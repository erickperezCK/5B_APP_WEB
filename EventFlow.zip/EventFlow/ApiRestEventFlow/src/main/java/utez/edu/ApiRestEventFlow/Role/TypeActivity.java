package utez.edu.ApiRestEventFlow.Role;

public enum TypeActivity {
    EVENT,
    WORKSHOP
}
