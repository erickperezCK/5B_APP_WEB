package utez.edu.ApiRestEventFlow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiRestEventFlowApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiRestEventFlowApplication.class, args);
	}

}
