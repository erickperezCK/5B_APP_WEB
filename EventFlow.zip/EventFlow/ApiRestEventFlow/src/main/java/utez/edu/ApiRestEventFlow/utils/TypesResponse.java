package utez.edu.ApiRestEventFlow.utils;

public enum TypesResponse {
    SUCCESS,
    ERROR,
    WARNING
}