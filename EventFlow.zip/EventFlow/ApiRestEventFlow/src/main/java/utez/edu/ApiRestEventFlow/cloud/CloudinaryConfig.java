package utez.edu.ApiRestEventFlow.cloud;

import com.cloudinary.Cloudinary;
import com.cloudinary.utils.ObjectUtils;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CloudinaryConfig {

    @Bean
    public Cloudinary cloudinary() {
        return new Cloudinary(ObjectUtils.asMap(
                "cloud_name", "dvsmwzs2g",
                "api_key", "139342923698986",
                "api_secret", "DDMHm_NMHzNH9n3g3UPWEehsCMw",
                "secure", true
        ));
    }
}