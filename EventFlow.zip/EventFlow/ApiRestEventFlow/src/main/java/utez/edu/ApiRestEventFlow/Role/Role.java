package utez.edu.ApiRestEventFlow.Role;

public enum Role {
    SUPERADMIN,
    ADMIN,
    CHECKER,
    USER
}
