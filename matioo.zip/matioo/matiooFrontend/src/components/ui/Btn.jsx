import { Button } from '@mantine/core';

export default function Btn() {
  return <Button type='submit' variant="filled" color="violet" className='flex justify-center m-auto'>Entrar</Button>;
}