import React from "react";

export default function Pages() {
    return (
        <>
            <div className="flex  items-center justify-center mt-[1em] text-gray-500">
                <h1>Filas de la lista: 8 ^ 1 - 8 de 16 </h1>
            </div>

        </>
    );
}