// Global constants for the application

// Single API URL constant to be used across the application
export const API_URL = 'http://localhost:8080';