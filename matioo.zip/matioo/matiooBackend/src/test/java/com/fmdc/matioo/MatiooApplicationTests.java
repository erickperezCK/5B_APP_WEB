package com.fmdc.matioo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MatiooApplicationTests {

	@Test
	void contextLoads() {
	}

}
