package com.fmdc.matioo.utils;

public enum TypesResponse {
    SUCCESS,
    ERROR,
    WARNING
}