package com.fmdc.matioo.resources;

public enum Role {
    RESPONSIBLE,
    INTERN,
    ADMIN
}
