package com.fmdc.matioo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MatiooApplication {

	public static void main(String[] args) {
		SpringApplication.run(MatiooApplication.class, args);
	}

}
