import { baseURL } from "../authApi";

export const getStyle = async () => {
  try {
    const response = await fetch(`${baseURL}/style/all`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        "Accept": "*/*"
      }
    });

    if (!response.ok) {
      throw new Error("Error al obtener los estilos");
    }

    const data = await response.json();
    
    if (data.type === "SUCCESS" && Array.isArray(data.result)) {
      // Buscar el estilo con status true
      const activeStyle = data.result.find(style => style.status === true);
      
      if (activeStyle) {
        return {
          type: "SUCCESS",
          result: {
            H1: activeStyle.H1,
            H2: activeStyle.H2,
            H3: activeStyle.H3,
            P: activeStyle.P,
            BgCard: activeStyle.BgCard,
            BgInterface: activeStyle.BgInterface,
            BgButton: activeStyle.BgButton,
            status: activeStyle.status
          }
        };
      } else {
        return {
          type: "ERROR",
          text: "No se encontró un estilo activo",
          result: null
        };
      }
    }

    return {
      type: "ERROR",
      text: "Respuesta inválida del servidor",
      result: null
    };
  } catch (error) {
    console.error("Error en getStyle:", error);
    return {
      type: "ERROR",
      text: error.message,
      result: null
    };
  }
}; 