import React, { useContext } from "react";
import { Tabs } from "expo-router";
import { StyleContext } from "../../../utils/StyleContext";
import { Ionicons } from "@expo/vector-icons";
import { TouchableOpacity } from "react-native";
import { logout } from "../../../api/authApi";
import { useRouter } from "expo-router";

export default function WaiterLayout() {
  const { style } = useContext(StyleContext);
  const router = useRouter();

  const handleLogout = async () => {
    try {
      await logout();
      router.replace("/");
    } catch (error) {
      console.error("Error al cerrar sesión:", error);
    }
  };

  return (
    <Tabs
      screenOptions={{
        headerStyle: {
          backgroundColor: style.BgInterface,
        },
        headerTintColor: style.H2,
        tabBarStyle: {
          backgroundColor: style.BgInterface,
        },
        tabBarActiveTintColor: style.BgButton,
        tabBarInactiveTintColor: style.H3,
        headerRight: () => (
          <TouchableOpacity
            onPress={handleLogout}
            style={{ marginRight: 15 }}
          >
            <Ionicons name="log-out-outline" size={24} color={style.H2} />
          </TouchableOpacity>
        ),
      }}
    >
      <Tabs.Screen
        name="areas"
        options={{
          title: "Áreas",
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="grid-outline" size={size} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="menu-qr"
        options={{
          title: "QR",
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="qr-code-outline" size={size} color={color} />
          ),
        }}
      />
    </Tabs>
  );
}
