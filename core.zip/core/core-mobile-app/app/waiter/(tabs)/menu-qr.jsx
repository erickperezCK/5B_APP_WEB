import React, { useContext } from "react";
import { View, Text, StyleSheet } from "react-native";
import QRCode from "react-native-qrcode-svg";
import { StyleContext } from "../../../utils/StyleContext";
import { webUrl } from "../../../api/authApi";

export default function MenuQR() {
  const { style } = useContext(StyleContext);
  const menuUrl = `${webUrl}menu`;

  return (
    <View style={[styles.container, { backgroundColor: style.BgInterface }]}>
      <View style={[styles.qrContainer, { backgroundColor: style.BgCard }]}>
        <Text style={[styles.title, { color: style.H1 }]}>Escanea el código QR</Text>
        <Text style={[styles.subtitle, { color: style.H3 }]}>
          Para ver nuestro menú digital
        </Text>
        
        <View style={styles.qrWrapper}>
          <QRCode
            value={menuUrl}
            size={300}
            backgroundColor="white"
            color="black"
            quietZone={10}
            enableLinearGradient={false}
            ecl="H"
          />
        </View>

        <Text style={[styles.url, { color: style.H3 }]}>
          {menuUrl}
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: 20,
  },
  qrContainer: {
    padding: 20,
    borderRadius: 15,
    alignItems: "center",
    width: "100%",
    maxWidth: 400,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 10,
    textAlign: "center",
  },
  subtitle: {
    fontSize: 16,
    marginBottom: 20,
    textAlign: "center",
  },
  qrWrapper: {
    padding: 20,
    backgroundColor: "white",
    borderRadius: 10,
    marginBottom: 20,
  },
  url: {
    fontSize: 14,
    textAlign: "center",
    marginTop: 10,
  },
}); 