import React, { useState, useContext, useEffect } from "react";
import { View, Text, TextInput, TouchableOpacity } from "react-native";
import { useRouter } from "expo-router";
import { login } from "../api/authApi";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Checkbox } from "react-native-paper";
import { StyleContext } from "../utils/StyleContext";
import { Ionicons } from "@expo/vector-icons";

export default function AuthScreen() {
  const router = useRouter();
  const { style, reloadStyles } = useContext(StyleContext);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;

    const checkAuth = async () => {
      try {
        console.log("Verificando autenticación...");
        const token = await AsyncStorage.getItem('jwt_token');
        const rol = await AsyncStorage.getItem('user_role');
        console.log("Token encontrado:", token);
        console.log("Rol encontrado:", rol);
        
        if (!isMounted) return;

        if (token && rol) {
          if (rol === "WAITER") {
            console.log("Navegando a waiter...");
            router.replace("/waiter/areas");
          } else if (rol === "LEADER") {
            console.log("Navegando a leader...");
            router.replace("/leader/dashboard");
          }
        }
      } catch (error) {
        console.error("Error al verificar autenticación:", error);
      } finally {
        if (isMounted) {
          setIsLoading(false);
        }
      }
    };

    checkAuth();
    return () => {
      isMounted = false;
    };
  }, []);

  useEffect(() => {
    console.log("Cargando estilos en vista de login...");
    reloadStyles();
  }, []);

  const handleLogin = async () => {
    try {
      console.log("Iniciando sesión...");
      const credentials = { email, password };
      const result = await login(credentials);
      console.log("Resultado del login:", result);
      
      if (result.jwt && result.rol) {
        await AsyncStorage.setItem('jwt_token', result.jwt);
        await AsyncStorage.setItem('user_role', result.rol);
        
        console.log("Token guardado:", result.jwt);
        console.log("Rol guardado:", result.rol);
        
        if (result.rol === "WAITER") {
          console.log("Navegando a waiter después de login...");
          router.replace("/waiter/areas");
        } else if (result.rol === "LEADER") {
          console.log("Navegando a leader después de login...");
          router.replace("/leader/dashboard");
        }
      }
    } catch (error) {
      console.error("Error al iniciar sesión:", error);
    }
  };

  if (isLoading) {
    return (
      <View className="flex-1 items-center justify-center" style={{ backgroundColor: style?.BgInterface || '#111111' }}>
        <Text style={{ color: style?.H2 || '#cccccc' }}>Cargando...</Text>
      </View>
    );
  }

  return (
    <View
      className="flex-1 items-center justify-center"
      style={{ backgroundColor: style.BgInterface }}
    >
      <View
        className="w-full max-w-sm p-12 rounded-2xl shadow-lg gap-5"
        style={{ backgroundColor: style.BgCard }}
      >
        <Text
          className="text-xl font-semibold text-center mb-6"
          style={{ color: style.H2 }}
        >
          Iniciar sesión
        </Text>

        {/* Campo de Email */}
        <View
          className="flex-row items-center border rounded-md px-3 py-2"
          style={{ borderColor: style.H3 }}
        >
          <Ionicons
            name="mail-outline"
            size={20}
            color={style.H3}
            className="mr-2"
          />
          <TextInput
            value={email}
            onChangeText={setEmail}
            placeholder="Correo electrónico"
            placeholderTextColor={style.H3}
            className="flex-1 text-white"
          />
        </View>

        {/* Campo de Contraseña */}
        <View
          className="flex-row items-center border rounded-md px-3 py-2"
          style={{ borderColor: style.H3 }}
        >
          <Ionicons
            name="lock-closed-outline"
            size={20}
            color={style.H3}
            className="mr-2"
          />
          <TextInput
            value={password}
            onChangeText={setPassword}
            placeholder="Contraseña"
            placeholderTextColor={style.H3}
            secureTextEntry
            className="flex-1 text-white"
          />
        </View>

        {/* Botón de Login */}
        <TouchableOpacity
          onPress={handleLogin}
          className="py-2 rounded-md"
          style={{ backgroundColor: style.BgButton }}
        >
          <Text
            className="text-center font-semibold"
            style={{ color: style.P }}
          >
            Entrar
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}
