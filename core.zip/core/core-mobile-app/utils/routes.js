export const Routes = {
    auth: "/",
    dashboard: "/dashboard",
    space:"/space"
    
  };
  