# service-core
This is the backend :) for CORE
