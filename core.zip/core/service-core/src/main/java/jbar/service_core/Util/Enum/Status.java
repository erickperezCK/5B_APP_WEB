package jbar.service_core.Util.Enum;

public enum Status {
    ACTIVE,
    INACTIVE,
    TODO,
    PROGRESS,
    DONE
}
