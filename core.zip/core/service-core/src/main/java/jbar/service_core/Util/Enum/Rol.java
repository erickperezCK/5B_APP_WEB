package jbar.service_core.Util.Enum;

public enum Rol {
    ADMIN,
    LEADER,
    WAITER,
    CHEF
}
