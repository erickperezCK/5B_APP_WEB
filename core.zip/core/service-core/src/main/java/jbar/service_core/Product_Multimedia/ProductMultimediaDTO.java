package jbar.service_core.Product_Multimedia;

public class ProductMultimediaDTO {
}
