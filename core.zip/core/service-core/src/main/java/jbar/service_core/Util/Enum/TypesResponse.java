package jbar.service_core.Util.Enum;

public enum TypesResponse {
    SUCCESS,
    ERROR,
    WARNING
}
