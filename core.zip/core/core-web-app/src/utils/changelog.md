# Tremor utils Changelog

### Changes 0.1.0

- New: chartColors added lime and fuchsia

### Changes mixed

- New: chartColors utilities
- New: getYAxisDomain utility
- New: hasOnlyOneValueForKey utility
- Fix: hasOnlyOneValueForKey for constants

## 0.1.0

### Changes

- New: chartColors utilities
- New: getYAxisDomain utility
- New: hasOnlyOneValueForKey utility

## 0.0.1

### Changes

- Updated sort order focusInput, focusRing, hasErrorInput
