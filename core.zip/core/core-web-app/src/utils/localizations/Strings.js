export default class Strings{
    static login = "Log in";
    static sendCode = "Send code";
    static logout = "Log out";
    static password = "Password";
    static newPassword = "New password";
    static updatePassword = "Update password";
    static confirmPassword = "Confirm password";
    static email = "E-mail";
    static forgotPassword = "Forgot password";
}