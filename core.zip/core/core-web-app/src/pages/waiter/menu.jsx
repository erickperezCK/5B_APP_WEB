import React, { useContext, useState, useEffect } from "react";
import { StyleContext } from "../../core/StyleContext";
import { getMenu } from "../../api/menuApi";
import { Document, Page, Text, View, Image, StyleSheet, pdf } from '@react-pdf/renderer';

// Estilos para el PDF
const styles = StyleSheet.create({
  page: {
    padding: 20,
    backgroundColor: '#ffffff',
    fontSize: 9
  },
  header: {
    marginBottom: 15,
    textAlign: 'center'
  },
  title: {
    fontSize: 18,
    marginBottom: 5,
    fontFamily: 'Helvetica-Bold'
  },
  description: {
    fontSize: 10,
    marginBottom: 15,
    fontFamily: 'Helvetica'
  },
  category: {
    fontSize: 12,
    marginTop: 10,
    marginBottom: 5,
    textAlign: 'center',
    fontFamily: 'Helvetica-Bold',
    color: '#333333',
    backgroundColor: '#f5f5f5',
    padding: 3
  },
  product: {
    marginBottom: 8,
    padding: 5,
    borderBottom: '0.5px solid #e0e0e0',
    flexDirection: 'row',
    alignItems: 'flex-start'
  },
  productImage: {
    width: 60,
    height: 60,
    marginRight: 8,
    objectFit: 'cover'
  },
  productInfo: {
    flex: 1,
    paddingRight: 5
  },
  productName: {
    fontSize: 10,
    fontFamily: 'Helvetica-Bold',
    marginBottom: 2
  },
  productDescription: {
    fontSize: 8,
    fontFamily: 'Helvetica',
    marginBottom: 2,
    color: '#666666'
  },
  productPrice: {
    fontSize: 9,
    fontFamily: 'Helvetica-Bold',
    color: '#333333'
  }
});

// Función para obtener la extensión del archivo
const getFileExtension = (url) => {
  const match = url.match(/\.([a-zA-Z0-9]+)(\?|$)/);
  return match ? match[1].toLowerCase() : 'jpg';
};

// Función para crear una URL de proxy
const createProxyUrl = (url) => {
  const extension = getFileExtension(url);
  const validExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
  
  if (!validExtensions.includes(extension)) {
    console.warn(`Extensión de archivo no válida: ${extension}`);
    return null;
  }

  // Usar un proxy de imágenes o un servicio como Cloudinary
  // Por ejemplo, usando images.weserv.nl como proxy
  return `https://images.weserv.nl/?url=${encodeURIComponent(url)}&output=${extension}`;
};

// Componente PDF
const MenuPDF = ({ menu }) => {
  // Obtener todas las categorías únicas
  const categories = [...new Set(
    menu.products.flatMap(product => 
      product.productCategories.map(cat => cat.name)
    )
  )].filter(Boolean);

  // Agrupar productos por categoría
  const productsByCategory = categories.reduce((acc, category) => {
    acc[category] = menu.products.filter(product => 
      product.productCategories.some(cat => cat.name === category)
    );
    return acc;
  }, {});

  return (
    <Document>
      <Page size="A4" style={styles.page}>
        <View style={styles.header}>
          <Text style={styles.title}>{menu.name}</Text>
          <Text style={styles.description}>{menu.description}</Text>
        </View>

        {categories.map((category, categoryIndex) => (
          <View key={categoryIndex}>
            <Text style={styles.category}>{category}</Text>
            {productsByCategory[category].map((product, index) => {
              const imageUrl = product.multimedia?.[0]?.url ? 
                createProxyUrl(`https://${product.multimedia[0].url}`) : 
                null;

              return (
                <View key={index} style={styles.product}>
                  {imageUrl && (
                    <Image 
                      src={imageUrl}
                      style={styles.productImage}
                    />
                  )}
                  <View style={styles.productInfo}>
                    <Text style={styles.productName}>{product.name}</Text>
                    <Text style={styles.productDescription}>{product.description}</Text>
                    <Text style={styles.productPrice}>${product.price.toFixed(2)}</Text>
                  </View>
                </View>
              );
            })}
          </View>
        ))}
      </Page>
    </Document>
  );
};

export function Menu() {
  const { style } = useContext(StyleContext);
  const [menu, setMenu] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchMenu = async () => {
      try {
        const response = await getMenu();
        if (response.type === "SUCCESS") {
          setMenu(response.result);
          
          // Generar y descargar el PDF automáticamente
          const blob = await pdf(<MenuPDF menu={response.result} />).toBlob();
          const url = URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.href = url;
          link.download = 'menu.pdf';
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          URL.revokeObjectURL(url);
        } else {
          setError("Error al obtener el menú");
        }
      } catch (err) {
        console.error('Error:', err);
        setError("Error al conectar con el servidor");
      } finally {
        setLoading(false);
      }
    };

    fetchMenu();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen px-4" style={{ backgroundColor: style.BgInterface }}>
        <div className="w-full max-w-sm shadow-2xl rounded-2xl p-6" style={{ backgroundColor: style.BgCard, color: style.H1 }}>
          <h2 className="text-xl font-bold mb-4 text-center" style={{ color: style.H2 }}>
            Generando menú...
          </h2>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-screen px-4" style={{ backgroundColor: style.BgInterface }}>
        <div className="w-full max-w-sm shadow-2xl rounded-2xl p-6" style={{ backgroundColor: style.BgCard, color: style.H1 }}>
          <h2 className="text-xl font-bold mb-4 text-center" style={{ color: style.H2 }}>
            Error
          </h2>
          <p className="text-center" style={{ color: style.H3 }}>
            {error}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-center justify-center min-h-screen px-4" style={{ backgroundColor: style.BgInterface }}>
      <div className="w-full max-w-sm shadow-2xl rounded-2xl p-6" style={{ backgroundColor: style.BgCard, color: style.H1 }}>
        <h2 className="text-xl font-bold mb-4 text-center" style={{ color: style.H2 }}>
          Menú generado
        </h2>
        <p className="text-center" style={{ color: style.H3 }}>
          El menú se ha descargado automáticamente
        </p>
      </div>
    </div>
  );
} 