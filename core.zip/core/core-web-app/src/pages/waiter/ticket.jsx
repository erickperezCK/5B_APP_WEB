import React, { useContext } from "react";
import { StyleContext } from "../../core/StyleContext";
import { QRCodeSVG } from "qrcode.react";
import { useParams } from "react-router-dom";

export function Ticket() {
  const { style } = useContext(StyleContext);
  const { sellId } = useParams();
  const domain = window.location.origin;
  const qrValue = `${domain}/waiter/${sellId}`;

  return (
    <div className="flex items-center justify-center min-h-screen px-4" style={{ backgroundColor: style.BgInterface }}>
      <div className="w-full max-w-sm shadow-2xl rounded-2xl p-6" style={{ backgroundColor: style.BgCard, color: style.H1 }}>
        <h2 className="text-xl font-bold mb-4 text-center" style={{ color: style.H2 }}>
          Escanea para calificar
        </h2>
        <div className="flex justify-center mb-4">
          <div className="p-4 bg-white rounded-lg">
            <QRCodeSVG 
              value={qrValue}
              size={200}
              level="H"
              includeMargin={true}
            />
          </div>
        </div>
        <p className="text-sm text-center" style={{ color: style.H3 }}>
          Escanea el código QR para calificar la atención de tu mesero
        </p>
      </div>
    </div>
  );
}
