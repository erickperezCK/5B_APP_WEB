export const StWaiter = [
    { mesero: "Juan Pérez", promedioEstrellas: 4.8, clientesAtendidos: 120, puntuacion: 4.7 },
    { mesero: "María López", promedioEstrellas: 4.5, clientesAtendidos: 140, puntuacion: 4.6 },
    { mesero: "Carlos Gómez", promedioEstrellas: 4.3, clientesAtendidos: 100, puntuacion: 4.4 },
    { mesero: "Ana Torres", promedioEstrellas: 4.9, clientesAtendidos: 90, puntuacion: 4.8 },
    { mesero: "Luis Ramírez", promedioEstrellas: 4.2, clientesAtendidos: 110, puntuacion: 4.3 }
];
