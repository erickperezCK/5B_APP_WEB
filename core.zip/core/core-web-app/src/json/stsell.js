export const StSell = [
    { fecha: "2024-01-01", total: 5000 },
    { fecha: "2024-01-02", total: 4200 },
    { fecha: "2024-01-03", total: 6300 },
    { fecha: "2024-01-04", total: 5800 },
    { fecha: "2024-01-05", total: 7000 }
];