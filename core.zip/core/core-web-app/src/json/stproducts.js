export const StProducts = [
    { platillo: "Hamburguesa Clásica", cantidad: 120 },
    { platillo: "Pizza Pepperoni", cantidad: 150 },
    { platillo: "Tacos al Pastor", cantidad: 180 },
    { platillo: "Ensalada César", cantidad: 90 },
    { platillo: "Sopa de Tortilla", cantidad: 60 }
];
export const StProductsTime = [
    { hora: "08:00", totalVentas: 200 },
    { hora: "10:00", totalVentas: 400 },
    { hora: "12:00", totalVentas: 1200 },
    { hora: "14:00", totalVentas: 1800 },
    { hora: "16:00", totalVentas: 1500 },
    { hora: "18:00", totalVentas: 1300 },
    { hora: "20:00", totalVentas: 900 },
    { hora: "22:00", totalVentas: 500 }
];

