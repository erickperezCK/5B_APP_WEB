
  "user": {
    "_id": "ObjectId",
    "description": "string (opcional)",
    "email": "string",
    "name": "string",
    "password": "string",
    "profile_photo_path": "string (opcional)",
    "register_date": "Date",
    "role": "enum('ADMIN', 'INSTRUCTOR', 'STUDENT')",
    "status": "enum('ACTIVE', 'INACTIVE')"
  }

  "account": {
    "_id": "ObjectId",
    "account_number": "string",
    "bank_name": "string",
    "status": "enum('ACTIVE', 'INACTIVE')",
    "admin_id": "ObjectId (ref: user._id)",
    "accountid": "ObjectId",
    "key": "string"
  }

  "course": {
    "_id": "ObjectId",
    "banner_path": "string",
    "status": "enum('FINALIZED', 'IN_PROGRESS', 'NOT_APPROVED', 'PUBLISHED', 'TO_APPROVE')",
    "description": "string",
    "end_date": "Date",
    "price": "number",
    "size": "number",
    "start_date": "Date",
    "title": "string",
    "instructor_id": "ObjectId (ref: user._id)"
  }


  "module": {
    "_id": "ObjectId",
    "date": "Date",
    "name": "string",
    "status": "enum('DELETED', 'LOCKED', 'UNLOCKED')",
    "course_id": "ObjectId (ref: course._id)"
  }


  "attendance": {
    "_id": "ObjectId",
    "attended": "boolean",
    "course_id": "ObjectId (ref: course._id)",
    "module_id": "ObjectId (ref: module._id)"
  }

  "category": {
    "_id": "ObjectId",
    "name": "string",
    "status": "enum('ACTIVE', 'INACTIVE')"
  }

  "constancy": {
    "_id": "ObjectId",
    "content_url": "string",
    "expedition_date": "Date",
    "course_id": "ObjectId (ref: course._id)"
  }

  "course_category": {
    "course_id": "ObjectId (ref: course._id)",
    "category_id": "ObjectId (ref: category._id)"
  }

  "registration": {
    "_id": "ObjectId",
    "status": "enum('CANCELED', 'FINALIZED', 'PENDING_PAYMENT', 'REGISTERED')",
    "course_id": "ObjectId (ref: course._id)",
    "student_id": "ObjectId (ref: user._id)"
  }

  "payment": {
    "_id": "ObjectId",
    "status": "enum('FAILED', 'FINISHED', 'PENDING')",
    "account_id": "ObjectId (ref: account._id)",
    "registration_id": "ObjectId (ref: registration._id)"
  }

  "review": {
    "_id": "ObjectId",
    "description": "string",
    "score": "number",
    "score_date": "Date",
    "course_id": "ObjectId (ref: course._id)",
    "instructor_id": "ObjectId (ref: user._id) (opcional)",
    "student_id": "ObjectId (ref: user._id)"
  }
  
  "section": {
    "_id": "ObjectId",
    "content_url": "string",
    "description": "string",
    "name": "string",
    "status": "enum('ACTIVE', 'INACTIVE')",
    "module_id": "ObjectId (ref: module._id)"
  }
