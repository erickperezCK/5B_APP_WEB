package com.eduhubpro.eduhubpro.Controllers.Instructor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.eduhubpro.eduhubpro.Entity.Attendance.Model.AttendanceDto;
import com.eduhubpro.eduhubpro.Entity.Attendance.Service.AttendanceService;
import com.eduhubpro.eduhubpro.Entity.Category.Model.CategoryDto;
import com.eduhubpro.eduhubpro.Entity.Category.Service.CategoryService;
import com.eduhubpro.eduhubpro.Entity.Course.Model.CourseDto;
import com.eduhubpro.eduhubpro.Entity.Course.Service.CourseService;
import com.eduhubpro.eduhubpro.Entity.Module.Model.ModuleDto;
import com.eduhubpro.eduhubpro.Entity.Module.Service.ModuleService;
import com.eduhubpro.eduhubpro.Entity.Section.Model.SectionDto;
import com.eduhubpro.eduhubpro.Entity.Section.Service.SectionService;
import com.eduhubpro.eduhubpro.Entity.User.Model.UserDto;
import com.eduhubpro.eduhubpro.Entity.User.Service.UserService;
import com.eduhubpro.eduhubpro.Util.Response.Message;

@RestController
@RequestMapping("/instructor")
public class InstructorController {

    private final CourseService courseService;
    private final UserService userService;
    private final ModuleService moduleService;
    private final SectionService sectionService;
    private final CategoryService categoryService;
    private final AttendanceService attendanceService;

    @Autowired
    public InstructorController(CourseService courseService, UserService userService, ModuleService moduleService,
            SectionService sectionService, CategoryService categoryService, AttendanceService attendanceService) {
        this.courseService = courseService;
        this.userService = userService;
        this.moduleService = moduleService;
        this.sectionService = sectionService;
        this.categoryService = categoryService;
        this.attendanceService = attendanceService;
    }

    @PostMapping("/user/profile")
    public ResponseEntity<Message> getMyInstructorProfile(@RequestBody @Validated(UserDto.Consult.class) UserDto dto) {
        return userService.findProfile(dto);
    }

    // Módulo usuarios
    @PostMapping("/user/upload-photo")
    public ResponseEntity<Message> uploadProfilePhoto(
            @Validated(UserDto.UploadProfilePhoto.class) @RequestBody UserDto dto) {
        return userService.uploadProfilePhoto(dto);
    }

    @PutMapping("/user/update-profile")
    public ResponseEntity<Message> updateProfile(@Validated(UserDto.Modify.class) @RequestBody UserDto dto) {
        return userService.updateProfile(dto);
    }

    @PutMapping("/user/change-status")
    public ResponseEntity<Message> changeStatusInstructor(
            @Validated(UserDto.ChangeStatus.class) @RequestBody UserDto dto) {
        return userService.changeStatusInstructor(dto);
    }

    @PostMapping("/user/support")
    public ResponseEntity<Message> support(@RequestParam String fullName, @RequestParam String email,
            @RequestParam String description) {
        return userService.support(fullName, email, description);
    }

    // Sección de categorías
    /*
     * @GetMapping("/category/all")
     * public ResponseEntity<Message> findAll() {
     * return categoryService.findAll();
     * }
     */

    @GetMapping("/category/all")
    public ResponseEntity<Message> findAllActives() {
        return categoryService.findAllActives();
    }

    @PostMapping("/category/by-id")
    public ResponseEntity<Message> findById(@Validated(CategoryDto.Consult.class) @RequestBody CategoryDto dto) {
        return categoryService.findById(dto);
    }

    /*
     * @PostMapping("/category/save")
     * public ResponseEntity<Message>
     * save(@Validated(CategoryDto.Register.class) @RequestBody CategoryDto dto) {
     * return categoryService.save(dto);
     * }
     * 
     * @PutMapping("/category/update")
     * public ResponseEntity<Message>
     * update( @Validated(CategoryDto.Modify.class) @RequestBody CategoryDto dto) {
     * return categoryService.update(dto);
     * }
     * 
     * @PutMapping("/category/change-status")
     * public ResponseEntity<Message>
     * changeStatus( @Validated(CategoryDto.ChangeStatus.class) @RequestBody
     * CategoryDto dto) {
     * return categoryService.changeStatus(dto);
     * }
     */

    // Sección de cursos
    // Muestra todos los cursos al docente
    @PostMapping("/course/all")
    public ResponseEntity<Message> findAllCourses(
            @Validated(CourseDto.ConsultFromInstructor.class) @RequestBody CourseDto dto) {
        return courseService.findAllByInstructor(dto);
    }

    @PostMapping("/course/by-id")
    public ResponseEntity<Message> findById(@Validated(CourseDto.Consult.class) @RequestBody CourseDto dto) {
        return courseService.findCourseDetails(dto);
    }

    // Mostrar todos los estudiantes con estado 'REGISTERED'
    @PostMapping("/course/registered-students")
    public ResponseEntity<Message> getRegisteredStudents(
            @Validated(CourseDto.Consult.class) @RequestBody CourseDto dto) {
        return courseService.findRegisteredStudents(dto);
    }

    @PostMapping("/course/create")
    public ResponseEntity<Message> save(@Validated(CourseDto.Register.class) @RequestBody CourseDto dto) {
        return courseService.save(dto);
    }

    @PutMapping("/course/update")
    public ResponseEntity<Message> update(@Validated(CourseDto.Modify.class) @RequestBody CourseDto dto) {
        return courseService.update(dto);
    }

    @PutMapping("/course/change-status")
    public ResponseEntity<Message> changeStatus(@Validated(CourseDto.ChangeStatus.class) @RequestBody CourseDto dto) {
        return courseService.changeStatus(dto);
    }

    // Sección de asistencia para los estudiantes
    // Filtar por estudiantes que aún no han tomado un módulo y los que ya lo
    // tomaron
    @PostMapping("/attendance/all")
    public ResponseEntity<Message> findStudentsByModuleTaken(
            @Validated(AttendanceDto.Consult.class) @RequestBody AttendanceDto dto) {
        return attendanceService.findStudentsByModuleTaken(dto);
    }

    // Sección de módulos para los cursos
    // Crear un módulo
    @PostMapping("/module/create")
    public ResponseEntity<Message> save(@Validated(ModuleDto.Register.class) @RequestBody ModuleDto dto) {
        return moduleService.save(dto);
    }

    // Actualizar un módulo
    @PutMapping("/module/update")
    public ResponseEntity<Message> update(@Validated(ModuleDto.Modify.class) @RequestBody ModuleDto dto) {
        return moduleService.update(dto);
    }

    // Cambiar el estado de un módulo (Eliminar o desbloquear)
    @PutMapping("/module/change-status")
    public ResponseEntity<Message> changeStatus(@Validated(ModuleDto.ChangeStatus.class) @RequestBody ModuleDto dto) {
        return moduleService.changeStatus(dto);
    }

    // Sección de secciones para los módulos
    // Crear una sección
    @PostMapping("/section/create")
    public ResponseEntity<Message> save(@Validated(SectionDto.Register.class) @RequestBody SectionDto dto) {
        return sectionService.save(dto);
    }

    // Actualizar una sección
    @PutMapping("/section/update")
    public ResponseEntity<Message> update(@Validated(SectionDto.Modify.class) @RequestBody SectionDto dto) {
        return sectionService.update(dto);
    }

    // Cambiar el estado de una sección (eliminar o cambiar a inactivo)
    @PutMapping("/section/change-status")
    public ResponseEntity<Message> changeStatus(@Validated(SectionDto.ChangeStatus.class) @RequestBody SectionDto dto) {
        return sectionService.changeStatus(dto);
    }
}