package com.eduhubpro.eduhubpro.Entity.Attendance.Model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class AttendanceDto {

    @NotNull(groups = { Modify.class, ChangeStatus.class }, message = "El id no puede ser nulo ni vacío.")
    private String attendanceId;

    @NotBlank(groups = { Register.class, Consult.class }, message = "El id del módulo no puede ser nulo.")
    private String moduleId;

    @NotBlank(groups = { Register.class }, message = "El id del estudiante no puede ser nulo.")
    private String studentId;

    @NotBlank(groups = { Register.class, Consult.class }, message = "El id del curso no puede ser nulo.")
    private String courseId;

    @NotNull(groups = { ChangeStatus.class }, message = "Falta indicar la asistencia.")
    private boolean attended;

    @NotNull(groups = { ChangeStatus.class }, message = "Falta indicar si está desbloqueado el módulo.")
    private boolean unlocked;

    public String getAttendanceId() {
        return attendanceId;
    }

    public void setAttendanceId(String attendanceId) {
        this.attendanceId = attendanceId;
    }

    public String getModuleId() {
        return moduleId;
    }

    public void setModuleId(String moduleId) {
        this.moduleId = moduleId;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public boolean isAttended() {
        return attended;
    }

    public void setAttended(boolean attended) {
        this.attended = attended;
    }

    public boolean isUnlocked() {
        return unlocked;
    }

    public void setUnlocked(boolean unlocked) {
        this.unlocked = unlocked;
    }

    public interface Register {
    }

    public interface Modify {
    }

    public interface ChangeStatus {
    }

    public interface Consult {
    }
}
