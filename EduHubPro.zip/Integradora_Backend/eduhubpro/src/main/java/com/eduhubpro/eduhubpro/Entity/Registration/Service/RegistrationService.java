package com.eduhubpro.eduhubpro.Entity.Registration.Service;

import com.eduhubpro.eduhubpro.Entity.Attendance.Model.Attendance;
import com.eduhubpro.eduhubpro.Entity.Attendance.Model.AttendanceRepository;
import com.eduhubpro.eduhubpro.Entity.Course.Model.Course;
import com.eduhubpro.eduhubpro.Entity.Course.Model.CourseDto;
import com.eduhubpro.eduhubpro.Entity.Course.Model.CourseRepository;
import com.eduhubpro.eduhubpro.Entity.Module.Model.Module;
import com.eduhubpro.eduhubpro.Entity.Module.Model.ModuleRepository;
import com.eduhubpro.eduhubpro.Entity.Payment.Model.Payment;
import com.eduhubpro.eduhubpro.Entity.Payment.Model.PaymentRepository;
import com.eduhubpro.eduhubpro.Entity.Registration.Model.Registration;
import com.eduhubpro.eduhubpro.Entity.Registration.Model.RegistrationDto;
import com.eduhubpro.eduhubpro.Entity.Registration.Model.RegistrationRepository;
import com.eduhubpro.eduhubpro.Entity.User.Model.User;
import com.eduhubpro.eduhubpro.Entity.User.Model.UserRepository;
import com.eduhubpro.eduhubpro.Security.Jwt.JwtUtil;
import com.eduhubpro.eduhubpro.Util.Enum.EntityEnum.PaymentStatus;
import com.eduhubpro.eduhubpro.Util.Enum.EntityEnum.RegistrationStatus;
import com.eduhubpro.eduhubpro.Util.Enum.TypesResponse;
import com.eduhubpro.eduhubpro.Util.Response.Message;
import com.eduhubpro.eduhubpro.Util.Services.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.SQLException;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class RegistrationService {

    private final RegistrationRepository registrationRepository;
    private final UserRepository userRepository;
    private final CourseRepository courseRepository;
    private final PaymentRepository paymentRepository;
    private final ModuleRepository moduleRepository;
    private final AttendanceRepository attendanceRepository;

    private final EmailService emailService;
    private final JwtUtil jwtUtil;

    @Autowired
    public RegistrationService(
            RegistrationRepository registrationRepository,
            UserRepository userRepository,
            CourseRepository courseRepository,
            PaymentRepository paymentRepository, JwtUtil jwtUtil, EmailService emailService,
            ModuleRepository moduleRepository, AttendanceRepository attendanceRepository) {
        this.registrationRepository = registrationRepository;
        this.userRepository = userRepository;
        this.courseRepository = courseRepository;
        this.paymentRepository = paymentRepository;
        this.moduleRepository = moduleRepository;
        this.attendanceRepository = attendanceRepository;
        this.emailService = emailService;
        this.jwtUtil = jwtUtil;
    }

    @Transactional(readOnly = true)
    public ResponseEntity<Message> findByCourse(CourseDto dto) {
        UUID courseId = UUID.fromString(dto.getCourseId());

        List<Registration> regs = registrationRepository.findByCourseIdAndStatus(courseId,
                Arrays.asList(RegistrationStatus.REGISTERED));
        List<User> students = regs.stream()
                .map(Registration::getStudent)
                .collect(Collectors.toList());

        if (students.isEmpty()) {
            return new ResponseEntity<>(
                    new Message("No se encontraron estudiantes registrados", TypesResponse.ERROR),
                    HttpStatus.NOT_FOUND);
        }

        Map<String, Object> response = new HashMap<>();
        response.put("students", students);
        response.put("total", students.size());

        return new ResponseEntity<>(
                new Message(response, "Estudiantes registrados en el curso", TypesResponse.SUCCESS),
                HttpStatus.OK);
    }

    /**
     * Filtro 1:
     * - Registration.registrationStatus = PENDING
     * - Payment.status = PENDING_PAYMENT
     */
    @Transactional(readOnly = true)
    public ResponseEntity<Message> findToApprove() {
        List<Object[]> results = registrationRepository.findAllByRegAndPayStatus(
                RegistrationStatus.PENDING,
                PaymentStatus.FINISHED);

        if (results.isEmpty()) {
            return new ResponseEntity<>(new Message("No hay inscripciones pendientes con pago finalizado.",
                    TypesResponse.ERROR), HttpStatus.NOT_FOUND);
        }

        // Creamos una lista de mapas con solo los campos necesarios para la vista
        List<Map<String, Object>> comprobaciones = results.stream().map(row -> {
            Registration reg = (Registration) row[0];
            Payment pay = (Payment) row[1];

            Map<String, Object> data = new HashMap<>();
            data.put("registrationId", reg.getRegistrationId());
            data.put("studentName", reg.getStudent().getName());
            data.put("studentEmail", reg.getStudent().getEmail());
            data.put("profilePhoto", reg.getStudent().getProfilePhotoPath());
            data.put("courseName", reg.getCourse().getTitle());
            data.put("instructorName", reg.getCourse().getInstructor().getName());
            data.put("startDate", reg.getCourse().getStartDate());
            data.put("endDate", reg.getCourse().getEndDate());
            data.put("price", reg.getCourse().getPrice());
            data.put("paymentId", pay.getPaymentId());
            data.put("paymentUrl", pay.getPaymentUrl());
            data.put("status", pay.getStatus());

            return data;
        }).collect(Collectors.toList());

        return new ResponseEntity<>(new Message(comprobaciones,
                "Inscripciones pendientes con pago finalizado obtenidas correctamente.",
                TypesResponse.SUCCESS), HttpStatus.OK);
    }

    /**
     * Filtro 2:
     * - Registration.registrationStatus = PENDING
     * - Payment.status = FINISHED
     */
    @Transactional(readOnly = true)
    public ResponseEntity<Message> findByPendingPayment() {
        List<Object[]> results = registrationRepository.findAllByRegAndPayStatus(
                RegistrationStatus.PENDING,
                PaymentStatus.PENDING_PAYMENT);

        if (results.isEmpty()) {
            return new ResponseEntity<>(new Message("No hay inscripciones pendientes con pago finalizado.",
                    TypesResponse.ERROR), HttpStatus.NOT_FOUND);
        }

        // Creamos una lista de mapas con solo los campos necesarios para la vista
        List<Map<String, Object>> comprobaciones = results.stream().map(row -> {
            Registration reg = (Registration) row[0];
            Payment pay = (Payment) row[1];

            Map<String, Object> data = new HashMap<>();
            data.put("registrationId", reg.getRegistrationId());
            data.put("studentName", reg.getStudent().getName());
            data.put("studentEmail", reg.getStudent().getEmail());
            data.put("profilePhoto", reg.getStudent().getProfilePhotoPath());
            data.put("courseName", reg.getCourse().getTitle());
            data.put("instructorName", reg.getCourse().getInstructor().getName());
            data.put("startDate", reg.getCourse().getStartDate());
            data.put("endDate", reg.getCourse().getEndDate());
            data.put("price", reg.getCourse().getPrice());
            data.put("paymentId", pay.getPaymentId());
            data.put("paymentUrl", pay.getPaymentUrl());
            data.put("status", pay.getStatus());

            return data;
        }).collect(Collectors.toList());

        return new ResponseEntity<>(new Message(comprobaciones,
                "Inscripciones pendientes con pago finalizado obtenidas correctamente.",
                TypesResponse.SUCCESS), HttpStatus.OK);
    }

    /**
     * 1) Crear una nueva inscripción (Registration).
     * 2) Luego, crear un objeto Payment asociado a esa inscripción.
     */
    @Transactional(rollbackFor = {SQLException.class})
    public ResponseEntity<Message> createRegistration(RegistrationDto dto) {
        // 1. Convertir los IDs a UUID y buscar las entidades necesarias
        // Se obtiene de la sesión en móvil
        UUID studentUuid = UUID.fromString(jwtUtil.extractUserId(dto.getStudentId()));
        UUID courseUuid = UUID.fromString(dto.getCourseId());

        Optional<User> optionalStudent = userRepository.findById(studentUuid);
        if (optionalStudent.isEmpty()) {
            return new ResponseEntity<>(
                    new Message("No se encontró el estudiante.", TypesResponse.ERROR),
                    HttpStatus.NOT_FOUND);
        }

        Optional<Course> optionalCourse = courseRepository.findById(courseUuid);
        if (optionalCourse.isEmpty()) {
            return new ResponseEntity<>(
                    new Message("No se encontró el curso.", TypesResponse.ERROR),
                    HttpStatus.NOT_FOUND);
        }

        // 2. Crear la inscripción
        User student = optionalStudent.get();
        Course course = optionalCourse.get();

        // Verificar si el curso es gratuito
        boolean isFreeCourse = course.getPrice() == 0;

        // Verificar si ya está inscrito
        Optional<Registration> existing = registrationRepository.findByStudentAndCourse(student, course);
        if (existing.isPresent()) {
            return new ResponseEntity<>(
                    new Message("Ya estás inscrito en este curso.", TypesResponse.ERROR),
                    HttpStatus.CONFLICT);
        }

        // Verificar cupo disponible
        long registeredCount = registrationRepository.countRegisteredByCourse(course,
                Arrays.asList(RegistrationStatus.PENDING, RegistrationStatus.REGISTERED));

        if (registeredCount >= course.getSize()) {
            return new ResponseEntity<>(
                    new Message("El curso alcanzó el límite de estudiantes inscritos.",
                            TypesResponse.ERROR),
                    HttpStatus.BAD_REQUEST);
        }

        // Crear la inscripción y asignar el estado según el precio del curso
        Registration newRegistration = new Registration(student, course);
        if (isFreeCourse) {
            newRegistration.setRegistrationStatus(RegistrationStatus.REGISTERED);
        } else {
            newRegistration.setRegistrationStatus(RegistrationStatus.PENDING);
        }

        // Guardar primero la inscripción para persistirla y obtener su ID
        newRegistration = registrationRepository.saveAndFlush(newRegistration);

        // Luego, crear y guardar el Payment asociado
        Payment payment = new Payment(newRegistration);
        if (isFreeCourse) {
            payment.setStatus(PaymentStatus.FINISHED);
        } else {
            payment.setStatus(PaymentStatus.PENDING_PAYMENT);
        }
        paymentRepository.saveAndFlush(payment);

        // 🟣 Crear asistencias por módulo (bloqueadas, excepto el primero)
        createInitialAttendanceRecords(student, course);

        return new ResponseEntity<>(
                new Message(newRegistration, "La inscripción fue creada correctamente.",
                        TypesResponse.SUCCESS),
                HttpStatus.OK);
    }

    @Transactional(rollbackFor = {SQLException.class})
    public ResponseEntity<Message> changeStatus(RegistrationDto dto) {
        UUID regId = UUID.fromString(dto.getRegistrationId());

        Optional<Registration> optional = registrationRepository.findById(regId);
        if (optional.isEmpty()) {
            return new ResponseEntity<>(new Message("No se encontró la inscripción.", TypesResponse.ERROR),
                    HttpStatus.NOT_FOUND);
        }

        Registration registration = optional.get();
        User student = registration.getStudent();
        Course course = registration.getCourse();

        // 2. Buscar el pago asociado
        Optional<Payment> optionalPayment = paymentRepository.findByRegistration(registration);
        if (optionalPayment.isEmpty()) {
            return new ResponseEntity<>(new Message("No se encontró el pago asociado a la inscripción.",
                    TypesResponse.ERROR), HttpStatus.NOT_FOUND);
        }
        Payment payment = optionalPayment.get();

        // Validamos el nuevo estado
        RegistrationStatus newStatus = dto.getRegistrationStatus();
        if (newStatus != RegistrationStatus.REGISTERED && newStatus != RegistrationStatus.CANCELED) {
            return new ResponseEntity<>(
                    new Message("Estado inválido. Solo se permite REGISTERED o CANCELED.",
                            TypesResponse.ERROR),
                    HttpStatus.BAD_REQUEST);
        }

        // Enviamos correo según el estado
        boolean emailSent = false;
        switch (newStatus) {
            case REGISTERED:
                emailSent = emailService.sendApprovedPayment(
                        "¡Pago aprobado! Estás inscrito en el curso.",
                        student.getEmail(),
                        student.getName(),
                        payment.getPaymentId().toString(),
                        course.getTitle());
                break;
            case CANCELED:
                emailSent = emailService.sendNotApprovedPayment(
                        "Tu pago fue rechazado.",
                        student.getEmail(),
                        student.getName(),
                        payment.getPaymentId().toString(),
                        course.getTitle());
                break;
            default:
                return new ResponseEntity<>(new Message("No fue posible realizar ésta acción.",
                        TypesResponse.ERROR), HttpStatus.INTERNAL_SERVER_ERROR);
        }

        if (!emailSent) {
            return new ResponseEntity<>(new Message("Falló el envío del correo.",
                    TypesResponse.ERROR), HttpStatus.INTERNAL_SERVER_ERROR);
        }

        // Actualizamos el estado
        registration.setRegistrationStatus(newStatus);
        registration = registrationRepository.saveAndFlush(registration);

        String msg = newStatus == RegistrationStatus.REGISTERED
                ? "Inscripción aprobada correctamente."
                : "Inscripción rechazada correctamente.";

        return new ResponseEntity<>(new Message(registration, msg, TypesResponse.SUCCESS), HttpStatus.OK);
    }

    private void createInitialAttendanceRecords(User student, Course course) {
        List<Module> courseModules = moduleRepository.findByCourseOrderByDateAsc(course);

        for (int i = 0; i < courseModules.size(); i++) {
            Module mod = courseModules.get(i);

            Attendance attendance = new Attendance();
            attendance.setStudent(student);
            attendance.setCourse(course);
            attendance.setModule(mod);
            attendance.setUnlocked(i == 0); // desbloquear solo el primer módulo
            attendance.setAttended(false);

            attendanceRepository.save(attendance);
        }
    }

}
