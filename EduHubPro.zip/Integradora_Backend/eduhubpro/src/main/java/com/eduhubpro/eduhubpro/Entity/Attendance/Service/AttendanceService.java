package com.eduhubpro.eduhubpro.Entity.Attendance.Service;

import com.eduhubpro.eduhubpro.Entity.Attendance.Model.Attendance;
import com.eduhubpro.eduhubpro.Entity.Attendance.Model.AttendanceDto;
import com.eduhubpro.eduhubpro.Entity.Attendance.Model.AttendanceRepository;
import com.eduhubpro.eduhubpro.Entity.Course.Model.Course;
import com.eduhubpro.eduhubpro.Entity.Course.Model.CourseRepository;
import com.eduhubpro.eduhubpro.Entity.Module.Model.Module;
import com.eduhubpro.eduhubpro.Entity.Module.Model.ModuleRepository;
import com.eduhubpro.eduhubpro.Entity.Section.Model.Section;
import com.eduhubpro.eduhubpro.Entity.Section.Model.SectionRepository;
import com.eduhubpro.eduhubpro.Entity.User.Model.User;
import com.eduhubpro.eduhubpro.Entity.User.Model.UserRepository;
import com.eduhubpro.eduhubpro.Security.Jwt.JwtUtil;
import com.eduhubpro.eduhubpro.Util.Enum.EntityEnum.Status;
import com.eduhubpro.eduhubpro.Util.Enum.TypesResponse;
import com.eduhubpro.eduhubpro.Util.Response.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.webjars.NotFoundException;

import java.sql.SQLException;
import java.util.*;
import java.util.stream.Collectors;

@Transactional
@Service
public class AttendanceService {

    private static final Logger logger = LoggerFactory.getLogger(AttendanceService.class);

    private final AttendanceRepository attendanceRepository;
    private final ModuleRepository moduleRepository;
    private final UserRepository userRepository;
    private final SectionRepository sectionRepository;
    private final CourseRepository courseRepository;
    private final JwtUtil jwtUtil;

    @Autowired
    public AttendanceService(AttendanceRepository attendanceRepository, ModuleRepository moduleRepository,
                             CourseRepository courseRepository, UserRepository userRepository, JwtUtil jwtUtil,
                             SectionRepository sectionRepository) {
        this.attendanceRepository = attendanceRepository;
        this.moduleRepository = moduleRepository;
        this.sectionRepository = sectionRepository;
        this.courseRepository = courseRepository;
        this.userRepository = userRepository;
        this.jwtUtil = jwtUtil;
    }

    // Método para obtener módulos y secciones de un curso en móvil
    @Transactional(readOnly = true)
    public ResponseEntity<Message> getModulesWithSections(String courseIdParam, String studentIdParam) {
        UUID courseId = UUID.fromString(courseIdParam);
        UUID studentId = UUID.fromString(jwtUtil.extractUserId(studentIdParam));

        Course course = courseRepository.findById(courseId)
                .orElseThrow(() -> new NotFoundException("Curso no encontrado"));

        User student = userRepository.findById(studentId)
                .orElseThrow(() -> new NotFoundException("Estudiante no encontrado"));

        List<Module> modules = moduleRepository.findAllByCourseWithSections(courseId);
        List<Attendance> attendances = attendanceRepository.findByStudentAndCourse(student, course);

        Map<UUID, Attendance> attendanceMap = attendances.stream()
                .collect(Collectors.toMap(
                        a -> a.getModule().getModuleId(),
                        a -> a
                ));

        List<Map<String, Object>> moduleData = modules.stream().map(mod -> {
            Map<String, Object> modMap = new HashMap<>();
            modMap.put("moduleId", mod.getModuleId());
            modMap.put("name", mod.getName());
            modMap.put("date", mod.getDate());

            Attendance att = attendanceMap.get(mod.getModuleId());
            String status = "LOCKED";
            if (att != null) {
                if (att.isAttended()) {
                    status = "COMPLETED";
                } else if (att.isUnlocked()) {
                    status = "UNLOCKED";
                }
            }

            modMap.put("status", status);

            // Secciones
            List<Map<String, Object>> sections = mod.getSections().stream()
                    .sorted(Comparator.comparing(Section::getCreatedAt))
                    .map(sec -> {
                        Map<String, Object> secMap = new HashMap<>();
                        secMap.put("sectionId", sec.getSectionId());
                        secMap.put("name", sec.getName());
                        secMap.put("createdAt", sec.getCreatedAt());
                        secMap.put("description", sec.getDescription());
                        secMap.put("contentUrl", sec.getContentUrl());
                        secMap.put("contentType", sec.getContentType());
                        secMap.put("duration", sec.getDuration());
                        secMap.put("courseId", courseId);
                        return secMap;
                    }).collect(Collectors.toList());

            if (!sections.isEmpty()) {
                sections.get(sections.size() - 1).put("isLast", true);
            }

            modMap.put("sections", sections);
            return modMap;
        }).collect(Collectors.toList());

        return new ResponseEntity<>(
                new Message(moduleData, "Módulos y lecciones cargadas", TypesResponse.SUCCESS),
                HttpStatus.OK
        );
    }

    // Método para obtener la lista de estudiantes que han tomado un módulo
    @Transactional(readOnly = true)
    public ResponseEntity<Message> findStudentsByModuleTaken(AttendanceDto dto) {
        // Obtener todas las asistencias relacionadas al módulo y curso
        UUID moduleId = UUID.fromString(dto.getModuleId());
        UUID courseId = UUID.fromString(dto.getCourseId());
        List<Attendance> attendanceList = attendanceRepository.findByModuleIdAndCourseId(moduleId, courseId);

        // Filtrar los que ya lo tomaron
        List<User> taken = attendanceList.stream()
                .filter(Attendance::isAttended)
                .map(Attendance::getStudent)
                .collect(Collectors.toList());

        // Filtrar los que lo tienen desbloqueado pero no lo han tomado
        List<User> pending = attendanceList.stream()
                .filter(a -> !a.isAttended() && a.isUnlocked())
                .map(Attendance::getStudent)
                .collect(Collectors.toList());

        // Crear mapa con ambas listas
        Map<String, List<User>> result = new HashMap<>();
        result.put("taken", taken);
        result.put("pending", pending);

        return new ResponseEntity<>(
                new Message(result, "Estudiantes clasificados por asistencia al módulo",
                        TypesResponse.SUCCESS),
                HttpStatus.OK);
    }

    // Método para obtener el progreso de asistencia de un estudiante en un curso
    @Transactional(readOnly = true)
    public ResponseEntity<Message> getProgress(String stId, String crsId) {
        UUID studentId = UUID.fromString(jwtUtil.extractUserId(stId));
        UUID courseId = UUID.fromString(crsId);

        User student = userRepository.findById(studentId)
                .orElseThrow(() -> new NotFoundException("Estudiante no encontrado"));
        Course course = courseRepository.findById(courseId)
                .orElseThrow(() -> new NotFoundException("Curso no encontrado"));

        int total = attendanceRepository.countByStudentAndCourse(student, course);
        int completed = attendanceRepository.countByStudentAndCourseAndAttendedTrue(student, course);

        int porcentaje = (total == 0) ? 0 : (completed * 100) / total;

        Map<String, Object> result = new HashMap<>();
        result.put("total", total);
        result.put("completed", completed);
        result.put("progress", porcentaje);

        return new ResponseEntity<>(
                new Message(result, "Progreso de asistencia del estudiante", TypesResponse.SUCCESS),
                HttpStatus.OK);
    }

    // Método para completar una sección y marcar asistencia
    @Transactional(rollbackFor = SQLException.class)
    public ResponseEntity<Message> completeSection(String stId, String sctId) {

        UUID studentId = UUID.fromString(jwtUtil.extractUserId(stId));
        UUID sectionId = UUID.fromString(sctId);

        Section section = sectionRepository.findById(sectionId)
                .orElseThrow(() -> new NotFoundException("Sección no encontrada"));
        Module module = section.getModule();
        Course course = module.getCourse();
        User student = userRepository.findById(studentId)
                .orElseThrow(() -> new NotFoundException("Estudiante no encontrado"));

        // ① Buscar asistencia actual
        Attendance current = attendanceRepository.findByStudentAndCourseAndModule(student, course, module)
                .orElseThrow(() -> new NotFoundException("Asistencia del módulo no encontrada"));

        // ② Determinar si es la última sección
        boolean isLast = sectionRepository.findAllByModuleId(module.getModuleId(), Status.ACTIVE)
                .stream()
                .max(Comparator.comparing(Section::getCreatedAt))
                .map(Section::getSectionId)
                .filter(sectionId::equals)
                .isPresent();

        current.setAttended(true);
        attendanceRepository.save(current);

        if (isLast) {
            // ③ Desbloquear siguiente módulo si existe
            List<Module> ordered = moduleRepository.findByCourseOrderByDateAsc(course);
            int idx = ordered.indexOf(module);

            if (idx + 1 < ordered.size()) {
                Module next = ordered.get(idx + 1);
                attendanceRepository.findByStudentAndCourseAndModule(student, course, next)
                        .ifPresent(nextAtt -> {
                            nextAtt.setUnlocked(true);
                            attendanceRepository.save(nextAtt);
                        });
            }

            return new ResponseEntity<>(
                    new Message("Asistencia registrada y siguiente módulo desbloqueado", TypesResponse.SUCCESS),
                    HttpStatus.OK
            );
        }

        return new ResponseEntity<>(
                new Message("Sección completada, pero aún no es la última del módulo", TypesResponse.SUCCESS),
                HttpStatus.OK
        );
    }

    /**
     * Utilidad: obtener (o crear) la asistencia a un módulo
     */
    private Attendance getOrCreateAttendance(User student,
                                             Course course,
                                             Module module,
                                             boolean unlocked) {
        return attendanceRepository
                .findByStudentAndCourseAndModule(student, course, module)
                .orElseGet(() -> {
                    Attendance att = new Attendance(student, module, course);
                    att.setUnlocked(unlocked);
                    return attendanceRepository.save(att);
                });
    }
}