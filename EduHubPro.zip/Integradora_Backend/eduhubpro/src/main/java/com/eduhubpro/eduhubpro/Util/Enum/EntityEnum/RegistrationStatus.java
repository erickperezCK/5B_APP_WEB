package com.eduhubpro.eduhubpro.Util.Enum.EntityEnum;

public enum RegistrationStatus {
    PENDING,
    REGISTERED, // Cuando ya está inscrito al curso y aprobado su pago
    CANCELED,
    FINALIZED // Cuando termina el curso
}