package com.eduhubpro.eduhubpro.Entity.Payment.Model;

import com.eduhubpro.eduhubpro.Util.Enum.EntityEnum.PaymentStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class PaymentDto {

    @NotBlank(groups = { Modify.class, ChangeStatus.class, Consult.class }, message = "El id no puede ser nulo.")
    private String paymentId;

    @NotBlank(groups = { Register.class }, message = "El inscripción no puede ser nula.")
    private String registrationId;

    @NotNull(groups = { ChangeStatus.class }, message = "El estado no puede ser nulo.")
    private PaymentStatus status;

    @NotBlank(groups = { Modify.class }, message = "El pago no puede ser nulo.")
    private String paymentUrl;

    @NotBlank(groups = { FindByStudent.class }, message = "El id del estudiante no puede ser nulo.")
    private String studentId;

    public String getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(String paymentId) {
        this.paymentId = paymentId;
    }

    public String getRegistrationId() {
        return registrationId;
    }

    public void setRegistrationId(String registrationId) {
        this.registrationId = registrationId;
    }

    public PaymentStatus getStatus() {
        return status;
    }

    public void setStatus(PaymentStatus status) {
        this.status = status;
    }

    public String getPaymentUrl() {
        return paymentUrl;
    }

    public void setPaymentUrl(String paymentUrl) {
        this.paymentUrl = paymentUrl;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public interface Register {
    }

    public interface Modify {
    }

    public interface ChangeStatus {
    }

    public interface Consult {
    }

    public interface FindByStudent {
    }

}