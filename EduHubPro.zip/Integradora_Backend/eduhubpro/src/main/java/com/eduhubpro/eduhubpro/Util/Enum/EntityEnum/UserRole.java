package com.eduhubpro.eduhubpro.Util.Enum.EntityEnum;

public enum UserRole {
    ADMIN,
    INSTRUCTOR,
    STUDENT
}