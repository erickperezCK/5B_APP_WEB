package com.eduhubpro.eduhubpro.Util.Services;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

@Service
public class PdfService {

    @Value("${spring.apitemplateio.apiurl}")
    private String apiUrl;

    @Value("${spring.apitemplateio.apikey}")
    private String apiKey;

    @Value("${spring.apitemplateio.constancy}")
    private String constancy;

    /**
     * Generates a PDF preview URL for a completed course.
     *
     * @param name           The name of the user for whom the certificate is generated.
     * @param courseName     The name of the completed course.
     * @param instructorName The name of the instructor of the course.
     * @param startDate      The start date of the course.
     * @param endDate        The completion date of the course.
     * @return A URL that provides a preview of the generated PDF certificate.
     * @throws IOException If an error occurs while generating the PDF.
     */
    public String generatePdf(String name, String courseName, String instructorName, String startDate, String endDate) throws IOException {
        try {
            HttpURLConnection connection = (HttpURLConnection) new URL(apiUrl + "?template_id=" + constancy + "&export_type=json").openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("X-API-KEY", apiKey);
            connection.setDoOutput(true);

            String json = String.format("{\"name\":\"%s\",\"course_name\":\"%s\",\"instructor_name\":\"%s\",\"start_date\":\"%s\",\"end_date\":\"%s\"}",
                    name, courseName, instructorName, startDate, endDate);
            connection.getOutputStream().write(json.getBytes(StandardCharsets.UTF_8));

            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8));
            String response = reader.lines().reduce("", String::concat);
            reader.close();

            int startIndex = response.indexOf("https://pub-cdn.apitemplate.io");
            int endIndex = response.indexOf(".pdf") + 4;

            if (startIndex == -1 || endIndex == -1) {
                throw new IOException("No se encontró la URL del PDF en la respuesta.");
            }

            return response.substring(startIndex, endIndex);
        } catch (IOException e) {
            throw new IOException("No se encontró la URL del PDF en la respuesta.");
        }
    }
}
