package com.eduhubpro.eduhubpro.Util.Config;

import com.eduhubpro.eduhubpro.Entity.Category.Model.Category;
import com.eduhubpro.eduhubpro.Entity.Category.Model.CategoryRepository;
import com.eduhubpro.eduhubpro.Entity.User.Model.User;
import com.eduhubpro.eduhubpro.Entity.User.Model.UserRepository;
import com.eduhubpro.eduhubpro.Util.Enum.EntityEnum.UserRole;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

@Configuration
public class DataInitializer {

    private final PasswordEncoder passwordEncoder;

    @Autowired
    public DataInitializer(PasswordEncoder passwordEncoder) {
        this.passwordEncoder = passwordEncoder;
    }

    @Bean
    CommandLineRunner initDatabase(UserRepository userRepository, CategoryRepository categoryRepository) {
        return args -> {
            // Usuario con rol de ADMIN
            Optional<User> optionalAdmin = userRepository.findByEmail("eduhubpro1@gmail.com");
            if (!optionalAdmin.isPresent()) {
                User adminUser = new User(
                        "Admin User",
                        "eduhubpro1@gmail.com",
                        passwordEncoder.encode("admin123"),
                        UserRole.ADMIN);
                userRepository.saveAndFlush(adminUser);
            }

            // Usuario con rol de STUDENT
            Optional<User> optionalStudent = userRepository.findByEmail("eduhubpro3@gmail.com");
            if (!optionalStudent.isPresent()) {
                User studentUser = new User(
                        "Student User",
                        "eduhubpro3@gmail.com",
                        passwordEncoder.encode("student123"),
                        UserRole.STUDENT);
                userRepository.saveAndFlush(studentUser);
            }

            // Usuario con rol de INSTRUCTOR
            Optional<User> optionalInstructor = userRepository.findByEmail("eduhubpro2@gmail.com");
            if (!optionalInstructor.isPresent()) {
                User instructorUser = new User(
                        "Instructor User",
                        "eduhubpro2@gmail.com",
                        passwordEncoder.encode("instructor123"),
                        UserRole.INSTRUCTOR);
                userRepository.saveAndFlush(instructorUser);
            }

            // Usuario con rol de STUDENT
            Optional<User> optionalStudent2 = userRepository.findByEmail("student2@example.com");
            if (!optionalStudent2.isPresent()) {
                User studentUser = new User(
                        "Student User 2",
                        "student2@example.com",
                        passwordEncoder.encode("student123"),
                        UserRole.STUDENT);
                userRepository.saveAndFlush(studentUser);
            }

            // Usuario con rol de STUDENT
            Optional<User> optionalInstructor2 = userRepository.findByEmail("instructor2@example.com");
            if (!optionalInstructor2.isPresent()) {
                User instructorUser = new User(
                        "Instructor User 2",
                        "instructor2@example.com",
                        passwordEncoder.encode("instructor123"),
                        UserRole.INSTRUCTOR);
                userRepository.saveAndFlush(instructorUser);
            }

            // Categorías
            String[] categoryNames = {
                    "Tecnología",
                    "Programación",
                    "Negocios",
                    "Emprendimiento",
                    "Ciencias",
                    "Idiomas",
                    "Educación",
                    "Arte",
                    "Marketing",
                    "Diseño",
                    "Economía",
                    "Finanzas",
                    "Comunicación",
                    "Desarrollo Personal",
                    "Oficios"
            };

            for (String categoryName : categoryNames) {
                Optional<Category> optionalCategory = categoryRepository.findByName(categoryName);
                if (!optionalCategory.isPresent()) {
                    Category newCategory = new Category(categoryName);
                    categoryRepository.saveAndFlush(newCategory);
                }
            }

        };
    }

}