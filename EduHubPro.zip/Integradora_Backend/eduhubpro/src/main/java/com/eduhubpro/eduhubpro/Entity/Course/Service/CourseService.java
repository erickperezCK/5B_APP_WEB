package com.eduhubpro.eduhubpro.Entity.Course.Service;

import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.eduhubpro.eduhubpro.Entity.Attendance.Model.Attendance;
import com.eduhubpro.eduhubpro.Entity.Attendance.Model.AttendanceRepository;
import com.eduhubpro.eduhubpro.Entity.Category.Model.Category;
import com.eduhubpro.eduhubpro.Entity.Category.Model.CategoryDto;
import com.eduhubpro.eduhubpro.Entity.Category.Model.CategoryRepository;
import com.eduhubpro.eduhubpro.Entity.Course.Model.Course;
import com.eduhubpro.eduhubpro.Entity.Course.Model.CourseDto;
import com.eduhubpro.eduhubpro.Entity.Course.Model.CourseRepository;
import com.eduhubpro.eduhubpro.Entity.Module.Model.Module;
import com.eduhubpro.eduhubpro.Entity.Module.Model.ModuleRepository;
import com.eduhubpro.eduhubpro.Entity.Registration.Model.Registration;
import com.eduhubpro.eduhubpro.Entity.Registration.Model.RegistrationRepository;
import com.eduhubpro.eduhubpro.Entity.Review.Model.Review;
import com.eduhubpro.eduhubpro.Entity.Review.Model.ReviewRepository;
import com.eduhubpro.eduhubpro.Entity.Section.Model.Section;
import com.eduhubpro.eduhubpro.Entity.Section.Model.SectionRepository;
import com.eduhubpro.eduhubpro.Entity.User.Model.User;
import com.eduhubpro.eduhubpro.Entity.User.Model.UserDto;
import com.eduhubpro.eduhubpro.Entity.User.Model.UserRepository;
import com.eduhubpro.eduhubpro.Security.Jwt.JwtUtil;
import com.eduhubpro.eduhubpro.Util.Enum.TypesResponse;
import com.eduhubpro.eduhubpro.Util.Enum.EntityEnum.CourseStatus;
import com.eduhubpro.eduhubpro.Util.Enum.EntityEnum.ModuleStatus;
import com.eduhubpro.eduhubpro.Util.Enum.EntityEnum.RegistrationStatus;
import com.eduhubpro.eduhubpro.Util.Enum.EntityEnum.Status;
import com.eduhubpro.eduhubpro.Util.Response.Message;
import com.eduhubpro.eduhubpro.Util.Services.EmailService;

@Service
public class CourseService {
    private static final Logger logger = LoggerFactory.getLogger(CourseService.class);

    private final CourseRepository courseRepository;
    private final UserRepository userRepository;
    private final CategoryRepository categoryRepository;
    private final RegistrationRepository registrationRepository;
    private final ModuleRepository moduleRepository;
    private final SectionRepository sectionRepository;
    private final ReviewRepository reviewRepository;
    private final AttendanceRepository attendanceRepository;

    private final JwtUtil jwtUtil;
    private final EmailService emailService;

    @Autowired
    public CourseService(CourseRepository courseRepository, UserRepository userRepository, JwtUtil jwtUtil,
                         CategoryRepository categoryRepository, EmailService emailService,
                         RegistrationRepository registrationRepository,
                         ModuleRepository moduleRepository, SectionRepository sectionRepository,
                         AttendanceRepository attendanceRepository, ReviewRepository reviewRepository) {
        this.courseRepository = courseRepository;
        this.userRepository = userRepository;
        this.registrationRepository = registrationRepository;
        this.moduleRepository = moduleRepository;
        this.sectionRepository = sectionRepository;
        this.reviewRepository = reviewRepository;
        this.attendanceRepository = attendanceRepository;
        this.jwtUtil = jwtUtil;
        this.categoryRepository = categoryRepository;
        this.emailService = emailService;
    }

    // --------------------------------------------
    @Transactional(readOnly = true)
    public ResponseEntity<Message> findAll() {
        List<Course> courses = courseRepository.findAll();

        logger.info("Búsqueda de cursos con categorías realizada correctamente");
        return new ResponseEntity<>(
                new Message(courses, "Listado de cursos con categorías", TypesResponse.SUCCESS),
                HttpStatus.OK);
    }

    // --------------------------------------------
    // 3.3.2.1.1 Observar cursos pendientes por aprobar del admin
    @Transactional(readOnly = true)
    public ResponseEntity<Message> findAllToApprove() {
        List<Course> courses = courseRepository.findAllByStatus(Arrays.asList(CourseStatus.TO_APPROVE,
                CourseStatus.PUBLISHED, CourseStatus.IN_PROGRESS));
        logger.info("Búsqueda de cursos con categorías realizada correctamente");
        return new ResponseEntity<>(
                new Message(courses, "Listado de cursos pendientes con categorías",
                        TypesResponse.SUCCESS),
                HttpStatus.OK);
    }

    // --------------------------------------------
    // Modificar para el docente
    @Transactional(readOnly = true)
    public ResponseEntity<Message> findAllInProgress() {
        List<Course> courses = courseRepository.findAllByStatus(Arrays.asList(CourseStatus.IN_PROGRESS));
        logger.info("Búsqueda de cursos  realizada correctamente");
        return new ResponseEntity<>(new Message(courses, "Listado de cursos", TypesResponse.SUCCESS),
                HttpStatus.OK);
    }

    // --------------------------------------------
    // Para mostrar en la página del docente de cursos
    @Transactional(readOnly = true)
    public ResponseEntity<Message> findAllByInstructor(CourseDto dto) {
        UUID instructorId = UUID.fromString(jwtUtil.extractUserId(dto.getInstructorId()));
        List<Course> courses = courseRepository.findAllByInstructor(instructorId,
                Arrays.asList(CourseStatus.INACTIVE));
        logger.info("Búsqueda de cursos realizada correctamente");
        return new ResponseEntity<>(new Message(courses, "Listado de cursos", TypesResponse.SUCCESS),
                HttpStatus.OK);
    }

    // --------------------------------------------
    // Para mostrar en la página principal de cursos y en la vista del admin cursos
    // publicados
    @Transactional(readOnly = true)
    public ResponseEntity<Message> findAllPublished() {
        List<Course> courses = courseRepository.findAllByStatus(Arrays.asList(CourseStatus.PUBLISHED));
        logger.info("Búsqueda de cursos publicados realizada correctamente");
        return new ResponseEntity<>(new Message(courses, "Listado de cursos publicados", TypesResponse.SUCCESS),
                HttpStatus.OK);
    }

    // --------------------------------------------
    // todo Filtrar por fecha e instructor, nombre, categoría
    @Transactional(readOnly = true)
    public ResponseEntity<Message> findByDate(CourseDto dto) {
        List<Course> courses = courseRepository.findByDate(dto.getStartDate());
        logger.info("Búsqueda de cursos por fecha realizada correctamente");
        return new ResponseEntity<>(new Message(courses, "Listado de cursos por fecha", TypesResponse.SUCCESS),
                HttpStatus.OK);
    }

    // CORREGIR YA QUE ESTÁ BUSCANDO POR ID Y NO POR NOMBRE
    @Transactional(readOnly = true)
    public ResponseEntity<Message> findByInstructorName(CourseDto dto) {
        List<Course> courses = courseRepository.findByInstructorAndCourseStatus(
                dto.getInstructorId().toLowerCase().trim(),
                CourseStatus.PUBLISHED);
        logger.info("Búsqueda de cursos por nombre realizada correctamente");
        return new ResponseEntity<>(new Message(courses, "Listado de cursos por nombre", TypesResponse.SUCCESS),
                HttpStatus.OK);
    }

    @Transactional(readOnly = true)
    public ResponseEntity<Message> findByCategory(CategoryDto dto) {
        UUID categoryId = UUID.fromString(dto.getCategoryId());

        List<Course> courses = courseRepository.findPublishedByCategoryId(categoryId, CourseStatus.PUBLISHED);

        logger.info("Búsqueda de cursos publicados por categoría realizada correctamente");

        return new ResponseEntity<>(
                new Message(courses, "Listado de cursos publicados por categoría",
                        TypesResponse.SUCCESS),
                HttpStatus.OK);
    }

    // Para que el admin vea los detalles del curso
    // Se espera que el curso ya esté en curso
    @Transactional(readOnly = true)
    public ResponseEntity<Message> findCourseDetails(CourseDto dto) {
        UUID courseId = UUID.fromString(dto.getCourseId()); // Convertir el ID a UUID

        // 1. Obtener el curso
        Optional<Course> optionalCourse = courseRepository.findById(courseId);
        if (optionalCourse.isEmpty()) {
            return new ResponseEntity<>(new Message("No se encontró el curso.", TypesResponse.ERROR),
                    HttpStatus.NOT_FOUND);
        }

        Course course = optionalCourse.get();

        // 2. Obtener los módulos del curso con estado filtrado
        // Filtrar por estado de los módulos
        List<ModuleStatus> moduleStatuses = Arrays.asList(ModuleStatus.LOCKED, ModuleStatus.UNLOCKED);
        List<Module> modules = moduleRepository.findAllByCourseId(courseId,
                moduleStatuses);

        // 3. Obtener las secciones de los módulos con estado ACTIVE
        List<UUID> moduleIds = modules.stream()
                .map(Module::getModuleId)
                .collect(Collectors.toList());
        List<Section> sections = sectionRepository.findAllByModuleId(moduleIds, Status.ACTIVE);

        // 4. Asociar las secciones a los módulos
        for (Module module : modules) {
            // Asignar las secciones a cada módulo
            module.setSections(sections.stream()
                    .filter(section -> section.getModule().equals(module))
                    .collect(Collectors.toList()));
        }

        // 5. Asociar los módulos al curso
        course.setModules(modules);

        // Obtener el conteo de estudiantes registrados en el curso
        long studentCount = registrationRepository.countRegisteredByCourse(course,
                Arrays.asList(RegistrationStatus.REGISTERED, RegistrationStatus.PENDING));

        // Obtener la info de cada estudiante
        List<Registration> students = registrationRepository.findByCourseAndStatusNotIn(course,
                Arrays.asList(RegistrationStatus.CANCELED, RegistrationStatus.FINALIZED));

        // Crear el mapa de resultados
        Map<String, Object> result = new HashMap<>();
        result.put("courseDetails", course); // Detalles del curso
        result.put("students", studentCount); // Número de estudiantes registrados
        result.put("totalStudent", students); // Estudiantes registrados

        return new ResponseEntity<>(
                new Message(result, "Curso encontrado correctamente", TypesResponse.SUCCESS),
                HttpStatus.OK);
    }

    @Transactional(readOnly = true)
    public ResponseEntity<Message> findRegisteredStudents(CourseDto dto) {
        UUID courseId = UUID.fromString(dto.getCourseId()); // Convertir el ID a UUID

        // Obtener todas las inscripciones con estado REGISTERED para el curso
        List<Registration> registrations = registrationRepository.findByCourseIdAndStatus(courseId,
                Arrays.asList(RegistrationStatus.REGISTERED));

        // Obtener los usuarios (estudiantes) asociados a las inscripciones
        List<User> students = registrations.stream()
                .map(registration -> registration.getStudent())
                .collect(Collectors.toList());

        if (students.isEmpty()) {
            return new ResponseEntity<>(
                    new Message("No se encontraron estudiantes registrados", TypesResponse.ERROR),
                    HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>(
                new Message(students, "Estudiantes registrados en el curso", TypesResponse.SUCCESS),
                HttpStatus.OK);
    }

    // --------------------------------------------
    @Transactional(readOnly = true)
    public ResponseEntity<Message> findCoursesInProgressByStudent(UserDto dto) {
        UUID studentId = UUID.fromString(jwtUtil.extractUserId(dto.getUserId()));

        List<Course> courses = registrationRepository
                .findInProgressCoursesByStudent(studentId);

        return new ResponseEntity<>(
                new Message(courses, "Cursos en progreso del estudiante", TypesResponse.SUCCESS),
                HttpStatus.OK);
    }

    // --------------------------------------------
    @Transactional(readOnly = true)
    public ResponseEntity<Message> findRegistrationByStudent(UserDto dto) {
        UUID studentId = UUID.fromString(jwtUtil.extractUserId(dto.getUserId()));

        List<Course> courses = registrationRepository.findRegistrationByStudent(studentId, List.of(RegistrationStatus.REGISTERED), Arrays.asList(CourseStatus.PUBLISHED, CourseStatus.FINALIZED));

        return new ResponseEntity<>(
                new Message(courses, "Cursos en progreso del estudiante", TypesResponse.SUCCESS),
                HttpStatus.OK);
    }

    // --------------------------------------------
    /*
     * @Transactional(rollbackFor = {SQLException.class})
     * public ResponseEntity<Message> save(CourseDto dto) {
     * UUID instructorId =
     * UUID.fromString(jwtUtil.extractUserId(dto.getInstructorId())); // Viene del
     * jwt
     * Optional<User> optionalInstructor = userRepository.findById(instructorId);
     * if (optionalInstructor.isEmpty()) {
     * return new ResponseEntity<>(new
     * Message("No se encontró el perfil del docente para relacionar al curso",
     * TypesResponse.ERROR), HttpStatus.NOT_FOUND);
     * }
     *
     * // Obtener los Ids de las categorías desde el DTO
     * List<UUID> categoryIds = dto.getCategoriesId().stream()
     * .map(UUID::fromString) // Convertir cada ID a UUID
     * .collect(Collectors.toList());
     *
     * // Consultar todas las categorías por su ID de una sola vez
     * List<Category> categories = categoryRepository.findAllById(categoryIds);
     *
     * if (categories.size() != categoryIds.size()) {
     * return new ResponseEntity<>(new
     * Message("Algunas categorías no fueron encontradas", TypesResponse.ERROR),
     * HttpStatus.NOT_FOUND);
     * }
     *
     * // La imagen del banner ya debe de llegar en el json
     * Course course = new Course(
     * dto.getTitle(),
     * dto.getDescription(),
     * dto.getBannerPath(),
     * dto.getStartDate(),
     * dto.getEndDate(),
     * dto.getPrice(),
     * dto.getSize(),
     * optionalInstructor.get(),
     * categories
     * );
     * course = courseRepository.saveAndFlush(course);
     *
     * if (course == null) {
     * return new ResponseEntity<>(new Message("No se pudo registrar el curso",
     * TypesResponse.ERROR), HttpStatus.INTERNAL_SERVER_ERROR);
     * }
     * logger.info("El registro ha sido realizado correctamente");
     * return new ResponseEntity<>(new Message(course,
     * "El curso ha sido registrado correctamente", TypesResponse.SUCCESS),
     * HttpStatus.OK);
     * }
     */

    @Transactional(rollbackFor = {SQLException.class})
    public ResponseEntity<Message> save(CourseDto dto) {
        UUID instructorId = UUID.fromString(jwtUtil.extractUserId(dto.getInstructorId()));
        Optional<User> optionalInstructor = userRepository.findById(instructorId);

        if (optionalInstructor.isEmpty()) {
            return new ResponseEntity<>(new Message("Docente no encontrado", TypesResponse.ERROR),
                    HttpStatus.NOT_FOUND);
        }

        List<UUID> categoryIds = dto.getCategoriesId().stream()
                .map(UUID::fromString)
                .collect(Collectors.toList());

        List<Category> categories = categoryRepository.findAllById(categoryIds);

        if (categories.size() != categoryIds.size()) {
            return new ResponseEntity<>(new Message("Categorías inválidas", TypesResponse.ERROR),
                    HttpStatus.NOT_FOUND);
        }

        Course course = new Course(
                dto.getTitle(),
                dto.getDescription(),
                dto.getBannerPath(),
                dto.getStartDate(),
                dto.getEndDate(),
                dto.getPrice(),
                dto.getSize(),
                optionalInstructor.get(),
                categories // ← relación directa con categorías
        );

        course = courseRepository.saveAndFlush(course);

        return new ResponseEntity<>(
                new Message(course, "Curso guardado exitosamente", TypesResponse.SUCCESS),
                HttpStatus.OK);
    }

    // --------------------------------------------
    @Transactional(rollbackFor = {SQLException.class})
    public ResponseEntity<Message> update(CourseDto dto) {
        UUID courseId = UUID.fromString(dto.getCourseId());
        Optional<Course> optionalCourse = courseRepository.findById(courseId);

        if (optionalCourse.isEmpty()) {
            return new ResponseEntity<>(new Message("Curso no encontrado", TypesResponse.ERROR),
                    HttpStatus.NOT_FOUND);
        }

        List<UUID> categoryIds = dto.getCategoriesId().stream()
                .map(UUID::fromString)
                .collect(Collectors.toList());

        List<Category> categories = categoryRepository.findAllById(categoryIds);

        if (categories.size() != categoryIds.size()) {
            return new ResponseEntity<>(new Message("Categorías inválidas", TypesResponse.ERROR),
                    HttpStatus.NOT_FOUND);
        }

        Course course = optionalCourse.get();
        course.setTitle(dto.getTitle());
        course.setDescription(dto.getDescription());
        course.setBannerPath(dto.getBannerPath());
        course.setStartDate(dto.getStartDate());
        course.setEndDate(dto.getEndDate());
        course.setPrice(dto.getPrice());
        course.setSize(dto.getSize());
        course.setCategories(categories); // ← Actualiza la relación

        course = courseRepository.saveAndFlush(course);

        return new ResponseEntity<>(
                new Message(course, "Curso actualizado exitosamente", TypesResponse.SUCCESS),
                HttpStatus.OK);
    }

    // todo al cambiar el estado del curso se cambiará también en inscripción, , y
    // se mandarán constancias
    // todo crear un job que cambie el estado de los cursos a publicados cuando su
    // fecha de inicio de acerque, notificar un dia antes de que el curso empezará

    // --------------------------------------------
    // 3.3.2.1.2 Aceptar/Rechazar
    @Transactional(rollbackFor = {SQLException.class})
    public ResponseEntity<Message> changeStatus(CourseDto dto) {
        logger.info(dto.getCourseStatus());
        UUID uuid = UUID.fromString(dto.getCourseId());
        Optional<Course> optionalCourse = courseRepository.findById(uuid);

        if (optionalCourse.isEmpty()) {
            return new ResponseEntity<>(new Message("No se encontró el curso.", TypesResponse.ERROR),
                    HttpStatus.NOT_FOUND);
        }

        Course course = optionalCourse.get();

        Optional<User> optionalUser = userRepository.findById(course.getInstructor().getUserId());

        if (optionalUser.isEmpty()) {
            return new ResponseEntity<>(
                    new Message("No se encontró el usuario relacionado al curso.",
                            TypesResponse.ERROR),
                    HttpStatus.NOT_FOUND);
        }

        User user = optionalUser.get();

        // enviar por correo al instructor que no se aprobó su curso si es el caso
        switch (CourseStatus.valueOf(dto.getCourseStatus())) {
            case CourseStatus.PUBLISHED:
                if (!emailService.sendEmail(
                        "Curso aprobado.",
                        user.getEmail(),
                        user.getName(),
                        course.getTitle(),
                        course.getStartDate().toString(),
                        course.getEndDate().toString())) {
                    return new ResponseEntity<>(
                            new Message("Error al enviar la notificación al usuario, inténtalo de nuevo.",
                                    TypesResponse.ERROR),
                            HttpStatus.INTERNAL_SERVER_ERROR);
                }
                course.setCourseStatus(CourseStatus.valueOf(dto.getCourseStatus()));
                break;
            case CourseStatus.NOT_APPROVED:
                if (!emailService.sendEmail(
                        "Curso no aprobado.",
                        user.getEmail(),
                        user.getName(),
                        course.getTitle())) {
                    return new ResponseEntity<>(
                            new Message("Error al enviar la notificación al usuario, inténtalo de nuevo.",
                                    TypesResponse.ERROR),
                            HttpStatus.INTERNAL_SERVER_ERROR);
                }
                course.setCourseStatus(CourseStatus.valueOf(dto.getCourseStatus()));
                break;
            case CourseStatus.TO_APPROVE:
                course.setCourseStatus(CourseStatus.TO_APPROVE);
                break;
            case CourseStatus.INACTIVE:
                course.setCourseStatus(CourseStatus.INACTIVE);
                break;
            default:
                return new ResponseEntity<>(
                        new Message("Error al cambiar el estado del curso.",
                                TypesResponse.ERROR),
                        HttpStatus.INTERNAL_SERVER_ERROR);
        }

        course = courseRepository.saveAndFlush(course);

        if (course == null) {
            return new ResponseEntity<>(
                    new Message("Error al cambiar el estado del curso.", TypesResponse.ERROR),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }

        logger.info("El estado del curso ha sido actualizado correctamente");
        return new ResponseEntity<>(
                new Message(course, "Se cambió el estado del curso correctamente.",
                        TypesResponse.SUCCESS),
                HttpStatus.OK);
    }

    @Transactional(rollbackFor = {SQLException.class})
    public void changeStatus(UUID courseId) {
        // Buscar el curso por ID
        Optional<Course> optionalCourse = courseRepository.findById(courseId);
        if (optionalCourse.isEmpty()) {
            logger.error("No se encontró el curso con ID {}", courseId);
            return;
        }

        Course course = optionalCourse.get();

        // Obtener todos los usuarios asociados al curso a través de las inscripciones
        List<Registration> registrations = registrationRepository.findByCourseAndStatusNotIn(course,
                Arrays.asList(RegistrationStatus.CANCELED, RegistrationStatus.FINALIZED));

        if (registrations.isEmpty()) {
            logger.info("No hay usuarios registrados en el curso con ID {}", courseId);
            return;
        }

        // Obtener el instructor para incluirlo en los correos
        User instructor = course.getInstructor();

        // Iterar sobre los usuarios registrados
        for (Registration registration : registrations) {
            User student = registration.getStudent();

            // Verificar si el estudiante ha completado todos los módulos
            // boolean completedAllModules = true;
            List<Module> modules = moduleRepository.findByCourseOrderByDateAsc(course);
            int totalModules = modules.size();

            /*
             * for (Module module : modules) {
             * Optional<Attendance> attendance = attendanceRepository
             * .findByStudentAndCourseAndModule(student, course, module);
             * if (attendance.isEmpty() || !attendance.get().isAttended()) {
             * completedAllModules = false;
             * break;
             * }
             * }
             */

            // Contar asistencias válidas del alumno
            long attendedModules = modules.stream()
                    .map(module -> attendanceRepository.findByStudentAndCourseAndModule(student,
                            course, module))
                    .filter(opt -> opt.isPresent() && opt.get().isAttended())
                    .count();

            double attendancePercentage = (attendedModules * 100.0) / totalModules;

            // Verificar si el estudiante ha dejado una valoración
            Optional<Review> review = reviewRepository.findByStudentAndCourse(student, course);

            if (attendancePercentage >= 80 && review.isPresent()) {
                // Enviar correo con la constancia
                boolean emailSent = emailService.sendEmail(
                        "Constancia de curso completado",
                        student.getEmail(),
                        student.getName(),
                        instructor.getName(),
                        course.getTitle(),
                        course.getStartDate().toString(),
                        course.getEndDate().toString());

                if (!emailSent) {
                    logger.error("Error al enviar la notificación al usuario {}",
                            student.getName());
                }
            } else {
                logger.info("El estudiante {} tiene asistencia de {}% y {}review",
                        student.getName(),
                        String.format("%.1f", attendancePercentage),
                        review.isPresent() ? "sí tiene " : "no tiene ");
            }
        }

        // Cambiar el estado del curso a COMPLETED
        course.setCourseStatus(CourseStatus.FINALIZED);

        // Guardar el curso con el nuevo estado
        courseRepository.saveAndFlush(course);

        logger.info("El estado del curso con ID {} ha sido actualizado a COMPLETED y las constancias enviadas.",
                courseId);
    }

}