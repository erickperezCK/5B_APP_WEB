package com.eduhubpro.eduhubpro.Entity.Payment.Service;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.eduhubpro.eduhubpro.Entity.Payment.Model.Payment;
import com.eduhubpro.eduhubpro.Entity.Payment.Model.PaymentDto;
import com.eduhubpro.eduhubpro.Entity.Payment.Model.PaymentRepository;
import com.eduhubpro.eduhubpro.Security.Jwt.JwtUtil;
import com.eduhubpro.eduhubpro.Util.Enum.TypesResponse;
import com.eduhubpro.eduhubpro.Util.Enum.EntityEnum.PaymentStatus;
import com.eduhubpro.eduhubpro.Util.Response.Message;

@Service
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final JwtUtil jwtUtil;

    @Autowired
    public PaymentService(PaymentRepository paymentRepository, JwtUtil jwtUtil) {
        this.paymentRepository = paymentRepository;
        this.jwtUtil = jwtUtil;
    }

    /**
     * Obtener pagos pendientes filtrados por estudiante.
     * Se espera que en el DTO se envíe el studentId (normalmente extraído del JWT).
     */
    @Transactional(readOnly = true)
    public ResponseEntity<Message> findPendingByStudent(PaymentDto dto) {
        // Extraer el studentId desde el JWT
        UUID studentId = UUID.fromString(jwtUtil.extractUserId(dto.getStudentId()));
        // Obtener los pagos pendientes asociados al estudiante
        List<Payment> payments = paymentRepository.findPendingByStudent(studentId);
        return new ResponseEntity<>(
                new Message(payments, "Pagos pendientes para el estudiante", TypesResponse.SUCCESS),
                HttpStatus.OK);
    }

    /**
     * Obtener todos los pagos pendientes sin filtrar por estudiante.
     */
    @Transactional(readOnly = true)
    public ResponseEntity<Message> findPendingPayments() {
        List<Payment> payments = paymentRepository.findPendingPayments();
        return new ResponseEntity<>(
                new Message(payments, "Pagos pendientes", TypesResponse.SUCCESS),
                HttpStatus.OK);
    }

    /**
     * Obtener todos los pagos aprobados (estado FINISHED) sin filtrar por estudiante.
     */
    @Transactional(readOnly = true)
    public ResponseEntity<Message> findFinishedPayments() {
        List<Payment> payments = paymentRepository.findFinishedPayments();
        return new ResponseEntity<>(
                new Message(payments, "Pagos aprobados", TypesResponse.SUCCESS),
                HttpStatus.OK);
    }

    /**
     * Actualizar un Payment recibiendo solo:
     * - paymentId
     * - paymentUrl
     * Este método no cambia el estado ni la inscripción, sólo la URL.
     */
    @Transactional(rollbackFor = { SQLException.class })
    public ResponseEntity<Message> updatePayment(PaymentDto dto) {
        // Convertir el paymentId y buscar el Payment
        UUID paymentUuid = UUID.fromString(dto.getPaymentId());
        Optional<Payment> optionalPayment = paymentRepository.findById(paymentUuid);
        if (optionalPayment.isEmpty()) {
            return new ResponseEntity<>(new Message("No se encontró el pago.", TypesResponse.ERROR),
                    HttpStatus.NOT_FOUND);
        }

        // Actualizar la URL
        Payment payment = optionalPayment.get();
        payment.setPaymentUrl(dto.getPaymentUrl());
        payment.setStatus(PaymentStatus.FINISHED); // Marcar el pago como pagado

        // Guardar los cambios
        payment = paymentRepository.saveAndFlush(payment);

        return new ResponseEntity<>(new Message(payment, "Se actualizó la URL del pago correctamente.",
                TypesResponse.SUCCESS), HttpStatus.OK);
    }

    @Transactional(rollbackFor = { SQLException.class })
    public ResponseEntity<Message> changePaymentStatus(PaymentDto dto) {
        // 1. Convertir ID y buscar el Payment
        UUID paymentUuid = UUID.fromString(dto.getPaymentId());
        Optional<Payment> optionalPayment = paymentRepository.findById(paymentUuid);
        if (optionalPayment.isEmpty()) {
            return new ResponseEntity<>(
                    new Message("No se encontró el pago.", TypesResponse.ERROR),
                    HttpStatus.NOT_FOUND);
        }

        // 2. Actualizar el estado del pago
        Payment payment = optionalPayment.get();
        payment.setStatus(dto.getStatus());

        // 3. Guardar cambios
        payment = paymentRepository.saveAndFlush(payment);

        return new ResponseEntity<>(
                new Message(payment, "El estado del pago se ha actualizado correctamente.",
                        TypesResponse.SUCCESS),
                HttpStatus.OK);
    }
}
