package com.eduhubpro.eduhubpro.Util.Enum.EntityEnum;

public enum PaymentStatus {
    FINISHED, // Cuando se realiza el pago y se sube el boucher en la móvil
    PENDING_PAYMENT,
    FAILED
}
// cuando se genera una inscripción se debe asociar rapidamente el pago 