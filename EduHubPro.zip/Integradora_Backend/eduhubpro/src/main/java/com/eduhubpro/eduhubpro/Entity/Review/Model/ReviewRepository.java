package com.eduhubpro.eduhubpro.Entity.Review.Model;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.eduhubpro.eduhubpro.Entity.Course.Model.Course;
import com.eduhubpro.eduhubpro.Entity.User.Model.User;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface ReviewRepository extends JpaRepository<Review, UUID> {
    List<Review> findByCourseCourseId(UUID courseId);

    @Query("SELECT r FROM Review r WHERE r.student = :student AND r.course = :course")
    Optional<Review> findByStudentAndCourse(@Param("student") User student, @Param("course") Course course);

}
