package com.eduhubpro.eduhubpro.Controllers.Admin;

import com.eduhubpro.eduhubpro.Entity.Account.Model.AccountDto;
import com.eduhubpro.eduhubpro.Entity.Account.Service.AccountService;
import com.eduhubpro.eduhubpro.Entity.Category.Model.CategoryDto;
import com.eduhubpro.eduhubpro.Entity.Category.Service.CategoryService;
import com.eduhubpro.eduhubpro.Entity.Course.Model.CourseDto;
import com.eduhubpro.eduhubpro.Entity.Course.Model.CourseRepository;
import com.eduhubpro.eduhubpro.Entity.Course.Service.CourseService;
import com.eduhubpro.eduhubpro.Entity.Payment.Model.PaymentDto;
import com.eduhubpro.eduhubpro.Entity.Payment.Service.PaymentService;
import com.eduhubpro.eduhubpro.Entity.Registration.Model.RegistrationDto;
import com.eduhubpro.eduhubpro.Entity.Registration.Service.RegistrationService;
import com.eduhubpro.eduhubpro.Entity.Review.Model.ReviewDto;
import com.eduhubpro.eduhubpro.Entity.Review.Service.ReviewService;
import com.eduhubpro.eduhubpro.Entity.User.Model.UserDto;
import com.eduhubpro.eduhubpro.Entity.User.Service.UserService;
import com.eduhubpro.eduhubpro.Util.Response.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/admin")
public class AdminController {

    private final UserService userService;
    private final CategoryService categoryService;
    private final CourseRepository courseRepository;
    private final CourseService courseService;
    private final RegistrationService registrationService;
    private final AccountService accountService;
    private final ReviewService reviewService;
    private final PaymentService paymentService;

    @Autowired
    public AdminController(UserService userService, CategoryService categoryService, CourseRepository courseRepository,
            CourseService courseService, RegistrationService registrationService, AccountService accountService,
            ReviewService reviewService, PaymentService paymentService) {
        this.userService = userService;
        this.categoryService = categoryService;
        this.courseRepository = courseRepository;
        this.courseService = courseService;
        this.registrationService = registrationService;
        this.accountService = accountService;
        this.reviewService = reviewService;
        this.paymentService = paymentService;
    }

    @GetMapping("/user/count")
    public ResponseEntity<Message> countUsers() {
        return userService.countAllUsers();
    }

    @GetMapping("/user/all")
    public ResponseEntity<Message> getAllUsers() {
        return userService.findAllForAdmin();
    }

    @PostMapping("/user/by-id")
    public ResponseEntity<Message> getUserById(@Validated(UserDto.Consult.class) @RequestBody UserDto dto) {
        return userService.findById(dto);
    }

    @PostMapping("/user/create")
    public ResponseEntity<Message> saveUser(@Validated(UserDto.Register.class) @RequestBody UserDto dto) {
        return userService.createUserForAdmin(dto);
    }

    @PutMapping("/user/update")
    public ResponseEntity<Message> updateUser(@Validated(UserDto.ModifyUser.class) @RequestBody UserDto dto) {
        return userService.updateForAdmin(dto);
    }

    @PutMapping("/user/change-status-instructor")
    public ResponseEntity<Message> changeStatusInstructor(
            @Validated(UserDto.ChangeStatus.class) @RequestBody UserDto dto) {
        return userService.changeStatusInstructorForAdmin(dto);
    }

    @PutMapping("/user/change-status-student")
    public ResponseEntity<Message> changeStatusUser(@Validated(UserDto.ChangeStatus.class) @RequestBody UserDto dto) {
        return userService.changeStatusStudentForAdmin(dto);
    }

    // Módulo categorías
    @GetMapping("/category/all")
    public ResponseEntity<Message> getAllCategories() {
        return categoryService.findAllActives();
    }

    @PostMapping("/category/by-id")
    public ResponseEntity<Message> getCategoryById(@Validated(CategoryDto.Consult.class) @RequestBody CategoryDto dto) {
        return categoryService.findById(dto);
    }

    @PostMapping("/category/create")
    public ResponseEntity<Message> save(@Validated(CategoryDto.Register.class) @RequestBody CategoryDto dto) {
        return categoryService.save(dto);
    }

    @PutMapping("/category/update")
    public ResponseEntity<Message> update(@Validated(CategoryDto.Modify.class) @RequestBody CategoryDto dto) {
        return categoryService.update(dto);
    }

    @PutMapping("/category/change-status")
    public ResponseEntity<Message> changeStatus(
            @Validated(CategoryDto.ChangeStatus.class) @RequestBody CategoryDto dto) {
        return categoryService.changeStatus(dto);
    }

    // Módulo de cursos
    // Muestra la lista de cursos por aprobar
    @GetMapping("/course/to-approve")
    public ResponseEntity<Message> getAllCourses() {
        return courseService.findAllToApprove();
    }

    @GetMapping("/course/all")
    public ResponseEntity<Message> getAll() {
        return courseService.findAll();
    }

    // Obtiene el curso con módulos y secciones
    @PostMapping("/course/by-id")
    public ResponseEntity<Message> findById(@Validated(CourseDto.Consult.class) @RequestBody CourseDto dto) {
        return courseService.findCourseDetails(dto);
    }

    // Mostrar todos los estudiantes con estado 'REGISTERED'
    @PostMapping("/course/registered-students")
    public ResponseEntity<Message> getRegisteredStudents(
            @Validated(CourseDto.Consult.class) @RequestBody CourseDto dto) {
        return courseService.findRegisteredStudents(dto);
    }

    @PutMapping("/course/change-status")
    public ResponseEntity<Message> changeStatus(@Validated(CourseDto.ChangeStatus.class) @RequestBody CourseDto dto) {
        return courseService.changeStatus(dto);
    }

    // Módulo de inscripciones
    // Filtro para usuarios con pago pendiente e inscripción
    @GetMapping("/registration/pending-payment")
    public ResponseEntity<Message> findByPendingPayment() {
        return registrationService.findByPendingPayment();
    }

    // Filtro para usuarios con pago pagado e inscripción pendiente
    @GetMapping("/registration/to-approve")
    public ResponseEntity<Message> findToApprove() {
        return registrationService.findToApprove();
    }

    @PutMapping("/registration/change-status")
    public ResponseEntity<Message> changeStatus(
            @Validated(RegistrationDto.ChangeStatus.class) @RequestBody RegistrationDto dto) {
        return registrationService.changeStatus(dto);
    }

    @PostMapping("/registration/registered-students")
    public ResponseEntity<Message> findByCourse(
            @Validated(CourseDto.Consult.class) @RequestBody CourseDto dto) {
        return registrationService.findByCourse(dto);
    }

    // Módulo de cuentas
    // Obener todas las cuentas activas
    @GetMapping("/account/all")
    public ResponseEntity<Message> findAllActives() {
        return accountService.findAllActives();
    }

    @PostMapping("/account/by-id")
    public ResponseEntity<Message> findById(@Validated(AccountDto.Consult.class) @RequestBody AccountDto dto) {
        return accountService.findById(dto);
    }

    @PostMapping("/account/save")
    public ResponseEntity<Message> save(@Validated(AccountDto.Register.class) @RequestBody AccountDto dto) {
        return accountService.save(dto);
    }

    @PutMapping("/account/update")
    public ResponseEntity<Message> update(@Validated(AccountDto.Modify.class) @RequestBody AccountDto dto) {
        return accountService.update(dto);
    }

    @PutMapping("/account/change-status")
    public ResponseEntity<Message> changeStatus(@Validated(AccountDto.ChangeStatus.class) @RequestBody AccountDto dto) {
        return accountService.changeStatus(dto);
    }

    // Lista todas las reseñas de un curso específico
    @PostMapping("/review/by-course")
    public ResponseEntity<Message> findAllByCourseId(
            @Validated(ReviewDto.FindBycourse.class) @RequestBody ReviewDto dto) {
        return reviewService.findAllByCourseId(dto);
    }

    // Obtiene una reseña específica por su ID
    @PostMapping("/review/by-id")
    public ResponseEntity<Message> findById(
            @Validated(ReviewDto.Consult.class) @RequestBody ReviewDto dto) {
        return reviewService.findById(dto);
    }

    // Retorna todas las reseñas activas (sin filtrar por estado)
    @GetMapping("/review/all")
    public ResponseEntity<Message> findAll() {
        return reviewService.findAllActives();
    }

    /**
     * Endpoint para obtener los pagos pendientes de un estudiante.
     * Se espera que en el DTO se envíe el campo "studentId" con el token o ID correspondiente.
     */
    @PostMapping("/payment/pending")
    public ResponseEntity<Message> findPendingPaymentsByStudent(
            @Validated(PaymentDto.Consult.class) @RequestBody PaymentDto dto) {
        return paymentService.findPendingByStudent(dto);
    }

    /**
     * Endpoint para actualizar la URL de un Payment.
     * Se esperan los campos "paymentId" y "paymentUrl" en el DTO.
     */
    @PutMapping("/payment/update")
    public ResponseEntity<Message> updatePayment(
            @Validated(PaymentDto.Modify.class) @RequestBody PaymentDto dto) {
        return paymentService.updatePayment(dto);
    }

    @GetMapping("/payment/pending/all")
    public ResponseEntity<Message> findAllPendingPayments() {
        return paymentService.findPendingPayments();
    }

    // Obtener todos los pagos aprobados (FINISHED) sin filtrar por estudiante
    @GetMapping("/payment/finished")
    public ResponseEntity<Message> findFinishedPayments() {
        return paymentService.findFinishedPayments();
    }

    @PutMapping("/payment/change-status")
    public ResponseEntity<Message> changePaymentStatus(
            @Validated(PaymentDto.ChangeStatus.class) @RequestBody PaymentDto dto) {
        return paymentService.changePaymentStatus(dto);
    }
}