package com.eduhubpro.eduhubpro.Entity.Review.Model;

import java.time.LocalDate;
import java.util.UUID;

import com.eduhubpro.eduhubpro.Entity.Course.Model.Course;
import com.eduhubpro.eduhubpro.Entity.User.Model.User;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "review")
public class Review {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID reviewId;

    @Column(name = "score", columnDefinition = "INT", nullable = false)
    private int score;

    @Column(name = "description", columnDefinition = "VARCHAR(255)", nullable = false)
    private String description;

    @Column(name = "score_date", columnDefinition = "DATE", nullable = false)
    private LocalDate scoreDate;

    @ManyToOne
    @JoinColumn(name = "student_id", nullable = false)
    private User student;

    @ManyToOne
    @JoinColumn(name = "course_id", nullable = false)
    private Course course;

    @ManyToOne
    @JoinColumn(name = "instructor_id")
    private User instructor;

    public Review() {

    }

    // Para estudiante - curso
    public Review(String description, User student, Course course) {
        this.description = description;
        this.scoreDate = LocalDate.now();
        this.student = student;
        this.course = course;
    }

    // Para estudiante - docente
    public Review(String description, User student, User instructor) {
        this.description = description;
        this.scoreDate = LocalDate.now();
        this.student = student;
        this.instructor = instructor;
    }

    // Curso general
    public Review(String description, int score, User student, User instructor, Course course) {
        this.description = description;
        this.score = score;
        this.scoreDate = LocalDate.now();
        this.student = student;
        this.instructor = instructor;
        this.course = course;
    }

    public UUID getReviewId() {
        return reviewId;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public void setReviewId(UUID reviewId) {
        this.reviewId = reviewId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDate getScoreDate() {
        return scoreDate;
    }

    public void setScoreDate(LocalDate scoreDate) {
        this.scoreDate = scoreDate;
    }

    public User getStudent() {
        return student;
    }

    public void setStudent(User student) {
        this.student = student;
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }

    public User getInstructor() {
        return instructor;
    }

    public void setInstructor(User instructor) {
        this.instructor = instructor;
    }
}
