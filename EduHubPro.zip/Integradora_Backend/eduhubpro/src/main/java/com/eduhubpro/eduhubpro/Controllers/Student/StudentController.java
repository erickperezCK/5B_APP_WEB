package com.eduhubpro.eduhubpro.Controllers.Student;

import com.eduhubpro.eduhubpro.Entity.Account.Service.AccountService;
import com.eduhubpro.eduhubpro.Entity.Attendance.Service.AttendanceService;
import com.eduhubpro.eduhubpro.Entity.Category.Model.CategoryDto;
import com.eduhubpro.eduhubpro.Entity.Category.Service.CategoryService;
import com.eduhubpro.eduhubpro.Entity.Course.Model.CourseDto;
import com.eduhubpro.eduhubpro.Entity.Course.Service.CourseService;
import com.eduhubpro.eduhubpro.Entity.Payment.Model.PaymentDto;
import com.eduhubpro.eduhubpro.Entity.Payment.Service.PaymentService;
import com.eduhubpro.eduhubpro.Entity.Registration.Model.RegistrationDto;
import com.eduhubpro.eduhubpro.Entity.Registration.Service.RegistrationService;
import com.eduhubpro.eduhubpro.Entity.Review.Model.ReviewDto;
import com.eduhubpro.eduhubpro.Entity.Review.Service.ReviewService;
import com.eduhubpro.eduhubpro.Entity.User.Model.UserDto;
import com.eduhubpro.eduhubpro.Entity.User.Service.UserService;
import com.eduhubpro.eduhubpro.Util.Response.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/student")
public class StudentController {

    private final CourseService courseService;
    private final CategoryService categoryService;
    private final UserService userService;
    private final RegistrationService registrationService;
    private final PaymentService paymentService;
    private final ReviewService reviewService;
    private final AccountService accountService;
    private final AttendanceService attendanceService;

    @Autowired
    public StudentController(CourseService courseService, CategoryService categoryService, UserService userService,
                             RegistrationService registrationService, PaymentService paymentService, ReviewService reviewService,
                             AccountService accountService, AttendanceService attendanceService) {
        this.courseService = courseService;
        this.categoryService = categoryService;
        this.userService = userService;
        this.registrationService = registrationService;
        this.paymentService = paymentService;
        this.reviewService = reviewService;
        this.accountService = accountService;
        this.attendanceService = attendanceService;
    }

    // Módulo usuarios
    // Consultar perfil
    @PostMapping("/user/profile")
    public ResponseEntity<Message> findProfile(@Validated(UserDto.Consult.class) @RequestBody UserDto dto) {
        return userService.findProfile(dto);
    }

    // Subir foto de perfil
    @PostMapping("/user/upload-photo")
    public ResponseEntity<Message> uploadProfilePhoto(
            @Validated(UserDto.UploadProfilePhoto.class) @RequestBody UserDto dto) {
        return userService.uploadProfilePhoto(dto);
    }

    // Actualizar perfil
    @PutMapping("/user/update-profile")
    public ResponseEntity<Message> updateProfile(@Validated(UserDto.Modify.class) @RequestBody UserDto dto) {
        return userService.updateProfile(dto);
    }

    @PutMapping("/user/change-status")
    public ResponseEntity<Message> changeStatusUser(@Validated(UserDto.ChangeStatus.class) @RequestBody UserDto dto) {
        return userService.changeStatusStudent(dto);
    }

    @PostMapping("/user/support")
    public ResponseEntity<Message> support(@RequestParam String fullName, @RequestParam String email,
                                           @RequestParam String description) {
        return userService.support(fullName, email, description);
    }

    @GetMapping("/course/all")
    public ResponseEntity<Message> findAllPublished() {
        return courseService.findAllPublished();
    }

    @PostMapping("/course/by-category")
    public ResponseEntity<Message> findCoursesByCategory(
            @Validated(CategoryDto.Consult.class) @RequestBody CategoryDto dto) {
        return courseService.findByCategory(dto);
    }

    @PostMapping("/course/by-id")
    public ResponseEntity<Message> findById(@Validated(CourseDto.Consult.class) @RequestBody CourseDto dto) {
        return courseService.findCourseDetails(dto);
    }

    @PostMapping("/course/in_progress")
    public ResponseEntity<Message> findCoursesInProgressByStudent(
            @Validated(UserDto.Consult.class) @RequestBody UserDto dto) {
        return courseService.findCoursesInProgressByStudent(dto);
    }

    @PostMapping("/course/registered")
    public ResponseEntity<Message> findRegistrationByStudent(
            @Validated(UserDto.Consult.class) @RequestBody UserDto dto) {
        return courseService.findRegistrationByStudent(dto);
    }

    @PostMapping("/registration/create")
    public ResponseEntity<Message> createRegistration(
            @Validated(RegistrationDto.Register.class) @RequestBody RegistrationDto dto) {
        return registrationService.createRegistration(dto);
    }

    @PostMapping("/payment/by-student")
    public ResponseEntity<Message> findPendingByStudent(
            @Validated(PaymentDto.FindByStudent.class) @RequestBody PaymentDto dto) {
        return paymentService.findPendingByStudent(dto);
    }

    @PutMapping("/payment/update-url")
    public ResponseEntity<Message> updatePayment(@Validated(PaymentDto.Modify.class) @RequestBody PaymentDto dto) {
        return paymentService.updatePayment(dto);
    }

    @GetMapping("/category/get-actives")
    public ResponseEntity<Message> findAllActives() {
        return categoryService.findAllActives();
    }

    // Reseñas
    // Crea una reseña validando que el estudiante haya completado el curso
    @PostMapping("/review/create")
    public ResponseEntity<Message> createReview(
            @Validated(ReviewDto.Register.class) @RequestBody ReviewDto dto) {
        return reviewService.createReview(dto);
    }

    // Obtiene una reseña específica por su ID
    @PostMapping("/review/by-id")
    public ResponseEntity<Message> findById(
            @Validated(ReviewDto.Consult.class) @RequestBody ReviewDto dto) {
        return reviewService.findById(dto);
    }

    // Módulo de cuentas
    // Obener todas las cuentas activas
    @GetMapping("/account/all")
    public ResponseEntity<Message> findAll() {
        return accountService.findAllActives();
    }

    // Módulo de asistencia
    // Módulos que incluyen la asistencia y módulos bloqueados
    @PostMapping("/attendance/mod-by-course")
    public ResponseEntity<Message> getModulesWithSections(@RequestParam String courseId, @RequestParam String studentId) {
        return attendanceService.getModulesWithSections(courseId, studentId);
    }

    // Completar un módulo
    @PostMapping("/attendance/complete")
    public ResponseEntity<Message> completeSection(@RequestParam String studentId, @RequestParam String sectionId) {
        return attendanceService.completeSection(studentId, sectionId);
    }

    // Obtener progreso en general
    @GetMapping("/attendance/progress")
    public ResponseEntity<Message> getProgress(@RequestParam String studentId, @RequestParam String courseId) {
        return attendanceService.getProgress(studentId, courseId);
    }
}
