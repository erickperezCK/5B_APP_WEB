package com.eduhubpro.eduhubpro.Util.Services;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.eduhubpro.eduhubpro.Entity.Course.Model.Course;
import com.eduhubpro.eduhubpro.Entity.Course.Model.CourseRepository;
import com.eduhubpro.eduhubpro.Entity.Course.Service.CourseService;
import com.eduhubpro.eduhubpro.Entity.Registration.Model.Registration;
import com.eduhubpro.eduhubpro.Entity.Registration.Model.RegistrationRepository;
import com.eduhubpro.eduhubpro.Entity.User.Model.User;
import com.eduhubpro.eduhubpro.Entity.User.Model.UserRepository;
import com.eduhubpro.eduhubpro.Util.Enum.EntityEnum.CourseStatus;
import com.eduhubpro.eduhubpro.Util.Enum.EntityEnum.RegistrationStatus;

@Component
public class CronJobs {
    private static final Logger logger = LoggerFactory.getLogger(CronJobs.class);

    private final CourseService courseService;
    private final CourseRepository courseRepository;
    private final RegistrationRepository registrationRepository;

    private final UserRepository userRepository;
    private final EmailService emailService;
    private final PdfService pdfService;

    @Autowired
    public CronJobs(UserRepository userRepository, EmailService emailService, PdfService pdfService,
            CourseService courseService, CourseRepository courseRepository,
            RegistrationRepository registrationRepository) {
        this.courseRepository = courseRepository;
        this.registrationRepository = registrationRepository;
        this.userRepository = userRepository;
        this.emailService = emailService;
        this.pdfService = pdfService;
        this.courseService = courseService;
    }

    @Scheduled(cron = "0 * * * * ?")
    public void sayHello() {
        logger.info("Hello World!");
        /*
         * emailService.sendEmail("Constancia", "alanyr107@gmail.com", "Alan", "Laura",
         * "Java", "Hoy", "Mañana");
         * emailService.sendEmail("Constancia", "alanyr107@gmail.com", "Alan", "Java",
         * "Hoy", "Mañana");
         * emailService.sendEmail("Constancia", "alanyr107@gmail.com", "Alan", "Java");
         */
    }

    @Scheduled(cron = "0 0 0 * * ?") // Se ejecuta a las 00:00 cada día
    public void reminderAndFinalizedCourses() {
        publishCoursesStartingToday();
        processFinalizedCourses();
        sendCourseStartReminder();
    }

    @Transactional
    public void publishCoursesStartingToday() {
        LocalDate today = LocalDate.now();

        // Buscar cursos que inician hoy
        List<Course> coursesToPublish = courseRepository.findByStartDateAndCourseStatus(today, CourseStatus.PUBLISHED);

        for (Course course : coursesToPublish) {
            course.setCourseStatus(CourseStatus.IN_PROGRESS);
            courseRepository.saveAndFlush(course);
        }

        if (!coursesToPublish.isEmpty()) {
            logger.info("Se publicaron {} cursos con fecha de inicio: {}", coursesToPublish.size(), today);
        }
    }

    @Transactional
    public void processFinalizedCourses() {
        // Obtener la fecha actual sin hora (solo la fecha)
        LocalDate today = LocalDate.now();

        // Buscar los cursos con estado FINALIZED y fecha de finalización igual a hoy
        List<Course> finalizedCourses = courseRepository.findByCourseStatusAndEndDate(today, CourseStatus.IN_PROGRESS);

        if (finalizedCourses.isEmpty()) {
            logger.info("No se encontraron cursos con estado FINALIZED y fecha de finalización igual a hoy.");
            return;
        }

        // Iterar sobre los cursos encontrados
        for (Course course : finalizedCourses) {
            // Llamar al método changeStatus para enviar las constancias y cambiar el estado
            UUID courseId = course.getCourseId();

            // Llamar al método changeStatus con el ID del curso
            courseService.changeStatus(courseId);
        }
    }

    @Transactional
    public void sendCourseStartReminder() {
        // Obtener la fecha actual
        LocalDate today = LocalDate.now();
        // Calcular la fecha que será en dos días
        LocalDate reminderDate = today.plusDays(1);

        // Buscar cursos con fecha de inicio igual a la fecha de recordatorio
        List<Course> coursesStartingInTwoDays = courseRepository.findByStartDate(reminderDate);

        if (coursesStartingInTwoDays.isEmpty()) {
            logger.info("No hay cursos que comiencen mañana.");
            return;
        }

        // Iterar sobre los cursos encontrados
        for (Course course : coursesStartingInTwoDays) {
            // Obtener todos los usuarios (estudiantes) registrados en el curso
            List<Registration> registrations = registrationRepository.findByCourseAndStatusNotIn(course,
                    Arrays.asList(RegistrationStatus.CANCELED,
                            RegistrationStatus.FINALIZED));

            // Si no hay usuarios registrados en el curso
            if (registrations.isEmpty()) {
                logger.info("No hay usuarios registrados en el curso con ID {}", course.getCourseId());
                continue;
            }

            // Enviar correos a cada estudiante inscrito en el curso
            for (Registration registration : registrations) {
                User student = registration.getStudent();

                // Enviar correo de recordatorio al estudiante
                boolean emailSent = emailService.sendCourseStartReminderStudent(
                        "Recordatorio: El curso está por comenzar",
                        student.getEmail(),
                        student.getName(),
                        course.getTitle(),
                        course.getStartDate().toString());

                boolean emailSent2 = emailService.sendPaymentReminderStudent(
                        "Recordatorio: Recordatorio del pago del curso ",
                        student.getEmail(),
                        student.getName(),
                        course.getTitle(),
                        course.getInstructor().getName(),
                        course.getStartDate().toString(),
                        course.getEndDate().toString(),
                        course.getPrice());

                if (!emailSent && !emailSent2) {
                    logger.error("Error al enviar el recordatorio al usuario {}", student.getName());
                }
            }

            // 2. Enviar recordatorio al instructor
            User instructor = course.getInstructor();
            if (instructor != null) {
                boolean emailToInstructor = emailService.sendCourseStartReminderInstructor(
                        "Recordatorio: El curso está por comenzar",
                        instructor.getEmail(),
                        instructor.getName(),
                        course.getTitle(),
                        course.getStartDate().toString());

                if (!emailToInstructor) {
                    logger.error("Error al enviar el recordatorio al instructor {}", instructor.getName());
                }
            }
        }

        logger.info("Recordatorios de inicio de curso enviados para los cursos que comienzan mañana.");
    }

}