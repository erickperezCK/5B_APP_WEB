package com.eduhubpro.eduhubpro.Util.Enum;

public enum S3Folder {
    PDF,
    PAYMENTS,
    DOCUMENTS,
    PROFILE_PHOTOS
}
