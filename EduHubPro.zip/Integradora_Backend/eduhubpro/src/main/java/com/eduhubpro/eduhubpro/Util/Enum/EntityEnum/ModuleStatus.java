package com.eduhubpro.eduhubpro.Util.Enum.EntityEnum;

public enum ModuleStatus {
    LOCKED,
    UNLOCKED,
    DELETED
}
