package com.eduhubpro.eduhubpro.CloudflareR2;

import java.io.IOException;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.eduhubpro.eduhubpro.Util.Enum.TypesResponse;
import com.eduhubpro.eduhubpro.Util.Response.Message;

import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.DeleteObjectRequest;
import software.amazon.awssdk.services.s3.model.ListObjectsV2Request;
import software.amazon.awssdk.services.s3.model.ListObjectsV2Response;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;
import software.amazon.awssdk.services.s3.model.S3Object;

@Service
public class CloudflareR2Service {

    private final S3Client s3Client;

    @Value("${cloudflare.r2.bucket-name}")
    private String bucketName;

    @Value("${cloudflare.r2.endpoint}")
    private String endpoint;

    @Value("${cloudflare.r2.public-url}")
    private String publicUrl;

    public CloudflareR2Service(S3Client s3Client) {
        this.s3Client = s3Client;
    }

    // Método para subir el archivo y obtener la URL pública
    public String uploadFile(MultipartFile file) {
        try {
            // Generar un nombre único para el archivo
            String fileName = UUID.randomUUID() + "-" + file.getOriginalFilename();

            // Crear la solicitud de subida
            PutObjectRequest putObjectRequest = PutObjectRequest.builder()
                    .bucket(bucketName)
                    .key(fileName)
                    .build();

            // Convertir el archivo a RequestBody
            RequestBody requestBody = RequestBody.fromInputStream(file.getInputStream(), file.getSize());

            // Subir el archivo a Cloudflare R2
            s3Client.putObject(putObjectRequest, requestBody);

            // Generar la URL pública para acceder al archivo
            return "https://" + publicUrl + "/" + fileName;

        } catch (IOException e) {
            throw new RuntimeException("Error al subir archivo", e);
        }
    }

    // Método para eliminar el archivo
    public void deleteFile(String fileName) {
        try {
            // Crear la solicitud de eliminación
            DeleteObjectRequest deleteObjectRequest = DeleteObjectRequest.builder()
                    .bucket(bucketName)
                    .key(fileName)
                    .build();

            // Eliminar el archivo de Cloudflare R2
            s3Client.deleteObject(deleteObjectRequest);
        } catch (Exception e) {
            throw new RuntimeException("Error al eliminar archivo", e);
        }
    }

    // Eliminar todos
    public ResponseEntity<Message> deleteAllObjectsFromS3() {
        try {
            // 1. Obtener todos los objetos del bucket
            ListObjectsV2Request listRequest = ListObjectsV2Request.builder()
                    .bucket(bucketName)
                    .build();

            ListObjectsV2Response listResponse = s3Client.listObjectsV2(listRequest);

            List<S3Object> objects = listResponse.contents();

            if (objects.isEmpty()) {
                return new ResponseEntity<>(
                        new Message("No hay archivos para eliminar", TypesResponse.WARNING),
                        HttpStatus.OK);
            }

            // 2. Iterar y eliminar cada archivo
            for (S3Object obj : objects) {
                DeleteObjectRequest deleteRequest = DeleteObjectRequest.builder()
                        .bucket(bucketName)
                        .key(obj.key())
                        .build();
                s3Client.deleteObject(deleteRequest);
            }

            return new ResponseEntity<>(
                    new Message("Todos los archivos han sido eliminados correctamente", TypesResponse.SUCCESS),
                    HttpStatus.OK);

        } catch (Exception e) {
            return new ResponseEntity<>(
                    new Message("Error al eliminar archivos: " + e.getMessage(), TypesResponse.ERROR),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Solo nombres
    public ResponseEntity<Message> getObjectsFromS3() {
        // Crear la solicitud de listado de objetos
        ListObjectsV2Request listObjects = ListObjectsV2Request.builder()
                .bucket(bucketName) // Nombre del bucket
                .build();

        // Llamar a listObjectsV2 con la solicitud
        ListObjectsV2Response result = s3Client.listObjectsV2(listObjects);

        // Obtener los objetos
        List<S3Object> objects = result.contents();

        // Mapear los objetos a sus nombres de archivo
        List<String> list = objects.stream().map(S3Object::key).collect(Collectors.toList());

        // Devolver la lista de archivos
        return new ResponseEntity<>(new Message(list, "Listado de archivos", TypesResponse.SUCCESS), HttpStatus.OK);
    }

    // Url completa
    public ResponseEntity<Message> getPublicUrlsFromS3() {
        // Crear la solicitud de listado de objetos
        ListObjectsV2Request listObjects = ListObjectsV2Request.builder()
                .bucket(bucketName)
                .build();

        // Obtener la respuesta de Cloudflare R2
        ListObjectsV2Response result = s3Client.listObjectsV2(listObjects);
        List<S3Object> objects = result.contents();

        // Mapear a URLs públicas
        List<String> publicUrls = objects.stream()
                .map(obj -> "https://" + publicUrl + "/" + obj.key())
                .collect(Collectors.toList());

        // Devolver como respuesta
        return new ResponseEntity<>(
                new Message(publicUrls, "Listado de URLs públicas", TypesResponse.SUCCESS),
                HttpStatus.OK);
    }

}
