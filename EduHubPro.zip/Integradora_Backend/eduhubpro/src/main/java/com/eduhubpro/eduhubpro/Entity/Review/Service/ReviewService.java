package com.eduhubpro.eduhubpro.Entity.Review.Service;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.eduhubpro.eduhubpro.Entity.Attendance.Model.Attendance;
import com.eduhubpro.eduhubpro.Entity.Attendance.Model.AttendanceRepository;
import com.eduhubpro.eduhubpro.Entity.Course.Model.Course;
import com.eduhubpro.eduhubpro.Entity.Course.Model.CourseRepository;
import com.eduhubpro.eduhubpro.Entity.Module.Model.ModuleRepository;
import com.eduhubpro.eduhubpro.Entity.Module.Model.Module;
import com.eduhubpro.eduhubpro.Entity.Review.Model.Review;
import com.eduhubpro.eduhubpro.Entity.Review.Model.ReviewDto;
import com.eduhubpro.eduhubpro.Entity.Review.Model.ReviewRepository;
import com.eduhubpro.eduhubpro.Entity.User.Model.User;
import com.eduhubpro.eduhubpro.Entity.User.Model.UserRepository;
import com.eduhubpro.eduhubpro.Security.Jwt.JwtUtil;
import com.eduhubpro.eduhubpro.Util.Enum.TypesResponse;
import com.eduhubpro.eduhubpro.Util.Enum.EntityEnum.CourseStatus;
import com.eduhubpro.eduhubpro.Util.Enum.EntityEnum.UserRole;
import com.eduhubpro.eduhubpro.Util.Response.Message;

@Service
public class ReviewService {

    private static final Logger logger = LoggerFactory.getLogger(ReviewService.class);

    private UserRepository userRepository;
    private ReviewRepository reviewRepository;
    private CourseRepository courseRepository;
    private ModuleRepository moduleRepository;
    private AttendanceRepository attendanceRepository;
    private JwtUtil jwtUtil;

    @Autowired
    public ReviewService(ReviewRepository reviewRepository, UserRepository userRepository,
            CourseRepository courseRepository, ModuleRepository moduleRepository, JwtUtil jwtUtil) {
        this.reviewRepository = reviewRepository;
        this.userRepository = userRepository;
        this.courseRepository = courseRepository;
        this.moduleRepository = moduleRepository;
        this.attendanceRepository = attendanceRepository;
        this.jwtUtil = jwtUtil;
    }

    @Transactional(readOnly = true)
    public ResponseEntity<Message> findAllByCourseId(ReviewDto dto) {
        UUID courseId = UUID.fromString(dto.getCourseId());

        List<Review> reviews = reviewRepository.findByCourseCourseId(courseId);
        if (reviews.isEmpty()) {
            return new ResponseEntity<>(new Message("No se encontraron reseñas para el curso.", TypesResponse.WARNING),
                    HttpStatus.NOT_FOUND);
        }

        logger.info("Reseñas encontradas para el curso con ID {}", courseId);
        return new ResponseEntity<>(
                new Message(reviews, "Listado de reseñas del curso obtenido exitosamente", TypesResponse.SUCCESS),
                HttpStatus.OK);
    }

    @Transactional(readOnly = true)
    public ResponseEntity<Message> findById(ReviewDto dto) {
        UUID reviewId = UUID.fromString(dto.getReviewId());
        Optional<Review> review = reviewRepository.findById(reviewId);

        if (review.isEmpty()) {
            return new ResponseEntity<>(new Message("Reseña no encontrada", TypesResponse.ERROR), HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>(new Message(review.get(), "Reseña encontrada", TypesResponse.SUCCESS),
                HttpStatus.OK);
    }

    @Transactional(readOnly = true)
    public ResponseEntity<Message> findAllActives() {
        List<Review> reviews = reviewRepository.findAll(); // Si manejas estado, podrías filtrar aquí
        if (reviews.isEmpty()) {
            return new ResponseEntity<>(new Message("No hay reseñas para éste curso.", TypesResponse.WARNING),
                    HttpStatus.NOT_FOUND);
        }

        logger.info("Búsqueda de reseñas activas realizada correctamente");
        return new ResponseEntity<>(new Message(reviews, "Listado de reseñas activas", TypesResponse.SUCCESS),
                HttpStatus.OK);
    }

    @Transactional(rollbackFor = { SQLException.class })
    public ResponseEntity<Message> createReview(ReviewDto dto) {
        // Extraer el studentId, courseId e instructorId del DTO
        UUID studentId = UUID.fromString(jwtUtil.extractUserId(dto.getStudentId())); // JWT
        UUID courseId = UUID.fromString(dto.getCourseId());
        UUID instructorId = UUID.fromString(dto.getInstructor_id()); // Instructor del curso

        // Obtener el estudiante, curso e instructor desde la base de datos
        User student = userRepository.findById(studentId)
                .orElseThrow(() -> new IllegalArgumentException("Estudiante no encontrado"));
        Course course = courseRepository.findById(courseId)
                .orElseThrow(() -> new IllegalArgumentException("Curso no encontrado"));
        User instructor = userRepository.findById(instructorId)
                .orElseThrow(() -> new IllegalArgumentException("Instructor no encontrado"));

        // Verificar que el rol sea de estudiante
        if (!student.getRole().equals(UserRole.STUDENT)) {
            return new ResponseEntity<>(
                    new Message("Solo los estudiantes pueden realizar una reseña", TypesResponse.ERROR),
                    HttpStatus.FORBIDDEN);
        }

        // Verificar que el curso haya finalizado
        if (!course.getCourseStatus().equals(CourseStatus.FINALIZED)) {
            return new ResponseEntity<>(new Message("El curso aún no ha finalizado", TypesResponse.ERROR),
                    HttpStatus.BAD_REQUEST);
        }

        // Verificar si el estudiante ha completado todos los módulos
        boolean completedAllModules = true;
        List<Module> modules = moduleRepository.findByCourseOrderByDateAsc(course);
        for (Module module : modules) {
            Optional<Attendance> attendance = attendanceRepository
                    .findByStudentAndCourseAndModule(student, course, module);
            // Verificar que el módulo esté desbloqueado y el estudiante lo haya completado
            if (attendance.isEmpty() || !attendance.get().isUnlocked() || !attendance.get().isAttended()) {
                completedAllModules = false;
                break;
            }
        }

        if (!completedAllModules) {
            return new ResponseEntity<>(
                    new Message("Debes completar todos los módulos del curso para poder evaluar", TypesResponse.ERROR),
                    HttpStatus.BAD_REQUEST);
        }

        // Crear la reseña del curso
        Review courseReview = new Review(dto.getDescription(), dto.getScore() == 0 ? 1 : dto.getScore(), student,
                instructor, course);

        // Guardar reseña
        reviewRepository.saveAndFlush(courseReview);

        return new ResponseEntity<>(
                new Message("Reseña creada exitosamente", TypesResponse.SUCCESS),
                HttpStatus.CREATED);
    }

    @Transactional(rollbackFor = { SQLException.class })
    public ResponseEntity<Message> createReviewForCourse(ReviewDto dto) {
        UUID studentId = UUID.fromString(dto.getStudentId());
        UUID courseId = UUID.fromString(dto.getCourseId());

        User student = userRepository.findById(studentId)
                .orElseThrow(() -> new IllegalArgumentException("Estudiante no encontrado"));
        Course course = courseRepository.findById(courseId)
                .orElseThrow(() -> new IllegalArgumentException("Curso no encontrado"));

        if (!student.getRole().equals(UserRole.STUDENT)) {
            return new ResponseEntity<>(
                    new Message("Solo los estudiantes pueden realizar una reseña", TypesResponse.ERROR),
                    HttpStatus.FORBIDDEN);
        }

        if (!course.getCourseStatus().equals(CourseStatus.FINALIZED)) {
            return new ResponseEntity<>(new Message("El curso aún no ha finalizado", TypesResponse.ERROR),
                    HttpStatus.BAD_REQUEST);
        }

        Review review = new Review(dto.getDescription(), student, course);
        review.setScore(dto.getScore());

        reviewRepository.saveAndFlush(review);

        return new ResponseEntity<>(new Message(review, "Reseña del curso creada exitosamente", TypesResponse.SUCCESS),
                HttpStatus.CREATED);
    }

    @Transactional(rollbackFor = { SQLException.class })
    public ResponseEntity<Message> createReviewForInstructor(ReviewDto dto) {
        UUID studentId = UUID.fromString(dto.getStudentId());
        UUID instructorId = UUID.fromString(jwtUtil.extractUserId(dto.getInstructor_id())); // JWT

        User student = userRepository.findById(studentId)
                .orElseThrow(() -> new IllegalArgumentException("Estudiante no encontrado"));
        User instructor = userRepository.findById(instructorId)
                .orElseThrow(() -> new IllegalArgumentException("Instructor no encontrado"));

        if (!student.getRole().equals(UserRole.STUDENT)) {
            return new ResponseEntity<>(
                    new Message("Solo los estudiantes pueden realizar una reseña", TypesResponse.ERROR),
                    HttpStatus.FORBIDDEN);
        }

        Review review = new Review(dto.getDescription(), student, instructor);
        review.setScore(dto.getScore());

        reviewRepository.saveAndFlush(review);

        return new ResponseEntity<>(
                new Message(review, "Reseña del docente creada exitosamente", TypesResponse.SUCCESS),
                HttpStatus.CREATED);
    }

    @Transactional(rollbackFor = { SQLException.class })
    public ResponseEntity<Message> updateReviewForCourse(ReviewDto dto) {
        UUID reviewId = UUID.fromString(dto.getReviewId());

        Optional<Review> optionalReview = reviewRepository.findById(reviewId);
        if (optionalReview.isEmpty()) {
            return new ResponseEntity<>(new Message("Reseña no encontrada", TypesResponse.ERROR), HttpStatus.NOT_FOUND);
        }

        Review review = optionalReview.get();

        // Validar que la reseña es para un curso
        if (review.getCourse() == null) {
            return new ResponseEntity<>(new Message("La reseña no corresponde a un curso", TypesResponse.ERROR),
                    HttpStatus.BAD_REQUEST);
        }

        review.setDescription(dto.getDescription());
        review.setScore(dto.getScore());
        review.setScoreDate(LocalDate.now());

        reviewRepository.saveAndFlush(review);

        return new ResponseEntity<>(
                new Message(review, "Reseña del curso actualizada con éxito", TypesResponse.SUCCESS), HttpStatus.OK);
    }

    @Transactional(rollbackFor = { SQLException.class })
    public ResponseEntity<Message> updateReviewForInstructor(ReviewDto dto) {
        UUID reviewId = UUID.fromString(dto.getReviewId());

        Optional<Review> optionalReview = reviewRepository.findById(reviewId);
        if (optionalReview.isEmpty()) {
            return new ResponseEntity<>(new Message("Reseña no encontrada", TypesResponse.ERROR), HttpStatus.NOT_FOUND);
        }

        Review review = optionalReview.get();

        // Validar que la reseña es para un docente
        if (review.getInstructor() == null) {
            return new ResponseEntity<>(new Message("La reseña no corresponde a un docente", TypesResponse.ERROR),
                    HttpStatus.BAD_REQUEST);
        }

        review.setDescription(dto.getDescription());
        review.setScore(dto.getScore());
        review.setScoreDate(LocalDate.now());

        reviewRepository.saveAndFlush(review);

        return new ResponseEntity<>(
                new Message(review, "Reseña del docente actualizada con éxito", TypesResponse.SUCCESS), HttpStatus.OK);
    }

}
