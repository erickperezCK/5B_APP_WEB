package com.eduhubpro.eduhubpro.Util.Enum.EntityEnum;

public enum Status {
    ACTIVE,
    INACTIVE
}