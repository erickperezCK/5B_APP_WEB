package com.eduhubpro.eduhubpro.Util.Enum.EntityEnum;

public enum CourseStatus {
    INACTIVE,
    IN_EDITION,
    TO_APPROVE,
    NOT_APPROVED,
    PUBLISHED,
    IN_PROGRESS,
    FINALIZED
}