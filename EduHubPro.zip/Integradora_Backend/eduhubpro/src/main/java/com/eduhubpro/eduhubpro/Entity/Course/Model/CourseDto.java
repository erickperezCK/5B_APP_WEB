package com.eduhubpro.eduhubpro.Entity.Course.Model;

import java.time.LocalDate;
import java.util.List;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;
import jakarta.validation.constraints.Size;

public class CourseDto {

    @NotBlank(groups = { Modify.class, ChangeStatus.class, Consult.class }, message = "El id no puede ser nulo.")
    private String courseId;

    @NotBlank(groups = { Register.class, Modify.class }, message = "El título no puede ser nulo.")
    @Size(groups = { Register.class, Modify.class }, max = 100, message = "El título no puede exceder 100 caracteres.")
    private String title;

    @NotBlank(groups = { Register.class, Modify.class }, message = "La descripción no puede ser nula.")
    @Size(groups = { Register.class,
            Modify.class }, max = 255, message = "La descripción de perfil no puede exceder 255 caracteres.")
    private String description;

    @NotBlank(groups = { Register.class, Modify.class }, message = "No pudimos cargar la portada del curso.")
    @Size(groups = { Register.class, Modify.class }, max = 255, message = "La portada no puede exceder 255 caracteres.")
    private String bannerPath;

    @FutureOrPresent(groups = { Register.class, Modify.class,
            ConsultDate.class }, message = "La fecha de inicio no puede ser anterior a la actual.")
    @NotNull(groups = { Register.class, Modify.class,
            ConsultDate.class }, message = "La fecha de inicio no puede ser nula.")
    private LocalDate startDate;

    @FutureOrPresent(groups = { Register.class,
            Modify.class }, message = "La fecha de fin no puede ser anterior a la actual.")
    @NotNull(groups = { Register.class, Modify.class }, message = "La fecha de fin no puede ser nula.")
    private LocalDate endDate;

    @NotNull(groups = { Register.class, Modify.class }, message = "El precio no puede ser nulo.")
    @DecimalMin(value = "0.0", inclusive = true, message = "El precio debe ser igual o mayor a cero.")
    private double price;

    @NotNull(groups = { Register.class, Modify.class }, message = "El tamaño del curso no puede ser nulo.")
    @PositiveOrZero(groups = { Register.class, Modify.class }, message = "El tamaño del curso debe ser mayor a cero.")
    private int size;

    @NotBlank(groups = { ChangeStatus.class }, message = "El estado no puede ser nulo.")
    private String courseStatus;

    @NotBlank(groups = { Register.class, ConsultFromInstructor.class }, message = "El instructor no puede ser nulo.")
    private String instructorId; // También se utiliza para las búsquedas por docente

    @NotNull(groups = { Register.class, Modify.class }, message = "Las categorías no pueden ser nulas.")
    @Size(min = 1, message = "Debes seleccionar al menos una categoría.")
    private List<String> categoriesId;

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getBannerPath() {
        return bannerPath;
    }

    public void setBannerPath(String bannerPath) {
        this.bannerPath = bannerPath;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public String getCourseStatus() {
        return courseStatus;
    }

    public void setCourseStatus(String courseStatus) {
        this.courseStatus = courseStatus;
    }

    public String getInstructorId() {
        return instructorId;
    }

    public void setInstructorId(String instructorId) {
        this.instructorId = instructorId;
    }

    public List<String> getCategoriesId() {
        return categoriesId;
    }

    public void setCategoriesId(List<String> categoriesId) {
        this.categoriesId = categoriesId;
    }

    public interface Register {
    }

    public interface Modify {
    }

    public interface ChangeStatus {
    }

    public interface Consult {
    }

    public interface ConsultFromInstructor {
    }

    public interface ConsultDate {
    }
}
