package com.eduhubpro.eduhubpro.Entity.User.Service;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.eduhubpro.eduhubpro.Entity.Course.Model.Course;
import com.eduhubpro.eduhubpro.Entity.Course.Model.CourseRepository;
import com.eduhubpro.eduhubpro.Entity.Registration.Model.Registration;
import com.eduhubpro.eduhubpro.Entity.Registration.Model.RegistrationRepository;
import com.eduhubpro.eduhubpro.Entity.User.Model.User;
import com.eduhubpro.eduhubpro.Entity.User.Model.UserDto;
import com.eduhubpro.eduhubpro.Entity.User.Model.UserRepository;
import com.eduhubpro.eduhubpro.Security.Jwt.JwtUtil;
import com.eduhubpro.eduhubpro.Util.Enum.TypesResponse;
import com.eduhubpro.eduhubpro.Util.Enum.EntityEnum.CourseStatus;
import com.eduhubpro.eduhubpro.Util.Enum.EntityEnum.RegistrationStatus;
import com.eduhubpro.eduhubpro.Util.Enum.EntityEnum.Status;
import com.eduhubpro.eduhubpro.Util.Enum.EntityEnum.UserRole;
import com.eduhubpro.eduhubpro.Util.Response.Message;
import com.eduhubpro.eduhubpro.Util.Services.EmailService;

@Service
public class UserService {

        private static final Logger logger = LoggerFactory.getLogger(UserService.class);

        private final UserRepository userRepository;
        private final PasswordEncoder passwordEncoder;
        private final CourseRepository courseRepository;
        private final RegistrationRepository registrationRepository;

        private final EmailService emailService;
        private final JwtUtil jwtUtil;

        @Autowired
        public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder,
                        CourseRepository courseRepository, RegistrationRepository registrationRepository,
                        JwtUtil jwtUtil, EmailService emailService) {
                this.userRepository = userRepository;
                this.passwordEncoder = passwordEncoder;
                this.courseRepository = courseRepository;
                this.registrationRepository = registrationRepository;
                this.jwtUtil = jwtUtil;
                this.emailService = emailService;
        }

        // --------------------------------------------
        // ADMIN
        // Analíticas
        @Transactional(readOnly = true)
        public ResponseEntity<Message> countAllUsers() {
                Long totalStudents = userRepository.countAllUsers(UserRole.STUDENT, Status.ACTIVE);
                Long totalInstructors = userRepository.countAllUsers(UserRole.INSTRUCTOR, Status.ACTIVE);
                Long totalCourses = courseRepository
                                .countCourses(Arrays.asList(CourseStatus.PUBLISHED, CourseStatus.IN_PROGRESS));

                // Fecha de corte (7 días atrás)
                LocalDate oneWeekAgo = LocalDate.now().minusDays(7);
                // Consulta a los usuarios nuevos
                Long newUsers = userRepository.countNewUsers(oneWeekAgo, Status.ACTIVE, UserRole.STUDENT);

                Map<String, Object> analytics = new HashMap<>();

                analytics.put("totalStudents", totalStudents);
                analytics.put("newStudents", newUsers);
                analytics.put("totalInstructors", totalInstructors);
                analytics.put("totalCourses", totalCourses);

                logger.info("Conteo de usuarios realizada correctamente");
                return new ResponseEntity<>(
                                new Message(analytics, "Conteo de usuarios y cursos", TypesResponse.SUCCESS),
                                HttpStatus.OK);
        }

        // Consultar todos los usuarios
        @Transactional(readOnly = true)
        public ResponseEntity<Message> findAllForAdmin() {
                List<User> users = userRepository.findAllByRole(Arrays.asList(UserRole.INSTRUCTOR, UserRole.STUDENT),
                                Status.ACTIVE);
                logger.info("La búsqueda de usuarios ha sido realizada correctamente");
                return new ResponseEntity<>(new Message(users, "Listado de usuarios", TypesResponse.SUCCESS),
                                HttpStatus.OK);
        }

        // --------------------------------------------
        // Para consultar perfiles por el admin
        @Transactional(readOnly = true)
        public ResponseEntity<Message> findById(UserDto dto) {
                UUID uuid = UUID.fromString(dto.getUserId());
                Optional<User> optionalUser = userRepository.findById(uuid);
                if (optionalUser.isEmpty()) {
                        return new ResponseEntity<>(
                                        new Message("No se encontró la información del perfil", TypesResponse.ERROR),
                                        HttpStatus.NOT_FOUND);
                }
                User user = optionalUser.get();
                logger.info("La búsqueda del usuario ha sido realizada correctamente");
                return new ResponseEntity<>(
                                new Message(user, "Información del perfil encontrada exitosamente",
                                                TypesResponse.SUCCESS),
                                HttpStatus.OK);
        }

        // --------------------------------------------
        // Consul perfil mediante el jwt
        @Transactional(readOnly = true)
        public ResponseEntity<Message> findProfile(UserDto dto) {
                // El token ya contiene el ID
                UUID userId = UUID.fromString(jwtUtil.extractUserId(dto.getUserId()));

                Optional<User> optionalUser = userRepository.findById(userId);
                if (optionalUser.isEmpty()) {
                        return new ResponseEntity<>(
                                        new Message("No se encontró el perfil del usuario.", TypesResponse.ERROR),
                                        HttpStatus.NOT_FOUND);
                }

                User user = optionalUser.get();
                logger.info("Perfil del usuario encontrado correctamente.");

                return new ResponseEntity<>(
                                new Message(user, "Perfil del usuario encontrado correctamente.",
                                                TypesResponse.SUCCESS),
                                HttpStatus.OK);
        }

        // --------------------------------------------
        // Crear usuarios por el admin o registrarse
        @Transactional(rollbackFor = { SQLException.class })
        public ResponseEntity<Message> createUser(UserDto dto) {
                Optional<User> optionalUser = userRepository.findByEmail(dto.getEmail());
                if (optionalUser.isPresent()) {
                        return new ResponseEntity<>(
                                        new Message("El correo electrónico proporcionado ya está en uso por otro usuario",
                                                        TypesResponse.WARNING),
                                        HttpStatus.BAD_REQUEST);
                }

                if (UserRole.valueOf(dto.getRole()).equals(UserRole.ADMIN)) {
                        return new ResponseEntity<>(
                                        new Message("El rol del usuario no puede ser administrador",
                                                        TypesResponse.WARNING),
                                        HttpStatus.BAD_REQUEST);
                }

                String hashPassword = passwordEncoder.encode(dto.getPassword());
                User user = new User(dto.getName(), dto.getEmail(), hashPassword, UserRole.valueOf(dto.getRole()));

                user = userRepository.saveAndFlush(user);

                if (user == null) {
                        return new ResponseEntity<>(
                                        new Message("No se pudo registrar la información", TypesResponse.ERROR),
                                        HttpStatus.INTERNAL_SERVER_ERROR);
                }
                logger.info("El registro ha sido realizado correctamente");
                return new ResponseEntity<>(
                                new Message(user, "Usuario registrado correctamente", TypesResponse.SUCCESS),
                                HttpStatus.OK);
        }

        @Transactional(rollbackFor = { SQLException.class })
        public ResponseEntity<Message> createUserForAdmin(UserDto dto) {
                Optional<User> optionalUser = userRepository.findByEmail(dto.getEmail());
                if (optionalUser.isPresent()) {
                        return new ResponseEntity<>(
                                        new Message("El correo electrónico proporcionado ya está en uso por otro usuario",
                                                        TypesResponse.WARNING),
                                        HttpStatus.BAD_REQUEST);
                }

                if (UserRole.valueOf(dto.getRole()).equals(UserRole.ADMIN)) {
                        return new ResponseEntity<>(
                                        new Message("El rol del usuario no puede ser administrador",
                                                        TypesResponse.WARNING),
                                        HttpStatus.BAD_REQUEST);
                }

                String hashPassword = passwordEncoder.encode(dto.getPassword());
                User user = new User(dto.getName(), dto.getEmail(), hashPassword, UserRole.valueOf(dto.getRole()));

                user = userRepository.saveAndFlush(user);

                if (user == null) {
                        return new ResponseEntity<>(
                                        new Message("No se pudo registrar la información", TypesResponse.ERROR),
                                        HttpStatus.INTERNAL_SERVER_ERROR);
                }

                // Devuelve un boolean
                emailService.sendCredentials("Credenciales del sistema EduHubPro", dto.getEmail(), dto.getName(),
                                dto.getPassword());

                logger.info("El registro ha sido realizado correctamente");
                return new ResponseEntity<>(
                                new Message(user, "Usuario registrado correctamente", TypesResponse.SUCCESS),
                                HttpStatus.OK);
        }

        // -------------------------------------------- todo implementar el servicio de
        // b2 para guardar la foto del perfil
        // Editar perfil para todos
        @Transactional(rollbackFor = { SQLException.class })
        public ResponseEntity<Message> updateProfile(UserDto dto) {
                UUID uuid = UUID.fromString(jwtUtil.extractUserId(dto.getUserId()));
                Optional<User> optionalUser = userRepository.findById(uuid);

                if (optionalUser.isEmpty()) {
                        return new ResponseEntity<>(
                                        new Message("No se pudo encontrar el perfil a editar", TypesResponse.ERROR),
                                        HttpStatus.NOT_FOUND);
                }
                if (dto.getPassword().isEmpty()) {
                        return new ResponseEntity<>(
                                        new Message("La contraseña no puede estar vacía", TypesResponse.WARNING),
                                        HttpStatus.BAD_REQUEST);
                }
                User user = optionalUser.get();

                String newEmail = dto.getEmail().trim(); // Correo nuevo
                String currentEmail = user.getEmail().trim(); // Correo del usuario actualmente

                // Si el usuario quiere cambiar su correo
                if (!newEmail.equalsIgnoreCase(currentEmail)) {
                        // Mandar el nuevo correo e id del usuario encontrado anteriormente
                        Optional<String> duplicateEmail = userRepository.findDuplicateEmail(newEmail, user.getUserId());

                        // Sí se encontró el correo
                        if (duplicateEmail.isPresent()) {
                                return new ResponseEntity<>(
                                                new Message("El correo electrónico proporcionado ya está en uso por otro usuario",
                                                                TypesResponse.WARNING),
                                                HttpStatus.BAD_REQUEST);
                        }
                }

                if (dto.getPassword().length() != 60) {
                        if (dto.getPassword().length() < 8 || dto.getPassword().length() > 20) {
                                return new ResponseEntity<>(
                                                new Message("La contraseña debe tener entre 8 y 20 caracteres",
                                                                TypesResponse.WARNING),
                                                HttpStatus.BAD_REQUEST);
                        }
                        String passwordToMatch = "(?=.*[A-Z])(?=.*\\d).{8,20}";
                        if (!dto.getPassword().matches(passwordToMatch)) {
                                return new ResponseEntity<>(new Message(
                                                "La contraseña debe tener al menos 8 caracteres, incluir una letra mayúscula y un número",
                                                TypesResponse.WARNING), HttpStatus.BAD_REQUEST);
                        }
                        user.setPassword(passwordEncoder.encode(dto.getPassword()));
                }

                user.setName(dto.getName());
                user.setEmail(newEmail);
                user.setProfilePhotoPath(dto.getProfilePhotoPath());
                // user.setDescription(dto.getDescription());

                user = userRepository.saveAndFlush(user);
                if (user == null) {
                        return new ResponseEntity<>(
                                        new Message("Error al editar la información del perfil", TypesResponse.ERROR),
                                        HttpStatus.BAD_REQUEST);
                }
                logger.info("Información del perfil del usuario editada exitósamente");
                return new ResponseEntity<>(new Message(user, "Perfil editado exitósamente", TypesResponse.SUCCESS),
                                HttpStatus.OK);
        }

        // --------------------------------------------
        // Actualizar foto de perfil al registrarse
        @Transactional(rollbackFor = { SQLException.class })
        public ResponseEntity<Message> uploadProfilePhoto(UserDto dto) {
                UUID userId = UUID.fromString(jwtUtil.extractUserId(dto.getUserId()));

                Optional<User> optionalUser = userRepository.findById(userId);
                if (optionalUser.isEmpty()) {
                        return new ResponseEntity<>(
                                        new Message("El usuario no fue encontrado", TypesResponse.WARNING),
                                        HttpStatus.NOT_FOUND);
                }

                User user = optionalUser.get();
                user.setProfilePhotoPath(dto.getProfilePhotoPath());
                userRepository.saveAndFlush(user);

                logger.info("Foto de perfil actualizada correctamente para el usuario con ID: {}", userId);

                return new ResponseEntity<>(
                                new Message(user, "Foto de perfil actualizada correctamente", TypesResponse.SUCCESS),
                                HttpStatus.OK);
        }

        // --------------------------------------------
        // todo la contraseña se pasara
        // como parametro en el json al mostrar el usuario y al llegar a este método
        // debe llegar encriptada asi como viene en el objeto al mostrar el usaurio
        // Actualizar usuarios por el admin
        @Transactional(rollbackFor = { SQLException.class })
        public ResponseEntity<Message> updateForAdmin(UserDto dto) {
                UUID uuid = UUID.fromString(dto.getUserId());
                Optional<User> optionalUser = userRepository.findById(uuid);

                if (optionalUser.isEmpty()) {
                        return new ResponseEntity<>(new Message("Usuario no encontrado", TypesResponse.ERROR),
                                        HttpStatus.NOT_FOUND);
                }
                if (dto.getPassword().isEmpty()) {
                        return new ResponseEntity<>(
                                        new Message("La contraseña no puede estar vacía", TypesResponse.WARNING),
                                        HttpStatus.BAD_REQUEST);
                }

                User user = optionalUser.get();

                String newEmail = dto.getEmail().trim(); // Correo nuevo
                String currentEmail = user.getEmail().trim(); // Correo del usuario actualmente

                // Si el usuario quiere cambiar su correo
                if (!newEmail.equalsIgnoreCase(currentEmail)) {
                        // Mandar el nuevo correo e id del usuario encontrado anteriormente
                        Optional<String> duplicateEmail = userRepository.findDuplicateEmail(newEmail, user.getUserId());
                        // Sí se encontró el correo
                        if (duplicateEmail.isPresent()) {
                                return new ResponseEntity<>(
                                                new Message("El correo electrónico proporcionado ya está en uso por otro usuario",
                                                                TypesResponse.WARNING),
                                                HttpStatus.BAD_REQUEST);
                        }
                }

                if (dto.getPassword().length() != 60) {
                        if (dto.getPassword().length() < 8 || dto.getPassword().length() > 20) {
                                return new ResponseEntity<>(
                                                new Message("La contraseña debe tener entre 8 y 20 caracteres",
                                                                TypesResponse.WARNING),
                                                HttpStatus.BAD_REQUEST);
                        }
                        String passwordToMatch = "(?=.*[A-Z])(?=.*\\d).{8,20}";
                        if (!dto.getPassword().matches(passwordToMatch)) {
                                return new ResponseEntity<>(new Message(
                                                "La contraseña debe tener al menos 8 caracteres, incluir una letra mayúscula y un número",
                                                TypesResponse.WARNING), HttpStatus.BAD_REQUEST);
                        }
                        user.setPassword(passwordEncoder.encode(dto.getPassword()));
                        emailService.resendCredentials("Cambio de credenciales", user.getEmail(), user.getName(),
                                        dto.getPassword());
                }

                user.setName(dto.getName());
                user.setEmail(newEmail);

                user = userRepository.saveAndFlush(user);
                if (user == null) {
                        return new ResponseEntity<>(
                                        new Message("Error al editar la información del usuario", TypesResponse.ERROR),
                                        HttpStatus.BAD_REQUEST);
                }

                logger.info("La actualización del usuario por el admin ha sido realizada correctamente");
                return new ResponseEntity<>(
                                new Message(user, "Información del usuario editada exitósamente",
                                                TypesResponse.SUCCESS),
                                HttpStatus.OK);
        }

        // --------------------------------------------
        // Cambiar el estado de instructores por el admin
        @Transactional(rollbackFor = { SQLException.class })
        public ResponseEntity<Message> changeStatusInstructorForAdmin(UserDto dto) {

                UUID uuid = UUID.fromString(dto.getUserId());

                Optional<User> optionalUser = userRepository.findById(uuid);

                if (optionalUser.isEmpty()) {
                        return new ResponseEntity<>(new Message("No se encontró la cuenta", TypesResponse.ERROR),
                                        HttpStatus.NOT_FOUND);
                }

                User user = optionalUser.get();

                // Obtener los cursos no finalizados del usuario
                List<Course> courses = courseRepository.findAllNotFinalizedCourses(user.getUserId(),
                                CourseStatus.FINALIZED);

                // Verificar si el usuario tiene cursos no finalizados
                if (!courses.isEmpty()) {
                        boolean allCoursesFinalized = courses.stream()
                                        .allMatch(course -> course.getCourseStatus() == CourseStatus.FINALIZED);
                        if (!allCoursesFinalized) {
                                logger.info("El docente tiene cursos que no están finalizados.");
                                return new ResponseEntity<>(
                                                new Message("La cuenta tiene cursos no finalizados",
                                                                TypesResponse.WARNING),
                                                HttpStatus.BAD_REQUEST);
                        }
                }

                user.setStatus(dto.getStatus());
                user.setEmail("");
                userRepository.saveAndFlush(user);
                logger.info("El estado del docente ha sido actualizado correctamente");

                return new ResponseEntity<>(
                                new Message(user, "Se cambió el estado de la cuenta correctamente",
                                                TypesResponse.SUCCESS),
                                HttpStatus.OK);
        }

        // --------------------------------------------
        // Cambiar el estado del estudiante por el admin
        @Transactional(rollbackFor = { SQLException.class })
        public ResponseEntity<Message> changeStatusStudentForAdmin(UserDto dto) {

                UUID uuid = UUID.fromString(dto.getUserId());

                Optional<User> optionalUser = userRepository.findById(uuid);

                if (optionalUser.isEmpty()) {
                        return new ResponseEntity<>(new Message("No se encontró la cuenta", TypesResponse.ERROR),
                                        HttpStatus.NOT_FOUND);
                }

                User user = optionalUser.get();

                // Obtener los cursos no finalizados del usuario
                List<Registration> registrations = registrationRepository.findAllNotFinalizedCourses(user.getUserId(),
                                RegistrationStatus.FINALIZED);

                // Verificar si el usuario tiene cursos no finalizados
                if (!registrations.isEmpty()) {
                        boolean allCoursesFinalized = registrations.stream()
                                        .allMatch(registration -> registration
                                                        .getRegistrationStatus() == RegistrationStatus.FINALIZED);
                        if (!allCoursesFinalized) {
                                logger.info("El estudiante tiene cursos que no están finalizados.");
                                return new ResponseEntity<>(
                                                new Message("La cuenta tiene cursos no finalizados",
                                                                TypesResponse.WARNING),
                                                HttpStatus.BAD_REQUEST);
                        }
                }

                user.setStatus(dto.getStatus());
                user.setEmail("");
                userRepository.saveAndFlush(user);
                logger.info("El estado del estudiante ha sido actualizado correctamente");

                return new ResponseEntity<>(
                                new Message(user, "Se cambió el estado de la cuenta correctamente",
                                                TypesResponse.SUCCESS),
                                HttpStatus.OK);
        }

        // --------------------------------------------
        // Cambiar el estado de instructores por el mismo
        @Transactional(rollbackFor = { SQLException.class })
        public ResponseEntity<Message> changeStatusInstructor(UserDto dto) {
                UUID uuid = UUID.fromString(jwtUtil.extractUserId(dto.getUserId()));
                Optional<User> optionalUser = userRepository.findById(uuid);

                if (optionalUser.isEmpty()) {
                        return new ResponseEntity<>(new Message("No se encontró la cuenta", TypesResponse.ERROR),
                                        HttpStatus.NOT_FOUND);
                }

                User user = optionalUser.get();

                if (user.getRole() != UserRole.INSTRUCTOR) {
                        logger.info("El usuario no es un docente.");
                        return new ResponseEntity<>(
                                        new Message("La cuenta no es de tipo docente", TypesResponse.WARNING),
                                        HttpStatus.BAD_REQUEST);
                }

                // Obtener los cursos no finalizados del usuario
                List<Course> courses = courseRepository.findAllNotFinalizedCourses(user.getUserId(),
                                CourseStatus.FINALIZED);

                // Verificar si el usuario tiene cursos no finalizados
                if (!courses.isEmpty()) {
                        boolean allCoursesFinalized = courses.stream()
                                        .allMatch(course -> course.getCourseStatus() == CourseStatus.FINALIZED);
                        if (!allCoursesFinalized) {
                                logger.info("El docente tiene cursos que no están finalizados.");
                                return new ResponseEntity<>(
                                                new Message("La cuenta tiene cursos no finalizados",
                                                                TypesResponse.WARNING),
                                                HttpStatus.BAD_REQUEST);
                        }
                }

                user.setStatus(dto.getStatus());
                user.setEmail("");
                userRepository.saveAndFlush(user);
                logger.info("El estado del docente ha sido actualizado correctamente");

                return new ResponseEntity<>(
                                new Message(user, "Se cambió el estado de la cuenta correctamente",
                                                TypesResponse.SUCCESS),
                                HttpStatus.OK);
        }

        // --------------------------------------------
        // Cambiar el estado del estudiante por el estudiante
        @Transactional(rollbackFor = { SQLException.class })
        public ResponseEntity<Message> changeStatusStudent(UserDto dto) {
                UUID uuid = UUID.fromString(jwtUtil.extractUserId(dto.getUserId()));
                Optional<User> optionalUser = userRepository.findById(uuid);

                if (optionalUser.isEmpty()) {
                        return new ResponseEntity<>(new Message("No se encontró la cuenta", TypesResponse.ERROR),
                                        HttpStatus.NOT_FOUND);
                }

                User user = optionalUser.get();

                if (user.getRole() != UserRole.STUDENT) {
                        logger.info("El usuario no es un estudiante.");
                        return new ResponseEntity<>(
                                        new Message("La cuenta no es de tipo estudiante", TypesResponse.WARNING),
                                        HttpStatus.BAD_REQUEST);
                }

                // Obtener los cursos no finalizados del usuario
                List<Registration> registrations = registrationRepository.findAllNotFinalizedCourses(user.getUserId(),
                                RegistrationStatus.FINALIZED);

                // Verificar si el usuario tiene cursos no finalizados
                if (!registrations.isEmpty()) {
                        boolean allCoursesFinalized = registrations.stream()
                                        .allMatch(registration -> registration
                                                        .getRegistrationStatus() == RegistrationStatus.FINALIZED);
                        if (!allCoursesFinalized) {
                                logger.info("La cuenta tiene cursos no finalizados");
                                return new ResponseEntity<>(
                                                new Message("La cuenta tiene cursos no finalizados",
                                                                TypesResponse.WARNING),
                                                HttpStatus.BAD_REQUEST);
                        }
                }

                user.setStatus(dto.getStatus());
                user.setEmail("");
                userRepository.saveAndFlush(user);
                logger.info("Se cambió el estado de la cuenta correctamente");

                return new ResponseEntity<>(
                                new Message(user, "Se cambió el estado de la cuenta correctamente",
                                                TypesResponse.SUCCESS),
                                HttpStatus.OK);
        }

        // --------------------------------------------
        @Transactional(rollbackFor = { SQLException.class })
        public ResponseEntity<Message> requestPasswordReset(UserDto dto) {
                Optional<User> optionalUser = userRepository.findByEmail(dto.getEmail());

                if (optionalUser.isEmpty()) {
                        return new ResponseEntity<>(
                                        new Message("El correo proporcionado no existe.", TypesResponse.ERROR),
                                        HttpStatus.NOT_FOUND);
                }
                String characters = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
                StringBuilder codeBuilder = new StringBuilder(255);
                for (int i = 0; i < 255; i++) {
                        int index = ThreadLocalRandom.current().nextInt(characters.length());
                        codeBuilder.append(characters.charAt(index));
                }

                String code = codeBuilder.toString();
                User user = optionalUser.get();
                user.setCode(code);
                userRepository.saveAndFlush(user);

                if (!emailService.sendCode("Recuperación de contraseña", user.getName(), user.getEmail(), code)) {
                        return new ResponseEntity<>(
                                        new Message("No se pudo enviar el código de verificación. Inténtalo de nuevo.",
                                                        TypesResponse.ERROR),
                                        HttpStatus.INTERNAL_SERVER_ERROR);
                }
                return new ResponseEntity<>(
                                new Message(user,
                                                "Código de recuperación enviado exitosamente a tu correo.",
                                                TypesResponse.SUCCESS),
                                HttpStatus.OK);
        }

        // --------------------------------------------
        @Transactional(rollbackFor = { SQLException.class })
        public ResponseEntity<Message> requestPasswordResetStudent(UserDto dto) {
                Optional<User> optionalUser = userRepository.findByEmail(dto.getEmail());

                if (optionalUser.isEmpty()) {
                        return new ResponseEntity<>(
                                        new Message("El correo proporcionado no existe.", TypesResponse.ERROR),
                                        HttpStatus.NOT_FOUND);
                }

                User user = optionalUser.get();
                if (user.getRole() != UserRole.STUDENT) {
                        return new ResponseEntity<>(
                                        new Message("Solo se permite la recuperación a estudiantes.",
                                                        TypesResponse.ERROR),
                                        HttpStatus.BAD_REQUEST);
                }

                String characters = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
                StringBuilder codeBuilder = new StringBuilder(255);
                for (int i = 0; i < 255; i++) {
                        int index = ThreadLocalRandom.current().nextInt(characters.length());
                        codeBuilder.append(characters.charAt(index));
                }

                String code = codeBuilder.toString();
                user.setCode(code);
                userRepository.saveAndFlush(user);

                if (!emailService.sendCode("Recuperación de contraseña", user.getName(), user.getEmail(), code)) {
                        return new ResponseEntity<>(
                                        new Message("No se pudo enviar el código de verificación. Inténtalo de nuevo.",
                                                        TypesResponse.ERROR),
                                        HttpStatus.INTERNAL_SERVER_ERROR);
                }
                return new ResponseEntity<>(
                                new Message(user,
                                                "Código de recuperación enviado exitosamente a tu correo.",
                                                TypesResponse.SUCCESS),
                                HttpStatus.OK);
        }

        // --------------------------------------------
        @Transactional(rollbackFor = { SQLException.class })
        public ResponseEntity<Message> resetPassword(UserDto dto) {
                Optional<User> optionalUser = userRepository.findByCodeAndEmail(dto.getCode(), dto.getEmail());

                if (optionalUser.isEmpty()) {
                        return new ResponseEntity<>(
                                        new Message("El código proporcionado no existe", TypesResponse.ERROR),
                                        HttpStatus.NOT_FOUND);
                }

                User user = optionalUser.get();
                String hashedPassword = passwordEncoder.encode(dto.getPassword());

                user.setPassword(hashedPassword);
                user.setCode("");
                userRepository.saveAndFlush(user);

                return new ResponseEntity<>(
                                new Message("Contraseña restablecida correctamente, inicia sesión.",
                                                TypesResponse.SUCCESS),
                                HttpStatus.OK);
        }

        // Soporte técnico
        @Transactional(rollbackFor = { SQLException.class })
        public ResponseEntity<Message> support(String fullName, String email, String description) {

                if (fullName == null || fullName.trim().isEmpty()) {
                        return new ResponseEntity<>(
                                        new Message("El nombre no puede estar vacío.", TypesResponse.WARNING),
                                        HttpStatus.BAD_REQUEST);
                }

                if (email == null || email.trim().isEmpty()) {
                        return new ResponseEntity<>(
                                        new Message("El correo electrónico no puede estar vacío.",
                                                        TypesResponse.WARNING),
                                        HttpStatus.BAD_REQUEST);
                }

                if (description == null || description.trim().isEmpty()) {
                        return new ResponseEntity<>(
                                        new Message("El comentario no puede estar vacío.",
                                                        TypesResponse.WARNING),
                                        HttpStatus.BAD_REQUEST);
                }

                boolean sent = emailService.support("Solicitud de soporte técnico", email, fullName, description);

                if (!sent) {
                        return new ResponseEntity<>(
                                        new Message("No se pudo enviar el mensaje.", TypesResponse.ERROR),
                                        HttpStatus.INTERNAL_SERVER_ERROR);
                }

                logger.info("Mensaje enviado exitósamente {}", email);
                return new ResponseEntity<>(
                                new Message("Mensaje enviado exitósamente.", TypesResponse.SUCCESS),
                                HttpStatus.OK);
        }
}