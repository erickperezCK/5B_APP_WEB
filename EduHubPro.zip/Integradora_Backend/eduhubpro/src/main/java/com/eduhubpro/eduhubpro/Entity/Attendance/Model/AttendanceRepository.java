package com.eduhubpro.eduhubpro.Entity.Attendance.Model;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.eduhubpro.eduhubpro.Entity.Course.Model.Course;
import com.eduhubpro.eduhubpro.Entity.User.Model.User;
import com.eduhubpro.eduhubpro.Entity.Module.Model.Module;

@Repository
public interface AttendanceRepository extends JpaRepository<Attendance, UUID> {

    @Query("SELECT a FROM Attendance a " +
            "WHERE a.module.moduleId = :moduleId " +
            "AND a.course.courseId = :courseId")
    List<Attendance> findByModuleIdAndCourseId(@Param("moduleId") UUID moduleId,
                                               @Param("courseId") UUID courseId);

    @Query("SELECT a FROM Attendance a WHERE a.student = :student AND a.course = :course AND a.module = :module")
    Optional<Attendance> findByStudentAndCourseAndModule(@Param("student") User student,
                                                         @Param("course") Course course, @Param("module") Module module);

    @Query("SELECT COUNT(a) FROM Attendance a WHERE a.student = :student AND a.course = :course")
    int countByStudentAndCourse(@Param("student") User student, @Param("course") Course course);

    @Query("SELECT COUNT(a) FROM Attendance a WHERE a.student = :student AND a.course = :course AND a.attended = true")
    int countByStudentAndCourseAndAttendedTrue(@Param("student") User student, @Param("course") Course course);

    @Query("SELECT a FROM Attendance a WHERE a.student = :student AND a.course = :course")
    List<Attendance> findByStudentAndCourse(@Param("student") User student, @Param("course") Course course);

}
