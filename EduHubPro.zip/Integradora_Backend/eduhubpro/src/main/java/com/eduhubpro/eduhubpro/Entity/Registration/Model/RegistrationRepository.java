package com.eduhubpro.eduhubpro.Entity.Registration.Model;

import com.eduhubpro.eduhubpro.Entity.Course.Model.Course;
import com.eduhubpro.eduhubpro.Entity.User.Model.User;
import com.eduhubpro.eduhubpro.Util.Enum.EntityEnum.CourseStatus;
import com.eduhubpro.eduhubpro.Util.Enum.EntityEnum.PaymentStatus;
import com.eduhubpro.eduhubpro.Util.Enum.EntityEnum.RegistrationStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface RegistrationRepository extends JpaRepository<Registration, UUID> {
        // Encontrar cursos del estudiante
        @Query("SELECT r FROM Registration r WHERE r.student.userId = :userId AND r.registrationStatus != :status")
        List<Registration> findAllNotFinalizedCourses(@Param("userId") UUID userId,
                        @Param("status") RegistrationStatus status);

        @Query("SELECT r FROM Registration r WHERE r.course.courseId = :courseId AND r.registrationStatus IN :statuses")
        List<Registration> findByCourseIdAndStatus(@Param("courseId") UUID courseId,
                        @Param("statuses") List<RegistrationStatus> statuses);

        /**
         * Un método genérico que une (JOIN) la tabla payment a registration
         * y filtra por estados de ambas entidades.
         */
        @Query("""
                        SELECT r, p
                        FROM Registration r
                        JOIN Payment p ON p.registration = r
                        WHERE r.registrationStatus = :regStatus
                          AND p.status = :payStatus
                        """)
        List<Object[]> findAllByRegAndPayStatus(@Param("regStatus") RegistrationStatus regStatus,
                        @Param("payStatus") PaymentStatus payStatus);

        // Cron job
        // Buscar todos los registros de estudiantes para un curso específico
        @Query("SELECT r FROM Registration r WHERE r.course = :course AND r.registrationStatus NOT IN :excludedStatuses")
        List<Registration> findByCourseAndStatusNotIn(@Param("course") Course course,
                        @Param("excludedStatuses") List<RegistrationStatus> excludedStatuses);

        // MÓVIL
        // Filtro de cursos en la app móvil
        @Query("SELECT r.course FROM Registration r " +
                        "WHERE r.student.userId = :studentId " +
                        "AND r.registrationStatus = com.eduhubpro.eduhubpro.Util.Enum.EntityEnum.RegistrationStatus.REGISTERED "
                        +
                        "AND r.course.courseStatus = com.eduhubpro.eduhubpro.Util.Enum.EntityEnum.CourseStatus.IN_PROGRESS")
        List<Course> findInProgressCoursesByStudent(@Param("studentId") UUID studentId);

        @Query("SELECT r.course FROM Registration r " +
                        "WHERE r.student.userId = :studentId " +
                        "AND r.registrationStatus IN :registrationStatuses " +
                        "AND r.course.courseStatus IN :courseStatuses")
        List<Course> findRegistrationByStudent(
                        @Param("studentId") UUID studentId,
                        @Param("registrationStatuses") List<RegistrationStatus> registrationStatuses,
                        @Param("courseStatuses") List<CourseStatus> courseStatuses);

        // Añadir este método para contar inscripciones con estados REGISTERED y PENDING
        @Query("SELECT COUNT(r) FROM Registration r WHERE r.course = :course AND r.registrationStatus IN :statuses")
        long countRegisteredByCourse(@Param("course") Course course,
                        @Param("statuses") List<RegistrationStatus> statuses);

        @Query("SELECT r FROM Registration r " +
                        "WHERE r.student = :student " +
                        "AND r.course = :course " +
                        "AND r.registrationStatus <> com.eduhubpro.eduhubpro.Util.Enum.EntityEnum.RegistrationStatus.CANCELED")
        Optional<Registration> findByStudentAndCourse(@Param("student") User student,
                        @Param("course") Course course);
}
