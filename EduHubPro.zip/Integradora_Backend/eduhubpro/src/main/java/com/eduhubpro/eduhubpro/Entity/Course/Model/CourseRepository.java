package com.eduhubpro.eduhubpro.Entity.Course.Model;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.eduhubpro.eduhubpro.Util.Enum.EntityEnum.CourseStatus;

@Repository
public interface CourseRepository extends JpaRepository<Course, UUID> {

        // Encontrar cursos asociados al docente cuando se cambia el estado de la cuenta
        @Query("SELECT c FROM Course c WHERE c.instructor.userId =:userId AND c.courseStatus !=:status")
        List<Course> findAllNotFinalizedCourses(@Param("userId") UUID userId, @Param("status") CourseStatus status);

        // Encontrar todos los cursos para el docente
        @Query("SELECT c FROM Course c WHERE c.instructor.userId =:userId AND c.courseStatus NOT IN :status")
        List<Course> findAllByInstructor(@Param("userId") UUID userId, @Param("status") List<CourseStatus> status);

        // Encontrar todos los cursos publicados
        @Query("SELECT c FROM Course c WHERE c.courseStatus IN :status")
        List<Course> findAllByStatus(@Param("status") List<CourseStatus> status);

        // Encontrar cursor por nombre de docente
        @Query("SELECT c FROM Course c WHERE LOWER(c.instructor.name) LIKE LOWER(CONCAT('%', :instructorName, '%')) AND c.courseStatus = :status")
        List<Course> findByInstructorAndCourseStatus(@Param("instructorName") String instructorName,
                        @Param("status") CourseStatus status);

        // Encontrar cursos por fecha
        @Query("SELECT c FROM Course c WHERE c.startDate >= :startDate ")
        List<Course> findByDate(@Param("startDate") LocalDate startDate);

        // Contar cursos en curso y publicados
        @Query("SELECT COUNT(c) FROM Course c WHERE c.courseStatus IN :status")
        Long countCourses(@Param("status") List<CourseStatus> status);

        // Encontrar cursos por id
        @Query("SELECT c FROM Course c WHERE c.courseId = :courseId")
        Optional<Course> findById(@Param("courseId") UUID courseId);

        // Cron job
        @Query("SELECT c FROM Course c WHERE c.startDate = :startDate")
        List<Course> findByStartDate(@Param("startDate") LocalDate startDate);

        // Utiliado en el cron job del proceso de finalización de cursos
        @Query("SELECT c FROM Course c WHERE c.courseStatus = :status AND FUNCTION('DATE', c.endDate) = :endDate")
        List<Course> findByCourseStatusAndEndDate(@Param("endDate") LocalDate endDate,
                        @Param("status") CourseStatus status);

        // Cambiar el estado del curso a en progreso
        @Query("SELECT c FROM Course c WHERE c.startDate = :startDate AND c.courseStatus = :status")
        List<Course> findByStartDateAndCourseStatus(@Param("startDate") LocalDate startDate,
                        @Param("status") CourseStatus status);

        @Query("SELECT c FROM Course c JOIN c.categories cat " +
                        "WHERE cat.categoryId = :categoryId AND c.courseStatus =:status")
        List<Course> findPublishedByCategoryId(@Param("categoryId") UUID categoryId,
                        @Param("status") CourseStatus status);

}