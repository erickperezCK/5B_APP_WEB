package com.eduhubpro.eduhubpro.Entity.Account.Model;

import com.eduhubpro.eduhubpro.Util.Enum.EntityEnum.Status;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface AccountRepository extends JpaRepository<Account, UUID> {
    @Query("SELECT a FROM Account a WHERE a.status IN :status")
    List<Account> findAllByStatusActive(@Param("status") Status status);

    @Query("SELECT a FROM Account a WHERE a.accountNumber = :accountNumber AND a.status = :status")
    Optional<Account> findByAccountNumber(@Param("accountNumber") String accountNumber,
            @Param("status") Status status);

    @Query("SELECT a FROM Account a WHERE a.key = :key AND a.status = :status")
    Optional<Account> findByKey(@Param("key") String key,
            @Param("status") Status status);
}