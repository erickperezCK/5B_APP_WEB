package com.eduhubpro.eduhubpro.Entity.Module.Model;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.eduhubpro.eduhubpro.Entity.Course.Model.Course;
import com.eduhubpro.eduhubpro.Util.Enum.EntityEnum.ModuleStatus;

@Repository
public interface ModuleRepository extends JpaRepository<Module, UUID> {

    // Buscar módulos relacionadas a un curso
    @Query("SELECT m FROM Module m WHERE m.course.courseId =:courseId AND m.status IN :status ORDER BY m.date ASC")
    List<Module> findAllByCourseId(@Param("courseId") UUID moduleId, @Param("status") List<ModuleStatus> status);

    // Contar cuantos módulos tiene un curso antes de colocar el estado como
    // bloqueado
    @Query("SELECT COUNT(m) FROM Module m WHERE m.course = :course")
    long countByCourse(@Param("course") Course course);

    @Query("SELECT m FROM Module m WHERE m.course = :course ORDER BY m.date ASC")
    List<Module> findByCourseOrderByDateAsc(@Param("course") Course course);

    @Query("SELECT m FROM Module m LEFT JOIN FETCH m.sections WHERE m.course.courseId = :courseId ORDER BY m.date ASC")
    List<Module> findAllByCourseWithSections(@Param("courseId") UUID courseId);

}
