package com.eduhubpro.eduhubpro.Entity.Payment.Model;

import com.eduhubpro.eduhubpro.Util.Enum.EntityEnum.PaymentStatus;
import com.eduhubpro.eduhubpro.Entity.Registration.Model.Registration;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface PaymentRepository extends JpaRepository<Payment, UUID> {

        Optional<Payment> findByRegistration(Registration registration);

        // Para obtener pagos pendientes filtrados por estudiante
        @Query("SELECT p FROM Payment p " +
                        "JOIN FETCH p.registration r " +
                        "JOIN FETCH r.course c " +
                        "WHERE p.status = com.eduhubpro.eduhubpro.Util.Enum.EntityEnum.PaymentStatus.PENDING_PAYMENT " +
                        "AND r.student.userId = :studentId " +
                        "AND c.courseStatus = com.eduhubpro.eduhubpro.Util.Enum.EntityEnum.CourseStatus.PUBLISHED")
        List<Payment> findPendingByStudent(@Param("studentId") UUID studentId);

        // Para obtener pagos pendientes sin requerir el estudiante
        @Query("SELECT p FROM Payment p JOIN FETCH p.registration r " +
                        "WHERE p.status = com.eduhubpro.eduhubpro.Util.Enum.EntityEnum.PaymentStatus.PENDING_PAYMENT")
        List<Payment> findPendingPayments();

        // Para obtener pagos aprobados (FINISHED) sin requerir el estudiante
        @Query("SELECT p FROM Payment p JOIN FETCH p.registration r " +
                        "WHERE p.status = com.eduhubpro.eduhubpro.Util.Enum.EntityEnum.PaymentStatus.FINISHED")
        List<Payment> findFinishedPayments();
}
