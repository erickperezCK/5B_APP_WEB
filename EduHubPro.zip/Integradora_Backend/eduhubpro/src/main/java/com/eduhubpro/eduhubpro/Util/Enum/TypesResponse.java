package com.eduhubpro.eduhubpro.Util.Enum;

public enum TypesResponse {
    SUCCESS,
    ERROR,
    WARNING
}