package com.eduhubpro.eduhubpro.Security.Auth.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.eduhubpro.eduhubpro.Entity.User.Model.UserDto;
import com.eduhubpro.eduhubpro.Entity.User.Service.UserService;
import com.eduhubpro.eduhubpro.Security.Auth.Model.AuthRequest;
import com.eduhubpro.eduhubpro.Security.Auth.Model.AuthResponse;
import com.eduhubpro.eduhubpro.Security.Jwt.JwtUtil;
import com.eduhubpro.eduhubpro.Util.Response.Message;

@RestController
@RequestMapping("/auth")
public class AuthController {

    private final JwtUtil jwtUtil;
    private final AuthService authService;
    private final UserService userService;

    @Autowired
    public AuthController(JwtUtil jwtUtil, AuthService authService, UserService userService) {
        this.jwtUtil = jwtUtil;
        this.authService = authService;
        this.userService = userService;
    }

    @PostMapping("/login")
    public AuthResponse login(@RequestBody AuthRequest authRequest) throws Exception {
        return authService.login(authRequest);
    }

    @DeleteMapping("/logout")
    public ResponseEntity<Message> logout(@Validated(UserDto.Consult.class) @RequestBody UserDto dto) {
        return authService.logout(dto);
    }

    // Registrarse
    // validar que si hay un estudiante inactivo otro pueda registrarse con su mismo
    // correo
    @PostMapping("/register")
    public ResponseEntity<Message> createUser(@Validated(UserDto.Register.class) @RequestBody UserDto dto) {
        return userService.createUser(dto);
    }

    // Recuperar contraseña cliente parte 1
    @PostMapping("/request-reset")
    public ResponseEntity<Message> requestPasswordReset(
            @Validated(UserDto.RequestReset.class) @RequestBody UserDto dto) {
        return userService.requestPasswordReset(dto);
    }

    @PostMapping("/request-reset-student")
    public ResponseEntity<Message> requestPasswordResetStudent(
            @Validated(UserDto.RequestReset.class) @RequestBody UserDto dto) {
        return userService.requestPasswordResetStudent(dto);
    }

    // Recuperar contraseña cliente parte 2
    @PutMapping("/reset")
    public ResponseEntity<Message> resetPassword(@Validated(UserDto.Reset.class) @RequestBody UserDto dto) {
        return userService.resetPassword(dto);
    }
}