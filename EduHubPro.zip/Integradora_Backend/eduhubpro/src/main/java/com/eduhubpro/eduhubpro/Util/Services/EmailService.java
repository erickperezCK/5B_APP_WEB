package com.eduhubpro.eduhubpro.Util.Services;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sendgrid.Method;
import com.sendgrid.Request;
import com.sendgrid.Response;
import com.sendgrid.SendGrid;
import com.sendgrid.helpers.mail.Mail;
import com.sendgrid.helpers.mail.objects.Email;
import com.sendgrid.helpers.mail.objects.Personalization;

@Service
public class EmailService {

    private static final Logger logger = LoggerFactory.getLogger(EmailService.class);
    private final PdfService pdfService;

    @Autowired
    public EmailService(PdfService pdfService) {
        this.pdfService = pdfService;
    }

    // Credentials
    @Value("${spring.mail.password}")
    private String accessToken;

    // Templates
    @Value("${spring.mailersend.courseApproved}")
    private String courseApproved;

    @Value("${spring.mailersend.courseNotApproved}")
    private String courseNotApproved;

    @Value("${spring.mailersend.paymentApproved}")
    private String paymentApproved;

    @Value("${spring.mailersend.paymentNotApproved}")
    private String paymentNotApproved;

    @Value("${spring.mailersend.constancy}")
    private String constancy;

    @Value("${spring.mailersend.credentials}")
    private String credentials;

    @Value("${spring.mailersend.resendCredentials}")
    private String resendCredentials;

    @Value("${spring.mailersend.paymentReminder}")
    private String paymentReminder;

    @Value("${spring.mailersend.courseStartReminder}")
    private String courseStartReminder;

    @Value("${spring.mailersend.courseStartReminderIns}")
    private String courseStartReminderIns;

    @Value("${spring.mailersend.resetPassword}")
    private String resetPassword;

    @Value("${spring.mailersend.support}")
    private String support;

    private String supportUrl;

    /**
     * Sends an email notification regarding an approved course.
     *
     * @param subject          The subject of the email.
     * @param destinationEmail The recipient's email address.
     * @param userName         The name of the user receiving the email.
     * @param courseName       The name of the course that was not approved.
     * @param startDate        The start date of the course.
     * @param endDate          The completion date of the course.
     * @return {@code true} if the email was sent successfully, otherwise
     *         {@code false}.
     */
    public boolean sendEmail(String subject, String destinationEmail, String userName, String courseName,
            String startDate, String endDate) {
        try {
            // 1) Crea el objeto de correo utilizando SendGrid
            Email from = new Email("no-reply@em5697.eduhubpro.site", "EduHubPro"); // Usando tu dominio verificado
            Email to = new Email(destinationEmail, userName); // Se envía automáticamente a este correo

            // 2) Crea el correo con la plantilla de SendGrid
            Mail mail = new Mail();
            mail.setFrom(from);
            mail.setSubject(subject);
            mail.setTemplateId(courseApproved); // ID de plantilla en SendGrid

            // 3) Configura la personalización del correo
            Personalization personalization = new Personalization();
            personalization.addTo(to); // Agrega al destinatario
            personalization.addDynamicTemplateData("name", userName); // Variable dinámica en la plantilla
            personalization.addDynamicTemplateData("course_name", courseName); // Nombre del curso
            personalization.addDynamicTemplateData("course_name2", courseName); // Repetir nombre del curso si es
                                                                                // necesario
            personalization.addDynamicTemplateData("start_date", startDate); // Fecha de inicio
            personalization.addDynamicTemplateData("end_date", endDate); // Fecha de finalización
            personalization.addDynamicTemplateData("support_url", supportUrl); // Url de soporte
            mail.addPersonalization(personalization);

            // 4) Configura la API de SendGrid
            SendGrid sg = new SendGrid(accessToken); // Tu API key
            Request request = new Request();
            request.setMethod(Method.POST);
            request.setEndpoint("mail/send");
            request.setBody(mail.build());

            // 5) Envía el correo
            Response response = sg.api(request);
            logger.info("Correo enviado con ID: " + response.getBody());
            return response.getStatusCode() == 202; // 202 = Aceptado por SendGrid

        } catch (IOException e) {
            logger.error("Error al enviar el correo: ", e);
            return false;
        }
    }

    /**
     * Sends an email notification regarding an unapproved course.
     *
     * @param subject          The subject of the email.
     * @param destinationEmail The recipient's email address.
     * @param userName         The name of the user receiving the email.
     * @param courseName       The name of the course that was not approved.
     * @return {@code true} if the email was sent successfully, otherwise
     *         {@code false}.
     */
    public boolean sendEmail(String subject, String destinationEmail, String userName, String courseName) {
        try {
            // 1) Crea el objeto de correo utilizando SendGrid
            Email from = new Email("no-reply@em5697.eduhubpro.site", "EduHubPro"); // Usando tu dominio verificado
            Email to = new Email(destinationEmail, userName); // Se envía automáticamente a este correo

            // 2) Crea el correo con la plantilla de SendGrid
            Mail mail = new Mail();
            mail.setFrom(from);
            mail.setSubject(subject);
            mail.setTemplateId(courseNotApproved); // ID de plantilla en SendGrid

            // 3) Configura la personalización del correo
            Personalization personalization = new Personalization();
            personalization.addTo(to); // Agrega al destinatario
            personalization.addDynamicTemplateData("name", userName); // Variable dinámica en la plantilla
            personalization.addDynamicTemplateData("course_name", courseName); // Nombre del curso
            personalization.addDynamicTemplateData("support_url", supportUrl); // Url de soporte

            mail.addPersonalization(personalization);

            // 4) Configura la API de SendGrid
            SendGrid sg = new SendGrid(accessToken); // Tu API key
            Request request = new Request();
            request.setMethod(Method.POST);
            request.setEndpoint("mail/send");
            request.setBody(mail.build());

            // 5) Envía el correo
            Response response = sg.api(request);
            logger.info("Correo enviado con ID: " + response.getBody());
            return response.getStatusCode() == 202; // 202 = Aceptado por SendGrid

        } catch (IOException e) {
            logger.error("Error al enviar el correo: ", e);
            return false;
        }
    }

    /**
     * Sends a course completion certificate via email.
     *
     * @param subject          The subject of the email.
     * @param destinationEmail The recipient's email address.
     * @param userName         The name of the user receiving the certificate.
     * @param instructorName   The name of the instructor of the course.
     * @param courseName       The name of the completed course.
     * @param startDate        The start date of the course.
     * @param endDate          The completion date of the course.
     * @return {@code true} if the email was sent successfully, otherwise
     *         {@code false}.
     */
    public boolean sendEmail(
            String subject,
            String destinationEmail,
            String userName,
            String instructorName,
            String courseName,
            String startDate,
            String endDate) {
        try {
            // 1) Crea el objeto de correo utilizando SendGrid
            Email from = new Email("no-reply@em5697.eduhubpro.site", "EduHubPro"); // Usando tu dominio verificado
            Email to = new Email(destinationEmail, userName); // Se envía automáticamente a este correo

            // 2) Crea el correo con la plantilla de SendGrid
            Mail mail = new Mail();
            mail.setFrom(from);
            mail.setSubject(subject);
            mail.setTemplateId(constancy); // ID de plantilla en SendGrid

            // 3) Generación del PDF y configuración de la personalización del correo
            String pdfUrl;
            try {
                pdfUrl = pdfService.generatePdf(userName, courseName, instructorName, startDate, endDate);
            } catch (IOException e) {
                logger.error("Error al generar el PDF: " + e.getMessage(), e);
                return false;
            }

            // Configura las personalizaciones
            Personalization personalization = new Personalization();
            personalization.addTo(to); // Agrega al destinatario
            personalization.addDynamicTemplateData("name", userName); // Variable dinámica en la plantilla
            personalization.addDynamicTemplateData("course_name", courseName); // Nombre del curso
            personalization.addDynamicTemplateData("instructor_name", instructorName); // Nombre del instructor
            personalization.addDynamicTemplateData("start_date", startDate); // Fecha de inicio
            personalization.addDynamicTemplateData("end_date", endDate); // Fecha de finalización
            personalization.addDynamicTemplateData("pdf_link", pdfUrl); // Enlace al PDF generado

            mail.addPersonalization(personalization);

            // 4) Configura la API de SendGrid
            SendGrid sg = new SendGrid(accessToken); // Tu API Key
            Request request = new Request();
            request.setMethod(Method.POST);
            request.setEndpoint("mail/send");
            request.setBody(mail.build());

            // 5) Envía el correo
            Response response = sg.api(request);
            logger.info("Correo enviado con ID: " + response.getBody());
            return response.getStatusCode() == 202; // 202 = Aceptado por SendGrid

        } catch (IOException e) {
            logger.error("Error al enviar el correo: ", e);
            return false;
        }
    }

    /**
     * Sends credentials to the user via email.
     *
     * @param subject          The subject of the email.
     * @param destinationEmail The recipient's email address.
     * @param userName         The name of the user receiving the credentials.
     * @param password         The password to be sent to the user.
     * @return {@code true} if the email was sent successfully, otherwise
     *         {@code false}.
     */
    public boolean sendCredentials(String subject, String destinationEmail, String userName, String password) {
        try {
            // 1) Crea el objeto de correo utilizando SendGrid
            Email from = new Email("no-reply@em5697.eduhubpro.site", "EduHubPro"); // Usando tu dominio verificado
            Email to = new Email(destinationEmail, userName); // Se envía automáticamente a este correo

            // 2) Crea el correo con la plantilla de SendGrid
            Mail mail = new Mail();
            mail.setFrom(from);
            mail.setSubject(subject);
            mail.setTemplateId(credentials); // ID de plantilla en SendGrid

            // 3) Configura la personalización del correo
            Personalization personalization = new Personalization();
            personalization.addTo(to); // Agrega al destinatario
            personalization.addDynamicTemplateData("name", userName); // Variable dinámica en la plantilla
            personalization.addDynamicTemplateData("email", destinationEmail); // Añade el email
            personalization.addDynamicTemplateData("password", password); // Añade la contraseña
            personalization.addDynamicTemplateData("support_url", supportUrl); // Url de soporte

            mail.addPersonalization(personalization);

            // 4) Configura la API de SendGrid
            SendGrid sg = new SendGrid(accessToken); // Tu API key
            Request request = new Request();
            request.setMethod(Method.POST);
            request.setEndpoint("mail/send");
            request.setBody(mail.build());

            // 5) Envía el correo
            Response response = sg.api(request);
            logger.info("Correo enviado con ID: " + response.getBody());
            return response.getStatusCode() == 202; // 202 = Aceptado por SendGrid

        } catch (IOException e) {
            logger.error("Error al enviar el correo: ", e);
            return false;
        }
    }

    /**
     * Resends credentials to the user via email.
     *
     * @param subject          The subject of the email.
     * @param destinationEmail The recipient's email address.
     * @param userName         The name of the user receiving the credentials.
     * @param password         The password to be sent to the user.
     * @return {@code true} if the email was sent successfully, otherwise
     *         {@code false}.
     */
    public boolean resendCredentials(String subject, String destinationEmail, String userName, String password) {
        try {
            // 1) Crea el objeto de correo utilizando SendGrid
            Email from = new Email("no-reply@em5697.eduhubpro.site", "EduHubPro"); // Usando tu dominio verificado
            Email to = new Email(destinationEmail, userName); // Se envía automáticamente a este correo

            // 2) Crea el correo con la plantilla de SendGrid
            Mail mail = new Mail();
            mail.setFrom(from);
            mail.setSubject(subject);
            mail.setTemplateId(resendCredentials); // ID de plantilla en SendGrid

            // 3) Configura la personalización del correo
            Personalization personalization = new Personalization();
            personalization.addTo(to); // Agrega al destinatario
            personalization.addDynamicTemplateData("name", userName); // Variable dinámica en la plantilla
            personalization.addDynamicTemplateData("email", destinationEmail); // Añade el email
            personalization.addDynamicTemplateData("password", password); // Añade la contraseña
            personalization.addDynamicTemplateData("support_url", supportUrl); // Url de soporte

            mail.addPersonalization(personalization);

            // 4) Configura la API de SendGrid
            SendGrid sg = new SendGrid(accessToken); // Tu API key
            Request request = new Request();
            request.setMethod(Method.POST);
            request.setEndpoint("mail/send");
            request.setBody(mail.build());

            // 5) Envía el correo
            Response response = sg.api(request);
            logger.info("Correo enviado con ID: " + response.getBody());
            return response.getStatusCode() == 202; // 202 = Aceptado por SendGrid

        } catch (IOException e) {
            logger.error("Error al enviar el correo: ", e);
            return false;
        }
    }

    /**
     * Sends a notification email for an approved payment.
     *
     * @param subject          The subject of the email.
     * @param destinationEmail The recipient's email address.
     * @param userName         The name of the user receiving the email.
     * @param paymentId        The ID of the approved payment.
     * @param courseName       The name of the course associated with the payment.
     * @return {@code true} if the email was sent successfully, otherwise
     *         {@code false}.
     */
    public boolean sendApprovedPayment(String subject, String destinationEmail,
            String userName, String paymentId,
            String courseName) {
        try {
            // 1) Crea el objeto de correo utilizando SendGrid
            Email from = new Email("no-reply@em5697.eduhubpro.site", "EduHubPro"); // Usando tu dominio verificado
            Email to = new Email(destinationEmail, userName); // Se envía automáticamente a este correo

            // 2) Crea el correo con la plantilla de SendGrid
            Mail mail = new Mail();
            mail.setFrom(from);
            mail.setSubject(subject);
            mail.setTemplateId(paymentApproved); // ID de plantilla en SendGrid

            // 3) Configura la personalización del correo
            Personalization personalization = new Personalization();
            personalization.addTo(to); // Agrega al destinatario
            personalization.addDynamicTemplateData("name", userName); // Variable dinámica en la plantilla
            // personalization.addDynamicTemplateData("payment_id", paymentId); // ID de
            // pago
            personalization.addDynamicTemplateData("course_name", courseName); // Nombre del curso
            personalization.addDynamicTemplateData("support_url", supportUrl); // Url de soporte

            mail.addPersonalization(personalization);

            // 4) Configura la API de SendGrid
            SendGrid sg = new SendGrid(accessToken); // Tu API key
            Request request = new Request();
            request.setMethod(Method.POST);
            request.setEndpoint("mail/send");
            request.setBody(mail.build());

            // 5) Envía el correo
            Response response = sg.api(request);
            logger.info("Correo enviado con ID: " + response.getBody());
            return response.getStatusCode() == 202; // 202 = Aceptado por SendGrid

        } catch (IOException e) {
            logger.error("Error al enviar el correo: ", e);
            return false;
        }
    }

    /**
     * Sends a notification email for a not approved payment.
     *
     * @param subject          The subject of the email.
     * @param destinationEmail The recipient's email address.
     * @param userName         The name of the user receiving the email.
     * @param paymentId        The ID of the not approved payment.
     * @param courseName       The name of the course associated with the payment.
     * @return {@code true} if the email was sent successfully, otherwise
     *         {@code false}.
     */
    public boolean sendNotApprovedPayment(String subject, String destinationEmail, String userName, String paymentId,
            String courseName) {
        try {
            // 1) Crea el objeto de correo utilizando SendGrid
            Email from = new Email("no-reply@em5697.eduhubpro.site", "EduHubPro"); // Usando tu dominio verificado
            Email to = new Email(destinationEmail, userName); // Se envía automáticamente a este correo

            // 2) Crea el correo con la plantilla de SendGrid
            Mail mail = new Mail();
            mail.setFrom(from);
            mail.setSubject(subject);
            mail.setTemplateId(paymentNotApproved); // ID de plantilla en SendGrid

            // 3) Configura la personalización del correo
            Personalization personalization = new Personalization();
            personalization.addTo(to); // Agrega al destinatario
            personalization.addDynamicTemplateData("name", userName); // Variable dinámica en la plantilla
            // personalization.addDynamicTemplateData("payment_id", paymentId); // ID de
            // pago
            personalization.addDynamicTemplateData("course_name", courseName); // Nombre del curso
            personalization.addDynamicTemplateData("support_url", supportUrl); // Url de soporte

            mail.addPersonalization(personalization);

            // 4) Configura la API de SendGrid
            SendGrid sg = new SendGrid(accessToken); // Tu API key
            Request request = new Request();
            request.setMethod(Method.POST);
            request.setEndpoint("mail/send");
            request.setBody(mail.build());

            // 5) Envía el correo
            Response response = sg.api(request);
            logger.info("Correo enviado con ID: " + response.getBody());
            return response.getStatusCode() == 202; // 202 = Aceptado por SendGrid

        } catch (IOException e) {
            logger.error("Error al enviar el correo: ", e);
            return false;
        }
    }

    /**
     * Sends a verification code for password reset.
     *
     * @param subject          The subject of the email.
     * @param userName         The name of the user receiving the email.
     * @param destinationEmail The recipient's email address.
     * @param code             The verification code to be sent.
     * @return {@code true} if the email was sent successfully, otherwise
     *         {@code false}.
     */
    public boolean sendCode(String subject, String userName, String destinationEmail, String code) {
        try {
            // 1) Crea el objeto de correo utilizando SendGrid
            Email from = new Email("no-reply@em5697.eduhubpro.site", "EduHubPro"); // Usando tu dominio verificado
            Email to = new Email(destinationEmail, userName); // Se envía automáticamente a este correo

            // 2) Crea el correo con la plantilla de SendGrid
            Mail mail = new Mail();
            mail.setFrom(from);
            mail.setSubject(subject);
            mail.setTemplateId(resetPassword); // ID de plantilla en SendGrid

            // 3) Configura la personalización del correo
            Personalization personalization = new Personalization();
            personalization.addTo(to); // Agrega al destinatario
            personalization.addDynamicTemplateData("name", userName); // Variable dinámica en la plantilla
            personalization.addDynamicTemplateData("code", code); // Código de verificación
            personalization.addDynamicTemplateData("support_url", supportUrl); // Url de soporte

            mail.addPersonalization(personalization);

            // 4) Configura la API de SendGrid
            SendGrid sg = new SendGrid(accessToken); // Tu API key
            Request request = new Request();
            request.setMethod(Method.POST);
            request.setEndpoint("mail/send");
            request.setBody(mail.build());

            // 5) Envía el correo
            Response response = sg.api(request);
            logger.info("Correo enviado con ID: " + response.getBody());
            return response.getStatusCode() == 202; // 202 = Aceptado por SendGrid

        } catch (IOException e) {
            logger.error("Error al enviar el correo: ", e);
            return false;
        }
    }

    /**
     * Sends a support email to the administrator.
     *
     * @param subject          The subject of the email.
     * @param destinationEmail The recipient's email address.
     * @param userName         The name of the user sending the support request.
     * @param comment          The comment or message from the user.
     * @return {@code true} if the email was sent successfully, otherwise
     *         {@code false}.
     */
    public boolean support(String subject, String destinationEmail, String userName, String comment) {
        try {
            // 1) Crea el objeto de correo utilizando SendGrid
            Email from = new Email("no-reply@em5697.eduhubpro.site", "EduHubPro"); // Usando tu dominio verificado
            Email to = new Email("eduhubpro1@gmail.com", userName); // Se envía automáticamente a este correo

            // 2) Crea el correo con la plantilla de SendGrid
            Mail mail = new Mail();
            mail.setFrom(from);
            mail.setSubject(subject);
            mail.setTemplateId(support); // ID de plantilla en SendGrid

            // 3) Configura la personalización del correo
            Personalization personalization = new Personalization();
            personalization.addTo(to); // Agrega al destinatario
            personalization.addDynamicTemplateData("name", userName); // Variable dinámica en la plantilla
            personalization.addDynamicTemplateData("email", destinationEmail); // Dirección de correo
            personalization.addDynamicTemplateData("email2", destinationEmail); // Dirección de correo
            personalization.addDynamicTemplateData("comment", comment); // Comentario

            mail.addPersonalization(personalization);

            // 4) Configura la API de SendGrid
            SendGrid sg = new SendGrid(accessToken); // Tu API key
            Request request = new Request();
            request.setMethod(Method.POST);
            request.setEndpoint("mail/send");
            request.setBody(mail.build());

            // 5) Envía el correo
            Response response = sg.api(request);
            logger.info("Correo enviado con ID: " + response.getBody());
            return response.getStatusCode() == 202; // 202 = Aceptado por SendGrid

        } catch (IOException e) {
            logger.error("Error al enviar el correo: ", e);
            return false;
        }
    }

    /**
     * Sends a course start reminder email to the student.
     *
     * @param subject          The subject of the email.
     * @param destinationEmail The recipient's email address.
     * @param userName         The name of the user receiving the email.
     * @param courseName       The name of the course that is starting.
     * @param startDate        The start date of the course.
     * @return {@code true} if the email was sent successfully, otherwise
     *         {@code false}.
     */
    public boolean sendCourseStartReminderStudent(String subject, String destinationEmail, String userName,
            String courseName, String startDate) {
        try {
            // 1) Crea el objeto de correo utilizando SendGrid
            Email from = new Email("no-reply@em5697.eduhubpro.site", "EduHubPro"); // Usando tu dominio verificado
            Email to = new Email(destinationEmail, userName); // Se envía automáticamente a este correo

            // 2) Crea el correo con la plantilla de SendGrid
            Mail mail = new Mail();
            mail.setFrom(from);
            mail.setSubject(subject);
            mail.setTemplateId(courseStartReminder); // ID de plantilla en SendGrid

            // 3) Configura la personalización del correo
            Personalization personalization = new Personalization();
            personalization.addTo(to); // Agrega al destinatario
            personalization.addDynamicTemplateData("name", userName); // Variable dinámica en la plantilla
            personalization.addDynamicTemplateData("start_date", startDate); // Fecha de inicio
            personalization.addDynamicTemplateData("course_name", courseName); // Nombre del curso
            personalization.addDynamicTemplateData("support_url", supportUrl); // Url de soporte
            // personalization.addDynamicTemplateData("instructor_name", instructorName); //
            // Nombre del instructor
            // personalization.addDynamicTemplateData("end_date", endDate); // Fecha de
            // finalización

            mail.addPersonalization(personalization);

            // 4) Configura la API de SendGrid
            SendGrid sg = new SendGrid(accessToken); // Tu API key
            Request request = new Request();
            request.setMethod(Method.POST);
            request.setEndpoint("mail/send");
            request.setBody(mail.build());

            // 5) Envía el correo
            Response response = sg.api(request);
            logger.info("Correo enviado con ID: " + response.getBody());
            return response.getStatusCode() == 202; // 202 = Aceptado por SendGrid

        } catch (IOException e) {
            logger.error("Error al enviar el correo: ", e);
            return false;
        }
    }

    /**
     * Sends a payment reminder email to the student.
     *
     * @param subject          The subject of the email.
     * @param destinationEmail The recipient's email address.
     * @param userName         The name of the user receiving the email.
     * @param courseName       The name of the course that is starting.
     * @param instructorName   The name of the instructor of the course.
     * @param startDate        The start date of the course.
     * @param endDate          The completion date of the course.
     * @param price            The price of the course.
     * @return {@code true} if the email was sent successfully, otherwise
     *         {@code false}.
     */
    public boolean sendPaymentReminderStudent(String subject, String destinationEmail, String userName,
            String courseName, String instructorName, String startDate, String endDate, double price) {
        try {
            // 1) Crea el objeto de correo utilizando SendGrid
            Email from = new Email("no-reply@em5697.eduhubpro.site", "EduHubPro"); // Usando tu dominio verificado
            Email to = new Email(destinationEmail, userName); // Se envía automáticamente a este correo

            // 2) Crea el correo con la plantilla de SendGrid
            Mail mail = new Mail();
            mail.setFrom(from);
            mail.setSubject(subject);
            mail.setTemplateId(paymentReminder); // ID de plantilla en SendGrid

            // 3) Configura la personalización del correo
            Personalization personalization = new Personalization();
            personalization.addTo(to); // Agrega al destinatario
            personalization.addDynamicTemplateData("name", userName); // Variable dinámica en la plantilla
            personalization.addDynamicTemplateData("start_date", startDate); // Fecha de inicio
            personalization.addDynamicTemplateData("instructor_name", instructorName); // Nombre del instructor
            personalization.addDynamicTemplateData("course_name", courseName); // Nombre del curso
            personalization.addDynamicTemplateData("end_date", endDate); // Fecha de finalización
            personalization.addDynamicTemplateData("price", price); // Precio
            personalization.addDynamicTemplateData("support_url", supportUrl); // Url de soporte

            mail.addPersonalization(personalization);

            // 4) Configura la API de SendGrid
            SendGrid sg = new SendGrid(accessToken); // Tu API key
            Request request = new Request();
            request.setMethod(Method.POST);
            request.setEndpoint("mail/send");
            request.setBody(mail.build());

            // 5) Envía el correo
            Response response = sg.api(request);
            logger.info("Correo enviado con ID: " + response.getBody());
            return response.getStatusCode() == 202; // 202 = Aceptado por SendGrid

        } catch (IOException e) {
            logger.error("Error al enviar el correo: ", e);
            return false;
        }
    }

    /**
     * Sends a course start reminder email to the instructor.
     *
     * @param subject          The subject of the email.
     * @param destinationEmail The recipient's email address.
     * @param userName         The name of the user receiving the email.
     * @param courseName       The name of the course that is starting.
     * @param startDate        The start date of the course.
     * @return {@code true} if the email was sent successfully, otherwise
     *         {@code false}.
     */
    public boolean sendCourseStartReminderInstructor(String subject, String destinationEmail, String userName,
            String courseName, String startDate) {
        try {
            // 1) Crea el objeto de correo utilizando SendGrid
            Email from = new Email("no-reply@em5697.eduhubpro.site", "EduHubPro"); // Usando tu dominio verificado
            Email to = new Email(destinationEmail, userName); // Se envía automáticamente a este correo

            // 2) Crea el correo con la plantilla de SendGrid
            Mail mail = new Mail();
            mail.setFrom(from);
            mail.setSubject(subject);
            mail.setTemplateId(courseStartReminderIns); // ID de plantilla en SendGrid

            // 3) Configura la personalización del correo
            Personalization personalization = new Personalization();
            personalization.addTo(to); // Agrega al destinatario
            personalization.addDynamicTemplateData("name", userName); // Variable dinámica en la plantilla
            personalization.addDynamicTemplateData("start_date", startDate); // Fecha de inicio
            personalization.addDynamicTemplateData("course_name", courseName); // Nombre del curso
            personalization.addDynamicTemplateData("support_url", supportUrl); // Url de soporte
            // personalization.addDynamicTemplateData("instructor_name", instructorName); //
            // Nombre del instructor
            // personalization.addDynamicTemplateData("end_date", endDate); // Fecha de
            // finalización

            mail.addPersonalization(personalization);

            // 4) Configura la API de SendGrid
            SendGrid sg = new SendGrid(accessToken); // Tu API key
            Request request = new Request();
            request.setMethod(Method.POST);
            request.setEndpoint("mail/send");
            request.setBody(mail.build());

            // 5) Envía el correo
            Response response = sg.api(request);
            logger.info("Correo enviado con ID: " + response.getBody());
            return response.getStatusCode() == 202; // 202 = Aceptado por SendGrid

        } catch (IOException e) {
            logger.error("Error al enviar el correo: ", e);
            return false;
        }
    }

}
