INSERT INTO user (
  user_id,
  name,
  email,
  password,
  profile_photo_path,
  description,
  register_date,
  role,
  status
) VALUES (
  UNHEX(REPLACE('b2ce9bd2-2155-4bc0-b44d-d2cb0b15d080','-','')),  -- Ejemplo de UUID en formato binario
  'Juan Pérez',
  'juan.perez@example.com',
  '$2a$10$abcxyzHasheadoEnBcrypt123456',  -- Contraseña encriptada Bcrypt
  NULL,
  NULL,
  '2025-03-20 10:00:00',
  'STUDENT',
  'ACTIVE'
);
INSERT INTO course (
  course_id,
  title,
  description,
  banner_path,
  start_date,
  end_date,
  price,
  size,
  status,
  instructor_id
) VALUES (
  UNHEX(REPLACE('bd844fa8-656a-4b42-829f-39a3e379f0e1','-','')),
  'Curso de Java',
  'Aprende fundamentos de Java y más.',
  'java_banner.jpg',
  '2025-04-01 09:00:00',
  '2025-06-01 18:00:00',
  1500,
  30,
  'TO_APPROVE', -- Estado inicial del curso
  UNHEX(REPLACE('b2406235-0f83-4d65-ab6a-67064aa4afca','-',''))
);
INSERT INTO registration (
  registration_id,
  status,             -- Column: registration_status en tu modelo
  student_id,
  course_id
) VALUES (
  UNHEX(REPLACE('9652b6f7-bc2e-47a4-ac70-2e2885d3e3fe','-','')),
  'PENDING',  -- Estatus del enum RegistrationStatus
  UNHEX(REPLACE('b2ce9bd2-2155-4bc0-b44d-d2cb0b15d080','-','')),  -- user_id del estudiante
  UNHEX(REPLACE('bd844fa8-656a-4b42-829f-39a3e379f0e1','-',''))   -- course_id
);
INSERT INTO payment (
  payment_id,
  status,
 payment_url,
  registration_id
) VALUES (
  UNHEX(REPLACE('e78a4936-3039-47b0-8ae5-7bec75d7b843','-','')),
  'PENDING_PAYMENT',          -- PaymentStatus (FINISHED, PENDING_PAYMENT, FAILED)
  '',
  UNHEX(REPLACE('9652b6f7-bc2e-47a4-ac70-2e2885d3e3fe','-',''))   -- la misma registration_id que insertaste
);
-- 1. USER (Estudiante)
INSERT INTO user (
  user_id,
  name,
  email,
  password,
  profile_photo_path,
  description,
  register_date,
  role,
  status
) VALUES (
  UNHEX(REPLACE('b2ce9bd2-2155-4bc0-b44d-d2cb0b15d080','-','')),
  'Juan Pérez',
  'juan.perez@example.com',
  '$2a$10$abcxyzHasheadoEnBcrypt123456',
  NULL,
  NULL,
  '2025-03-20 10:00:00',
  'STUDENT',
  'ACTIVE'
);

-- 2. COURSE
INSERT INTO course (
  course_id,
  title,
  description,
  banner_path,
  start_date,
  end_date,
  price,
  size,
  status,
  instructor_id
) VALUES (
  UNHEX(REPLACE('bd844fa8-656a-4b42-829f-39a3e379f0e1','-','')),
  'Curso de Java',
  'Aprende fundamentos de Java y más.',
  'java_banner.jpg',
  '2025-04-01 09:00:00',
  '2025-06-01 18:00:00',
  1500,
  30,
  'TO_APPROVE', 
  UNHEX(REPLACE('c3ad2d4c-d43c-4f12-9a0c-36b5c81c4dc3','-',''))
);

-- 3. REGISTRATION
INSERT INTO registration (
  registration_id,
  status,
  student_id,
  course_id
) VALUES (
  UNHEX(REPLACE('9652b6f7-bc2e-47a4-ac70-2e2885d3e3fe','-','')),
  'PENDING',
  UNHEX(REPLACE('b2ce9bd2-2155-4bc0-b44d-d2cb0b15d080','-','')),
  UNHEX(REPLACE('bd844fa8-656a-4b42-829f-39a3e379f0e1','-',''))
);

-- 4. PAYMENT
INSERT INTO payment (
  payment_id,
  status,
  account_id,
  registration_id
) VALUES (
  UNHEX(REPLACE('e78a4936-3039-47b0-8ae5-7bec75d7b843','-','')),
  'PENDING_PAYMENT',
  UNHEX(REPLACE('2af3b452-ac31-4233-93f8-c1d6650f21f7','-','')),
  UNHEX(REPLACE('9652b6f7-bc2e-47a4-ac70-2e2885d3e3fe','-',''))
);
