const LOGIN = 'LOGIN';
const LOGOUT = 'LOGOUT';

export const USER_ACTIONS = {
    LOGIN,
    LOGOUT
}