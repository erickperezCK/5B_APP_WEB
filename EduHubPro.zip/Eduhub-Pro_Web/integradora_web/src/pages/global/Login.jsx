import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

// Svgs
import signupImage from '../../assets/svg/signin.svg';
import signinImage from '../../assets/svg/signup.svg';

import styles from '../../styles/login.module.css';

import { sweetAlert, unlogin } from '../../utils/config/config.js';
import { USER_ACTIONS } from '../../utils/config/enums.js';

import { useUserContext } from '../../contexts/UserProvider.jsx';

import {
    auth_path,
    base_api_url,
    login,
    register
} from '../../utils/config/paths.js';

const Login = () => {

    const navigate = useNavigate();

    const { dispatch } = useUserContext();

    // Animation
    const [isSignUpMode, setIsSignUpMode] = useState(false);

    // Login
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [role, setRole] = useState('');

    useEffect(() => {
        document.body.className = ''; // Limpia todas las clases previas
        document.body.classList.add(styles.fade_in, styles.loginBody);

        return () => {
            document.body.classList.remove(styles.fade_in, styles.loginBody); // Limpia cuando se desmonta
        };
    }, []);

    const loginRequest = async () => {

        if (email === '' && password === '') {
            sweetAlert('error', 'Error', 'El correo y la contraseña no pueden estar vacíos.', '', null);
            return;
        }

        if (email === '') {
            sweetAlert('error', 'Error', 'El correo no puede estar vacío.', '', null);
            return;
        }
        if (password === '') {
            sweetAlert('error', 'Error', 'La contraseña no puede estar vacía.', '', null);
            return;
        }

        await fetch(`${base_api_url}${auth_path}${login}`, {
            method: "POST",
            headers: unlogin,
            body: JSON.stringify(
                {
                    email: email.trim(),
                    password: password.trim()
                }
            )
        }).then(response => response.json())
            .then(response => {

                dispatch({
                    type: USER_ACTIONS.LOGIN,
                    value: {
                        jwt: response.jwt,
                        role: response.role,
                        name: response.name
                    }
                });

                if (response.role.includes("ADMIN")) {
                    // sweetAlert('success', 'Éxito', 'Inicio de sesión exitoso', '/admin/dashboard', navigate);
                    navigate('/admin/dashboard');
                } else if (response.role.includes("INSTRUCTOR")) {
                    // sweetAlert('success', 'Éxito', 'Inicio de sesión exitoso', '', navigate);
                    navigate('/inst/courses');
                } else if (response.role.includes("STUDENT")) {
                    sweetAlert('question', 'Aviso', 'Tu cuenta es de estudiante. Inicia sesión en nuestra app móvil.', '', navigate);
                    dispatch({ type: USER_ACTIONS.LOGOUT });
                    return;
                }

            }).catch((error) => {
                sweetAlert('error', 'Error', 'Hubo un error al iniciar sesión, por favor revisa tus creenciales o inténtalo de nuevo más tarde', '', null);
            });
    }

    const loginRequestR = async (email, password) => {
        await fetch(`${base_api_url}${auth_path}${login}`, {
            method: "POST",
            headers: unlogin,
            body: JSON.stringify(
                {
                    email: email.trim(),
                    password: password.trim()
                }
            )
        }).then(response => response.json())
            .then(response => {

                dispatch({
                    type: USER_ACTIONS.LOGIN,
                    value: {
                        jwt: response.jwt,
                        role: response.role,
                        name: response.name
                    }
                });

                if (role === 'STUDENT') {
                    sweetAlert('success', 'Éxito', `Registro exitoso. Inicia sesión en nuestra app móvil`, '', navigate);
                    dispatch({ type: USER_ACTIONS.LOGOUT });
                    return;
                }

                if (response.role.includes("ADMIN")) {
                    // sweetAlert('success', 'Éxito', 'Inicio de sesión exitoso', '/admin/dashboard', navigate);
                    navigate('/admin/dashboard');
                } else if (response.role.includes("INSTRUCTOR")) {
                    // sweetAlert('success', 'Éxito', 'Inicio de sesión exitoso', '', navigate);
                    navigate('/inst/profile/photo');
                }

            }).catch((error) => {
                sweetAlert('error', 'Error', 'Hubo un error al iniciar sesión, por favor revisa tus creenciales o inténtalo de nuevo más tarde.', '', null);
            });
    }

    const registerRequest = async () => {
        await fetch(`${base_api_url}${auth_path}${register}`, {
            method: "POST",
            headers: unlogin,
            body: JSON.stringify(
                {
                    name: name,
                    email: email.trim(),
                    password: password.trim(),
                    role: role
                }
            )
        }).then(response => response.json())
            .then(response => {

                if (response.type !== 'SUCCESS') {
                    if (typeof response === 'object' && !response.text) {
                        const errorMessages = Object.values(response).join("\n");
                        sweetAlert('error', 'Error', errorMessages, '', null);
                    } else if (response.text) {
                        sweetAlert('error', 'Error', response.text, '', null);
                    }
                    return;
                }

                loginRequestR(email, password);


                /* 
                setTimeout(() => {
                window.location.reload();
                }, 4000); 
                */
            }).catch((error) => {
                sweetAlert('error', 'Error', 'No pudimos hacer el registro, vuelve a intentarlo.', '', null);
            });
    }

    return (
        <div className={`${styles.owncontainer} ${isSignUpMode ? styles.sign_up_mode : ''}`}>
            <div className={styles.signin_signup}>
                <form className={styles.sign_in_form}>
                    <h2 className={styles.title}>Iniciar Sesión</h2>
                    <div className={styles.input_field}>
                        <i className="bi bi-envelope-fill"></i>
                        <input type="text" placeholder="Correo electrónico" onChange={(e) => setEmail(e.target.value)} />
                    </div>
                    <div className={styles.input_field}>
                        <i className="bi bi-lock-fill"></i>
                        <input type="password" placeholder="Contraseña" onChange={(e) => setPassword(e.target.value)} />
                    </div>
                    <input type='button' value="Iniciar sesión" onClick={async () => await loginRequest()} className={styles.botonpro} />
                    <p className={styles.social_text}>
                        <a href="#" onClick={() => navigate('/forgot-password')}>¿Olvidaste tu contraseña?</a>
                    </p>
                    <p className={styles.account_text}>¿No tienes una cuenta?
                        <a href="#" onClick={() => setIsSignUpMode(true)}>Regístrate</a>
                    </p>
                </form>
                <form className={styles.sign_up_form}>
                    <h2 className={styles.title}>Registrarse</h2>
                    <div className={styles.input_field}>
                        <i className="bi bi-person-fill"></i>
                        <input type="text" placeholder="Nombre completo" onChange={(e) => setName(e.target.value)} />
                    </div>
                    <div className={styles.input_field}>
                        <i className="bi bi-envelope-fill"></i>
                        <input type="text" placeholder="Correo electrónico" onChange={(e) => setEmail(e.target.value)} />
                    </div>
                    <div className={styles.input_field}>
                        <i className="bi bi-lock-fill"></i>
                        <input type="password" placeholder="Contraseña" onChange={(e) => setPassword(e.target.value)} />
                    </div>
                    <div className={styles.input_field}>
                        <i className="bi bi-people-fill"></i>
                        <select className={styles.role_select} value={role} onChange={(e) => setRole(e.target.value)}>
                            <option disabled value="">Selecciona un rol</option>
                            <option value="INSTRUCTOR">Docente</option>
                            <option value="STUDENT">Estudiante</option>
                        </select>
                    </div>
                    <input type="button" value="Registrarse" className={styles.botonpro} onClick={async () => await registerRequest()} />

                    <p className={styles.account_text}>¿Ya tienes una cuenta?
                        <a href="#" onClick={() => setIsSignUpMode(false)}>Inicia sesión</a>
                    </p>
                </form>
            </div>
            <div className={styles.panels_container}>
                <div className={`${styles.panel} ${styles.left_panel}`}>
                    <div className={styles.content_panel}>
                        <h3>¿Ya eres miembro?</h3>
                        <p>Inicia sesión y sigue disfrutando de todo nuestro contenido.</p>
                        <button className={styles.botonpro} onClick={() => setIsSignUpMode(false)}>Inicia sesión</button>
                    </div>
                    <img src={signupImage} className={styles.image} alt="Sign up" />
                </div>
                <div className={`${styles.panel} ${styles.right_panel}`}>
                    <div className={styles.content_panel}>
                        <h3>¿Eres nuevo aquí?</h3>
                        <p>Regístrate y conoce todo lo que nuestro sistema ofrece para el aprendizaje.</p>
                        <button className={styles.botonpro} onClick={() => setIsSignUpMode(true)}>Registrarse</button>
                    </div>
                    <img src={signinImage} className={styles.image} alt="Sign in" />
                </div>
            </div>
        </div>
    );
};

export default Login;
